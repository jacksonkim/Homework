#######################################################################
#                    Order Form Definition Variables                  #
#######################################################################

# These are the values that are used by the manager to configure this gateway.

# %sc_gateway_settings = ('cc_names', 'Credit Cards Accepted (comma seperated with no spaces)');

# The process variable is the unique variable that is passed by this gateway that tells us
# that it is time to call the process order sub.

$process_variable{'Offline'} = "process_order";

# This tells us what the variable name is that contails the cart id
# when returning from the gateway.

$return_cart_id_variable{'Offline'} = "cart_id";

# Image name and description that will show up on the view cart screen for this gateway.

$check_out_image{'Offline'}  = "complete_order.gif";
$check_out_detail{'Offline'} = "Pay by Credit Card!";

###############################################################################
# Gateway Prep
###############################################################################

sub Offline_gateway_prep
{
   # We set the ship-to address values to be the same as the bill-to values
   # if the ship-to values are blank.

   if (! $form_data{'s_name'})     { $form_data{'s_name'}      = $form_data{'b_name'};      }
   if (! $form_data{'s_address_1'}){ $form_data{'s_address_1'} = $form_data{'b_address_1'}; }
   if (! $form_data{'s_address_2'}){ $form_data{'s_address_2'} = $form_data{'b_address_2'}; }
   if (! $form_data{'s_city'})     { $form_data{'s_city'}      = $form_data{'b_city'};      }
   if (! $form_data{'s_state'})    { $form_data{'s_state'}     = $form_data{'b_state'};     }
   if (! $form_data{'s_zip'})      { $form_data{'s_zip'}       = $form_data{'b_zip'};       }
   if (! $form_data{'s_country'})  { $form_data{'s_country'}   = $form_data{'b_country'};   }
   if (! $form_data{'s_phone'})    { $form_data{'s_phone'}     = $form_data{'b_phone'};     }

   # These are misc. variables that we need to set up.

   $carddate     = "$form_data{'card_month'}/$form_data{'card_year'}";
   ($shippingkey, $shippingabv, $shipmethod) = split(/\|/, $form_data{'upgradeShipping'});

   # These are the variables that need to be passed to the checkout process/gateway
   # The first part is what we want to call the variable when it is passed.
   # The second part is what variable  we are going to use.
   # Pass name, Variable name to use.

   $sc_passthrough_variables->{'shippingkey'}  = 'shippingkey';
   $sc_passthrough_variables->{'shippingabv'}  = 'shippingabv';
   $sc_passthrough_variables->{'shipmethod'}   = 'shipmethod';
   $sc_passthrough_variables->{'carddate'}     = 'carddate';

   $sc_passthrough_variables->{'SHIPPING'}     = 'final_shipping';
   $sc_passthrough_variables->{'SALESTAX'}     = 'final_salestax';
   $sc_passthrough_variables->{'DISCOUNT'}     = 'final_discount';
   $sc_passthrough_variables->{'SUBTOTAL'}     = 'subtotal';
   $sc_passthrough_variables->{'AMOUNT'}       = 'final_total';

   # This is the same as above but instead of variables we are using $form_data{'values'}
   # for the second part.
   # Pass form name as, Order form name.

   $sc_passthrough_form_data->{'b_name'}       = 'b_name';
   $sc_passthrough_form_data->{'b_address_1'}  = 'b_address_1';
   $sc_passthrough_form_data->{'b_address_2'}  = 'b_address_2';
   $sc_passthrough_form_data->{'b_city'}       = 'b_city';
   $sc_passthrough_form_data->{'b_state'}      = 'b_state';
   $sc_passthrough_form_data->{'b_zip'}        = 'b_zip';
   $sc_passthrough_form_data->{'b_country'}    = 'b_country';
   $sc_passthrough_form_data->{'b_phone'}      = 'b_phone';
   $sc_passthrough_form_data->{'fax'}          = 'fax';
   $sc_passthrough_form_data->{'email'}        = 'email';
   $sc_passthrough_form_data->{'s_name'}       = 's_name';
   $sc_passthrough_form_data->{'s_address_1'}  = 's_address_1';
   $sc_passthrough_form_data->{'s_address_2'}  = 's_address_2';
   $sc_passthrough_form_data->{'s_city'}       = 's_city';
   $sc_passthrough_form_data->{'s_state'}      = 's_state';
   $sc_passthrough_form_data->{'s_zip'}        = 's_zip';
   $sc_passthrough_form_data->{'s_country'}    = 's_country';
   $sc_passthrough_form_data->{'s_phone'}      = 's_phone';
   $sc_passthrough_form_data->{'card_type'}    = 'card_type';
   $sc_passthrough_form_data->{'card_number'}  = 'card_number';
   $sc_passthrough_form_data->{'card_month'}   = 'card_month';
   $sc_passthrough_form_data->{'card_year'}    = 'card_year';
   $sc_passthrough_form_data->{'card_cid'}     = 'card_cid';
   $sc_passthrough_form_data->{'comments'}     = 'comments';
   $sc_passthrough_form_data->{'mailinglist'}  = 'mailinglist';
   $sc_passthrough_form_data->{'upgradeShipping'}  = 'upgradeShipping';

   # Used for customer accounts
   $sc_passthrough_form_data->{'account'}  = 'account';

   # coupons support
   $sc_passthrough_form_data->{'coupon_code'}  = 'coupon_code';

   # This is a list of the form values on the order form and an actual description of what this
   # field actually is. This is used to display an error message to the screen if this is a
   # required field and it is not filled in.

   $sc_order_form_array->{'b_name'}       = 'Billing Name';
   $sc_order_form_array->{'b_address_1'}  = 'Billing Street';
   $sc_order_form_array->{'b_address_2'}  = 'Billing Street';
   $sc_order_form_array->{'b_city'}       = 'Billing City';
   $sc_order_form_array->{'b_state'}      = 'Billing State';
   $sc_order_form_array->{'b_zip'}        = 'Billing Zip';
   $sc_order_form_array->{'b_country'}    = 'Billing Country';
   $sc_order_form_array->{'b_phone'}      = 'Billing Phone';
   $sc_order_form_array->{'s_name'}       = 'Ship To Name';
   $sc_order_form_array->{'s_address_1'}  = 'Ship To Street';
   $sc_order_form_array->{'s_address_2'}  = 'Ship To Street';
   $sc_order_form_array->{'s_city'}       = 'Ship To City';
   $sc_order_form_array->{'s_state'}      = 'Ship To State';
   $sc_order_form_array->{'s_zip'}        = 'Ship To Zip';
   $sc_order_form_array->{'s_country'}    = 'Ship To Country';
   $sc_order_form_array->{'s_phone'}      = 'Ship To Phone';
   $sc_order_form_array->{'email'}        = 'Email';
   $sc_order_form_array->{'card_type'}    = 'Type of Card';
   $sc_order_form_array->{'card_number'}  = 'Card Number';
   $sc_order_form_array->{'card_month'}   = 'Card Expiration Month';
   $sc_order_form_array->{'card_year'}    = 'Card Expiration Year';
   $sc_order_form_array->{'card_cid'}     = 'Validation Code';

   # This is a list of the required fields on the order form.

   push(@sc_order_form_required_fields, "b_name");
   push(@sc_order_form_required_fields, "b_address_1");
   push(@sc_order_form_required_fields, "b_city");
   push(@sc_order_form_required_fields, "b_state");
   push(@sc_order_form_required_fields, "b_zip");
   push(@sc_order_form_required_fields, "b_phone");
   push(@sc_order_form_required_fields, "email");
   push(@sc_order_form_required_fields, "card_type");
   push(@sc_order_form_required_fields, "card_number");
   push(@sc_order_form_required_fields, "card_month");
   push(@sc_order_form_required_fields, "card_year");
   push(@sc_order_form_required_fields, "card_cid");

   # Fields to replace in templates (Emails, and log files), form post value to replace with.

   $sc_process_order_fields->{'INVOICE'}         = 'invoice';
   $sc_process_order_fields->{'cart_id'}         = 'cart_id';
   $sc_process_order_fields->{'NAME'}            = 'b_name';
   $sc_process_order_fields->{'ADDRESS_1'}       = 'b_address_1';
   $sc_process_order_fields->{'ADDRESS_2'}       = 'b_address_2';
   $sc_process_order_fields->{'CITY'}            = 'b_city';
   $sc_process_order_fields->{'STATE'}           = 'b_state';
   $sc_process_order_fields->{'ZIP'}             = 'b_zip';
   $sc_process_order_fields->{'COUNTRY'}         = 'b_country';
   $sc_process_order_fields->{'PHONE'}           = 'b_phone';
   $sc_process_order_fields->{'EMAIL'}           = 'email';
   $sc_process_order_fields->{'FAX'}             = 'fax';
   $sc_process_order_fields->{'SHIPNAME'}        = 's_name';
   $sc_process_order_fields->{'S_ADDRESS_1'}     = 's_address_1';
   $sc_process_order_fields->{'S_ADDRESS_2'}     = 's_address_2';
   $sc_process_order_fields->{'SHIPTOCITY'}      = 's_city';
   $sc_process_order_fields->{'SHIPTOSTATE'}     = 's_state';
   $sc_process_order_fields->{'SHIPTOZIP'}       = 's_zip';
   $sc_process_order_fields->{'SHIPTOCOUNTRY'}   = 's_country';
   $sc_process_order_fields->{'SUBTOTAL'}        = 'SUBTOTAL';
   $sc_process_order_fields->{'SHIPPING'}        = 'SHIPPING';
   $sc_process_order_fields->{'SHIPMETHOD'}      = 'shipmethod';
   $sc_process_order_fields->{'SALESTAX'}        = 'SALESTAX';
   $sc_process_order_fields->{'DISCOUNT'}        = 'DISCOUNT';
   $sc_process_order_fields->{'AMOUNT'}          = 'AMOUNT';
   $sc_process_order_fields->{'METHOD'}          = 'method';
   $sc_process_order_fields->{'EXPDATE'}         = 'carddate';

   $sc_process_order_fields->{'coupon_code'}     = 'coupon_code';
   $sc_process_order_fields->{'downloads'}       = 'downloads';
}

#######################################################################
# orderform
#######################################################################

sub Offline_OrderForm
{
   my ($OrderForm, %selected, $ship_count);
   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);

   if (-f "$Path/library/members_customers.pl")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_customers.pl");

      if ($form_data{'email'} && $form_data{'password'})
      {
         $order_form_login = &login;

      } elsif ($form_data{'email'} && $form_data{'password'} eq "") {

         $OrderForm .= &lost_password("$form_data{'email'}");

      } else {
         if ($form_data{'account_update'} eq "")
         {
            $order_form_login = &login_form;
         }
      }

      $order_form_account = &account_form;
   }

   $year += 1900;
   $cc_year = $year;

   $selected{"$form_data{'card_type'}"}       = "selected";
   $selected{"$form_data{'card_month'}"}      = "selected";
   $selected{"$form_data{'card_year'}"}       = "selected";
   $selected{"$form_data{'upgradeShipping'}"} = "selected";

   while ($cc_year <= ($year + 10))
   {
      $cc_years .= qq~<option value="$cc_year" $selected{$cc_year}>$cc_year</option>\n~;
      $cc_year++
   }

   foreach my $card (@credit_cards)
   {
      $cards_accepted .= qq~<option value="$card" $selected{"$card"}>$card</option>\n~;
   }

   $query = "SELECT * FROM $table{'shipping'}";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   while(@row = $sth->fetchrow)
   {
      $shipping_html .= qq~<OPTION VALUE="$row[$shipping{'id'}]|$row[$shipping{'abv'}]|$row[$shipping{'name'}]" $selected{"$row[$shipping{'id'}]|$row[$shipping{'abv'}]|$row[$shipping{'name'}]"}>$row[$shipping{'name'}]&nbsp;</OPTION>\n~;
   }
   $sth->finish;

   $OrderForm .= qq~
      $order_form_login

      <form name="checkout" method="POST" action="$config{'secure_script_url'}">
      <INPUT TYPE="hidden" NAME="cart_id" VALUE="$cart_id">
      <INPUT TYPE="hidden" NAME="gateway" VALUE="Offline">
      <input type="hidden" name="account" value="$form_data{'account'}">

      $order_form_top
      $Offline_order_form_top1
      $Offline_order_form_top2

      <TABLE WIDTH="100%" BORDER="0" CELLPADDING="0">
      <tr>
        <td width="50%" valign="top" class="border_right">

      <TABLE WIDTH="100%" BORDER="0" CELLPADDING="0">
      <TR>
      <TD colspan="2" class="orderform_comment">
          &nbsp;
      </TD>
      </TR>
      <TR>
      <TD COLSPAN="2" class="orderform_header">Billing Address:</TD>
      </TR>
      <TR>
      <TD class="orderform_label">Name:</TD>
      <TD class="orderform_value">
         <INPUT TYPE="text" NAME="b_name" VALUE="$form_data{'b_name'}" SIZE="30" MAXLENGTH="100">
         <span class="orderform_error">$form_data{'b_name_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD class="orderform_label">Street:</TD>
      <TD class="orderform_value">
        <INPUT TYPE="text" NAME="b_address_1" SIZE="30" value="$form_data{'b_address_1'}" MAXLENGTH="100">
        <span class="orderform_error">$form_data{'b_address_1_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD class="orderform_label">&nbsp;</TD>
      <TD class="orderform_value">
        <INPUT TYPE="text" NAME="b_address_2" SIZE="30" value="$form_data{'b_address_2'}" MAXLENGTH="100">
        <span class="orderform_error">$form_data{'b_address_2_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD class="orderform_label">City:</TD>
      <TD class="orderform_value">
         <INPUT TYPE="text" NAME="b_city" SIZE="30" value="$form_data{'b_city'}" MAXLENGTH="40">
         <span class="orderform_error">$form_data{'b_city_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD class="orderform_label">State/Province/Region:</TD>
      <TD class="orderform_value">
      <INPUT TYPE="text" NAME="b_state" SIZE="4" value="$form_data{'b_state'}" MAXLENGTH="5">
      <span class="orderform_error">$form_data{'b_state_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD class="orderform_label">ZIP/Postal Code:</TD>
      <TD class="orderform_value">
        <INPUT TYPE="text" NAME="b_zip" SIZE="11" value="$form_data{'b_zip'}" MAXLENGTH="10">
        <span class="orderform_error">$form_data{'b_zip_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Country:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="b_country" SIZE="11" value="$form_data{'b_country'}" MAXLENGTH="50" >
        <span class="orderform_error">$form_data{'b_country_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Phone:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="b_phone" SIZE="15" value="$form_data{'b_phone'}" MAXLENGTH="20">
        <span class="orderform_error">$form_data{'b_phone_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Fax:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="fax" SIZE="15" MAXLENGTH="20" value="$form_data{'fax'}">
        <span class="orderform_error">$form_data{'fax_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">E-Mail:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="email" MAXLENGTH="50" size="40" value="$form_data{'email'}">
      <span class="orderform_error">$form_data{'email_error'}&nbsp;</span></TD>
      </TR>
      </TABLE>
        </td>
        <td width="50%" valign="top">

      <TABLE WIDTH="100%" BORDER="0" CELLPADDING="0">
      <TR>
      <TD COLSPAN="2" class="orderform_comment">
      <input type="checkbox" name="shipto" value="true" onClick="shipToChange()">Ship to billing address
      </TD>
      </TR>
      <TR>
      <TD COLSPAN="2" class="orderform_header">Shipping Address:</TD>
      </TR>
      <TR>
      <TD class="orderform_label">Name:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_name" SIZE="30" value="$form_data{'s_name'}" MAXLENGTH="100">
        <span class="orderform_error">$form_data{'s_name_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Street:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_address_1" SIZE="30" value="$form_data{'s_address_1'}" MAXLENGTH="100">
      <span class="orderform_error">$form_data{'s_address_1_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">&nbsp;</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_address_2" SIZE="30" value="$form_data{'s_address_2'}" MAXLENGTH="100">
      <span class="orderform_error">$form_data{'s_address_2_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">City:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_city" SIZE="30" value="$form_data{'s_city'}" MAXLENGTH="40">
      <span class="orderform_error">$form_data{'s_city_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">State/Province/Region:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_state" SIZE="4" value="$form_data{'s_state'}" MAXLENGTH="5">
      <span class="orderform_error">$form_data{'s_state_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">ZIP/Postal Code:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_zip" SIZE="11" value="$form_data{'s_zip'}" MAXLENGTH="10">
        <span class="orderform_error">$form_data{'s_zip_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Country:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_country" SIZE="11" value="$form_data{'s_country'}" MAXLENGTH="50">
        <span class="orderform_error">$form_data{'s_country_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Phone:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="s_phone" SIZE="15" value="$form_data{'s_phone'}" MAXLENGTH="20">
        <span class="orderform_error">$form_data{'s_phone_error'}&nbsp;</span></TD>
      </TR>


      </TABLE>
        </td>
      </tr>
      </TABLE>

      <TABLE WIDTH="100%" BORDER="0" CELLPADDING="0">
      <TR>
      <TD COLSPAN="2">&nbsp;</TD>
      </TR>
      <TR>
      <TD class="orderform_value" colspan="2"><input type="checkbox" $form_data{'mailinglist'} value="CHECKED" name="mailinglist">Check here to be added to our mailing list.</TD>
      </TR>
      <TR>
      <TD COLSPAN="2">&nbsp;</TD>
      </TR>
      <TR>
      <TD COLSPAN="2" class="orderform_comment">Please select the method that you would like used for shipping your order.</TD>
      </TR>
      <TR>
      <TD COLSPAN="2" class="orderform_header">Shipping Method:</TD>
      </TR>
      <TR>
      <TD class="orderform_label">Shipping:</TD>
      <TD class="orderform_value">
        <select name="upgradeShipping" size="1">
         $shipping_html
        </select>  <span class="orderform_error">$form_data{'upgradeShipping_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD COLSPAN="2" class="orderform_comment">
      Be careful to enter all credit card information correctly to avoid any delays in the shipping of your order.
      </TD>
      </TR>
      <TR>
      <TD COLSPAN="2" class="orderform_header">Credit Card Information:</TD>
      </TR>
      <TR>
      <TD class="orderform_label">Card:</TD>
      <TD class="orderform_value">
      <select size="1" name="card_type">
      <option value="">Card Type</option>
      $cards_accepted
      </select>
      <span class="orderform_error">$form_data{'card_type_error'}&nbsp;</span>
      </TD>
      </TR>
      <TR>
      <TD class="orderform_label">Number:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="card_number" MAXLENGTH="20" size="20" value="$form_data{'card_number'}">
      <span class="orderform_error">$form_data{'card_number_error'}&nbsp;</span></TD>
      </TR>
      <TR>
      <TD class="orderform_label">Exp. Date:</TD>
      <TD class="orderform_value">
      <SELECT NAME="card_month" size="1">
      <OPTION value="">Month</OPTION>
      <OPTION value="01" $selected{'01'}>01</OPTION>
      <OPTION value="02" $selected{'02'}>02</OPTION>
      <OPTION value="03" $selected{'03'}>03</OPTION>
      <OPTION value="04" $selected{'04'}>04</OPTION>
      <OPTION value="05" $selected{'05'}>05</OPTION>
      <OPTION value="06" $selected{'06'}>06</OPTION>
      <OPTION value="07" $selected{'07'}>07</OPTION>
      <OPTION value="08" $selected{'08'}>08</OPTION>
      <OPTION value="09" $selected{'09'}>09</OPTION>
      <OPTION value="10" $selected{'10'}>10</OPTION>
      <OPTION value="11" $selected{'11'}>11</OPTION>
      <OPTION value="12" $selected{'12'}>12</OPTION>
      </SELECT>/

      <SELECT NAME="card_year" size="1">
      <OPTION value="">Year</OPTION>
      $cc_years
      </SELECT><span class="orderform_error">$form_data{'card_month_error'}&nbsp;
      $form_data{'card_year_error'}&nbsp;</span>
      </TD>
      </TR>
      <tr>
      <TD class="orderform_label">Card ID:</TD>
      <TD class="orderform_value"><INPUT TYPE="text" NAME="card_cid" MAXLENGTH="20" size="4" value="$form_data{'card_cid'}">
      <span class="orderform_error">$form_data{'card_cid_error'}&nbsp;</span></TD>
      </tr>
      <TR>
      <TD colspan="2">&nbsp;</TD>
      </TR>

      $Offline_order_form_bottom1
      $Offline_order_form_bottom2
      $order_form_bottom

      $order_form_account

      <TR>
      <TD colspan="2" class="orderform_comment">
          If you have any comments or
          special instructions that you would like to send to us then please fill in
          that information here.
      </TD>
      </TR>
      <TR>
      <TD colspan="2" class="orderform_header">Special Instructions / Comments:</TD>
      </TR>
      <TR>
      <TD colspan="2" class="orderform_value" height="81">
      <textarea style="textarea" name="comments" rows="3" cols="43">$form_data{'comments'}</textarea>
      </TD>
      </TR>
      <TR>
      <TD colspan="2">
      </TD>
      </TR>
      <TR>
      <TD colspan="2" class="orderform_comment" height="40">
      Only one more step! Please click the Verify Order
      button below. This will give you the chance to examine your order one last time
      before you actually submit it to be processed.
      </TD>
      </TR>
      <TR>
      <TD colspan="2" height="46">
      <INPUT TYPE="submit" NAME="submit_order_form_button"  VALUE=" Verify Order ">
      <BR>
      </TD>
      </TR>
      </TABLE>
      </FORM>
   ~;

   return ($OrderForm);
}

###############################################################################

sub Offline_printSubmitPage
{
   my ($printSubmitPage);

   &Offline_gateway_prep;

   $cart = &display_cart_table();

   $printSubmitPage .= qq~
      <form method="POST" action="$secure_order_script_url" name="paymentForm" onSubmit="return checkClicks()">
      <input type="hidden" name="gateway" value="Offline">
      <input type="hidden" name="cart_id" value="$cart_id">
   ~;

   &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/encode.pl");
	$encypt_code = "$final_total $final_shipping $final_discount $final_salestax";
	$control     = &hmac_hex($encypt_code, $encrypt_key);
	$printSubmitPage .= qq~<INPUT TYPE="HIDDEN" NAME="control" VALUE="$control">~;

	open (PAGE, "$config{'templates_path'}/$config{'template_name'}/confirmation.txt") || &update_error_log("FILE OPEN ERROR: $config{'templates_path'}/$config{'template_name'}/confirmation.txt", __FILE__, __LINE__, 'log');
	while (<PAGE>)
	{
	   $printSubmitPage .= $_;
	}
	close (PAGE);

   while ( my ($pass_key, $pass_value) = each(%$sc_passthrough_form_data) )
   {
      $printSubmitPage .= qq~<input type="hidden" name=$pass_key value="$form_data{$pass_value}">\n~;
      $printSubmitPage =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
   }

   while ( my ($pass_key, $pass_value) = each(%$sc_passthrough_variables) )
   {
      $printSubmitPage .= qq~<INPUT TYPE="hidden" NAME=$pass_key VALUE="${$pass_value}">\n~;
      $printSubmitPage =~ s/\{$pass_key\}/${$pass_value}/g;
   }

   $printSubmitPage .= qq~
      <INPUT TYPE=SUBMIT VALUE="Submit Order For Processing">
      <INPUT TYPE="HIDDEN" NAME="process_order" VALUE="yes">
      </FORM>
   ~;

   $printSubmitPage =~ s/\{cart\}/$cart/g;

   return ($printSubmitPage);
}

###############################################################

sub Offline_processOrder
{
   my ($processOrder);
   my ($subtotal, $total_quantity, $total_weight, $required_fields_filled_in);
   my ($product, $quantity, $options, $text_of_confirm_email);

   &Offline_gateway_prep;

   &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/encode.pl");
	$encypt_code = "$form_data{'AMOUNT'} $form_data{'SHIPPING'} $form_data{'DISCOUNT'} $form_data{'SALESTAX'}";
	$control     = &hmac_hex($encypt_code, $encrypt_key);

	if ($control ne $form_data{'control'})
	{
	   return("Control number does not match");
	}

	$orderDate = &get_date($time, 1);

   my $tid = $dbh->quote($cart_id);

   my $query = "SELECT * FROM $table{'cart'},$table{'products'} WHERE cart_id=$tid AND $table{'cart'}.pid=$table{'products'}.rowid";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);

   if ($sth->rows)
   {
   	if (-f "$Path/library/members_invoice_number.pl")
   	{
   	   &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_invoice_number.pl");
   	   $invoice = &invoice_number;
   	} else {
   	   $invoice = $time . "-" . $$;
   	}
   	$form_data{'invoice'} = $invoice;
   } else {
      # Select the invoice number from the orders table
   }

   while(@row = $sth->fetchrow)
   {
      $cartData++;
      push (@stata, $row[$cart{'product_id'}]);
      push (@statb, $row[$cart{'product_id'}]);

      ##############################################################
      # Generate the text version of products for customer email
      ##############################################################
      $d_counter = 0;
      foreach my $display_index (@cart_index_for_email)
      {
         if ($row[$display_index] eq "")
         {
            $row[$display_index] = "&nbsp;";
         }

         if ($display_index == $cart{'name'})
         {
            $product_text .= qq~$cart_email_fields[$d_counter]\: $row[$display_index] - $row[$cart{'option_text'}]\n~;
            if ($row[$cart{'file'}])
            {
               $product_text .= qq~Download: $config{'script_url'}?download=$row[$cart{'filename'}]&invoice=$invoice\n~;
            }

         } elsif ($display_index == $cart{'price'}) {
            my $price = &display_price(&format_price($row[$display_index]));
            $product_text .= qq~$cart_email_fields[$d_counter]\: $price\n~;

         } elsif ($display_index eq "price_after_options") {
            my $price = &display_price(&format_price($row[$cart{'price'}]+$row[$cart{'option_price'}]));
            $product_text .= qq~$cart_email_fields[$d_counter]\: $price\n~;

         } elsif ($display_index eq "total") {
            my $price = &display_price(&format_price($row[$cart{'quantity'}]*($row[$cart{'price'}]+$row[$cart{'option_price'}])));
            $product_text .= qq~$cart_email_fields[$d_counter]\: $price\n~;

         } else {
            $product_text .= qq~$cart_email_fields[$d_counter]\: $row[$display_index]\n~;

         }

         $d_counter++;
      }
      $product_text .= "\n";

      # Write values to orders database table
      my $id = &write_db($table{'order_details'},
                         'invoice'        => "$invoice",
                         'quantity'       => "$row[$cart{'quantity'}]",
                         'category'       => "$row[$cart{'category'}]",
                         'price'          => "$row[$cart{'price'}]",
                         'name'           => "$row[$cart{'name'}]",
                         'options'        => "$row[$cart{'option_text'}]",
                         'prafo'          => $row[$cart{'price'}]+$row[$cart{'option_price'}]);


      if ($row[$cart{'filename'}] && -f "$Path/library/members_download.pl")
      {
         &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_download.pl");
         $form_data{'downloads'} .= ($row[$cart{'name'}], $row[$cart{'filename'}], $invoice);
      }
   }
   $sth->finish;

   if ($cartData)
   {
      my $id = &write_db($table{'orders'},
                         'invoice'        => "$invoice",
                         'cart_id'        => "$cart_id",
                         'account'        => "$form_data{'account'}",
                         'b_name'         => "$form_data{'b_name'}",
                         'b_address_1'    => "$form_data{'b_address_1'}",
                         'b_address_2'    => "$form_data{'b_address_2'}",
                         'b_city'         => "$form_data{'b_city'}",
                         'b_state'        => "$form_data{'b_state'}",
                         'b_zip'          => "$form_data{'b_zip'}",
                         'b_country'      => "$form_data{'b_country'}",
                         'b_phone'        => "$form_data{'b_phone'}",
                         's_name'         => "$form_data{'s_name'}",
                         's_address_1'    => "$form_data{'s_address_1'}",
                         's_address_2'    => "$form_data{'s_address_2'}",
                         's_city'         => "$form_data{'s_city'}",
                         's_state'        => "$form_data{'s_state'}",
                         's_zip'          => "$form_data{'s_zip'}",
                         's_country'      => "$form_data{'s_country'}",
                         's_phone'        => "$form_data{'s_phone'}",
                         'fax'            => "$form_data{'fax'}",
                         'email'          => "$form_data{'email'}",
                         'method'         => "$form_data{'method'}",
                         'card_type'      => "$form_data{'card_type'}",
                         'card_number'    => "$form_data{'card_number'}",
                         'card_month'     => "$form_data{'card_month'}",
                         'card_year'      => "$form_data{'card_year'}",
                         'card_cid'       => "$form_data{'card_cid'}",
                         'shipmethod'     => "$form_data{'shipmethod'}",
                         'comment'        => "$form_data{'comments'}",
                         'subtotal'       => "$form_data{'SUBTOTAL'}",
                         'shipping'       => "$form_data{'SHIPPING'}",
                         'discount'       => "$form_data{'DISCOUNT'}",
                         'salestax'       => "$form_data{'SALESTAX'}",
                         'grandtotal'     => "$form_data{'AMOUNT'}",
                         'status'         => "0",
                         'ip'             => "$ENV{'REMOTE_ADDR'}",
                         'time'           => "$time");

      if ($form_data{'mailinglist'} eq "CHECKED")
      {
         my $id = &write_db($table{'emaillog'}, 'address' => "$form_data{'EMAIL'}");
      }

   	open (EMAIL, "$config{'templates_path'}/$config{'template_name'}/customer_email.txt") || &update_error_log("FILE OPEN ERROR: $config{'templates_path'}/$config{'template_name'}/customer_email.txt", __FILE__, __LINE__, 'log');
    	while (<EMAIL>)
    	{
    	   $text_of_confirm_email .= $_;
    	}
    	close (EMAIL);

   	open (EMAIL, "$config{'templates_path'}/$config{'template_name'}/admin_email.txt") || &update_error_log("FILE OPEN ERROR: $config{'templates_path'}/$config{'template_name'}/admin_email.txt", __FILE__, __LINE__, 'log');
    	while (<EMAIL>)
    	{
    	   $text_of_admin_email .= $_;
    	}
    	close (EMAIL);

      while ( my ($pass_key, $pass_value) = each(%$sc_process_order_fields) )
      {
         if ($pass_key eq 'SUBTOTAL' || $pass_key eq 'SHIPPING' ||
             $pass_key eq 'SALESTAX' || $pass_key eq 'DISCOUNT' || $pass_key eq 'AMOUNT')
         {
            $form_data{$pass_value} = &display_price(&format_price($form_data{$pass_value}));
         }

    		$text_of_confirm_email =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
    		$text_of_admin_email   =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
      }

      while ( my ($pass_key, $pass_value) = each(%$sc_process_custom_order_fields) )
      {
    		$text_of_admin_email   .= "$pass_key\: $form_data{$pass_value}\n";
      }

    	$text_of_confirm_email =~ s/\{product_text\}/$product_text/g;
      $text_of_confirm_email =~ s/\{date\}/$orderDate/g;

    	$text_of_admin_email   =~ s/\{product_text\}/$product_text/g;
      $text_of_admin_email   =~ s/\{date\}/$orderDate/g;
      # $text_of_admin_email   =~ s/\{emailCCnum\}/$emailCCnum/g;

      $text_of_admin_email .= qq~\n\nIP: $ENV{'REMOTE_ADDR'}\n~;
      $text_of_admin_email .= qq~\n$config{'script_url'}\n~;

      &require_plugins("$Path/gateway/plugins");

      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/$mail_lib");

      if ($config{'email_admin_orders'} =~ /yes/i)
      {
         &send_mail($form_data{'email'}, $config{'order_to_email'}, "Online Order", $text_of_admin_email);
      }

      &send_mail($config{'order_from_email'}, $form_data{'email'}, "Thank you for your order!", "$text_of_confirm_email");

      # This empties the cart after the order is successful
      $query = "DELETE from $table{'cart'} WHERE cart_id=$tid";
      $dbh->do($query);
   }

   open (THANKS, "<$config{'templates_path'}/$config{'template_name'}/thankyou.htm") || &update_error_log("TEMPLATE OPEN ERROR - thankyou.htm $!", __FILE__, __LINE__);
   while (<THANKS>)
   {
      $processOrder .= $_;
   }
   close (THANKS);

   while ( my ($pass_key, $pass_value) = each(%$sc_process_order_fields) )
   {
 		$processOrder =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
   }

   return ($processOrder);
}

1;
