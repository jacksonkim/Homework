<!--

var submitcount=0;

function checkClicks()
{
   if (submitcount == 0)
   {
      submitcount++;
      return true;
   } else {
      return false;
   }
}

function shipToChange()
{
   if (document.checkout.shipto.checked == true)
   {
      document.checkout.s_name.value      = document.checkout.b_name.value;
      document.checkout.s_address_1.value = document.checkout.b_address_1.value;
      document.checkout.s_address_2.value = document.checkout.b_address_2.value;
      document.checkout.s_city.value      = document.checkout.b_city.value;
      document.checkout.s_state.value     = document.checkout.b_state.value;
      document.checkout.s_zip.value       = document.checkout.b_zip.value;
      document.checkout.s_country.value   = document.checkout.b_country.value;
      document.checkout.s_phone.value     = document.checkout.b_phone.value;
   } else {
      document.checkout.s_name.value      = '';
      document.checkout.s_address_1.value = '';
      document.checkout.s_address_2.value = '';
      document.checkout.s_city.value      = '';
      document.checkout.s_state.value     = '';
      document.checkout.s_zip.value       = '';
      document.checkout.s_country.value   = '';
      document.checkout.s_phone.value     = '';
   }
}

function textCounter(field, countfield, maxlimit)
{
   if (field.value.length > maxlimit)
   {
      field.value = field.value.substring(0, maxlimit);
   } else {
      countfield.value = maxlimit - field.value.length;
   }
}

//-->


      