############################################################
# subroutine: calculate_final_values
############################################################

sub calculate_final_values
{
   my ($subtotal, $total_quantity, $total_weight) = @_;
   my ($temp_total, $grand_total) = 0;
   my ($final_shipping, $shipping);
   my ($final_discount, $discount);
   my ($final_sales_tax, $sales_tax);

   $temp_total = $subtotal;

   if ($subtotal > 0)
   {
      for my $calc_loop (1..3)
      {
         $shipping  = 0;
         $discount  = 0;
         $sales_tax = 0;

         if ($calculate_discount_loop == $calc_loop)
         {
             $final_discount = &calculate_discount($temp_total, $total_quantity, $total_weight);
             $subtotal -= $final_discount;
         }

         if ($calculate_salestax_loop == $calc_loop)
         {
             $final_sales_tax = &calculate_sales_tax($temp_total);
             $subtotal += $final_sales_tax;
         }

         if ($calculate_shipping_loop == $calc_loop)
         {
            $final_shipping = &calculate_shipping($temp_total, $total_quantity, $total_weight, $form_data{'upgradeShipping'});
            $subtotal += $final_shipping;
         }

         $temp_total = $subtotal;
      }
   }

   $grand_total = $temp_total;

   return ($final_shipping, $final_discount, $final_sales_tax, $grand_total);
}

############################################################
# subroutine: calculate_shipping
############################################################

sub calculate_shipping
{
   my ($subtotal, $total_quantity, $total_weight, $method) = @_;
   my ($total_shipping);
   my ($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

   if ($shipKey)
   {
      my $id = $dbh->quote($shipKey);
      $query = "SELECT * FROM $table{'shipping'} WHERE id=$id";
   } else {
      $query = "SELECT * FROM $table{'shipping'} LIMIT 1";
   }

   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   while (@row = $sth->fetchrow)
   {
      $shipping_method  = $row[$shipping{'method'}];
      $shipping_price   = $row[$shipping{'price'}];
      $shipping_percent = $row[$shipping{'percent'}];
      $shipping_weight  = $row[$shipping{'weight'}];
      $shipping_sub     = $row[$shipping{'sub'}];
      last;
   }
   $sth->finish;

   if ($shipping_price)
   {
      $total_shipping += $shipping_price;
   }

   if ($shipping_percent)
   {
      $total_shipping += $subtotal*($shipping_percent/100);
   }

   if ($shipping_weight eq "yes")
   {
      $total_shipping += $total_weight;
   }

   if ($shipping_sub)
   {
      $shipping_sub =~ /([\w]+)/;
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/" . $shipping_sub . "_shipping.pl");
      $total_shipping += &{$shipping_sub}($shipKey, $shipping_method, $subtotal, $total_weight, $total_shipping);
   }

   return ($total_shipping);
}

############################################################
# subroutine: calculate_discount
############################################################

sub calculate_discount
{
   my ($subtotal, $total_quantity, $total_weight) = @_;

   if (-f "$Path/library/members_discount.pl")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_discount.pl");
      $discount = &discount($subtotal, $total_quantity, $total_weight);
   }

   return ($discount);
}

############################################################
# subroutine: calculate_sales_tax
############################################################

sub calculate_sales_tax
{
   my ($subtotal) = @_;
   my ($sales_tax) = 0;

   if (-f "$Path/library/members_sales_tax.pl")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_sales_tax.pl");
      $sales_tax = &sales_tax($subtotal, $taxable);

   } else {
      if (! $form_data{'s_state'})
      {
         $form_data{'s_state'} = $form_data{'b_state'};
      }

      $form_data{'s_state'} =~ tr/a-z/A-Z/;

      $state_count = 0;
      foreach my $tax_state (@sales_tax_form_values)
      {
         $tax_state =~ tr/a-z/A-Z/;
         if ($tax_state eq $form_data{'s_state'})
         {
            $sales_tax = $subtotal * ($sales_tax[$state_count] + 0);
         }
         $state_count++;
      }
   }

   return ($sales_tax);
}

1;