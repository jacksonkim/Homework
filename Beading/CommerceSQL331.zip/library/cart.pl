#######################################################################
#                        Delete Old Carts.                         #
#######################################################################

sub delete_old_carts
{
   my $twenty_four_hours = "86400";
   my $old_date = $time-$twenty_four_hours;


   if (-f "$Path/library/members_inventory_control.pl")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_inventory_control.pl");
      &add_from_deleted_carts($old_date, '');
   }

   my $query = "DELETE FROM $table{'cart'} WHERE add_time<$old_date";
   $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
}

#######################################################################
#                        Assign a Shopping Cart.                      #
#######################################################################

sub assign_a_unique_shopping_cart_id
{
   my (@row, $sth, $query);
   my $cart_count = 0;
   my $cart_found = "yes";

   while ($cart_found eq "yes")
   {
      $cart_id = $time . "." . $$;
      $cart_count++;
      $cart_found = "no";

      $query = "SELECT * FROM $table{'cart'} WHERE cart_id=\'$cart_id\'";
      $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
      $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
      while(@row = $sth->fetchrow)
      {
         $cart_found = "yes";
      }
      $sth->finish;

      if ($cart_count == 4)
      {
         &update_error_log("COULD NOT CREATE UNIQUE CART ID", __FILE__, __LINE__);
      }
   }

   $setcookie = 1;
}

#######################################################################
#                    Add to Shopping Cart                             #
#######################################################################

sub add_to_the_cart
{
   my ($query, $sth, $count, $fail);
   my (@row, @items_ids);
   my (%option_text, %option_price);

   foreach my $item (keys (%form_data))
   {
      if ($item =~ /^item-/i && $form_data{$item} ne "")
      {
         $item =~ s/^item-//i;

         unless (($form_data{"item-$item"} =~ /\D/) || ($form_data{"item-$item"} == 0))
         {
            push (@items_ids, $item);
         }
      }

      if ($item =~ /^option\|/i && $form_data{$item} ne "")
      {
         my ($junk, $option_number, $option_id) = split (/\|/, $item);
         my ($option_desc, $option_pr, $control) = split (/\|/, $form_data{$item});

         if ($option_desc)
         {
            &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/encode.pl");
            my $test = "$option_desc $option_pr";
            my $test_control = &hmac_hex($test, $config{'encrypt_key'});

            if ($test_control ne $control)
            {
               &update_error_log("Control miss match error", __FILE__, __LINE__);
               $fail++;
            }

            $option_text{$option_id}  .= $option_desc . ", ";
            $option_price{$option_id} += $option_pr;
         }
      }
   }

   unless ($fail)
   {
      foreach my $product_id (@items_ids)
      {
         my $cart_session_id   = $dbh->quote($cart_id);
         my $quantity          = $form_data{"item-$product_id"};
         my $cart_quantity     = $dbh->quote($quantity);
         my $cart_product_id   = $dbh->quote($product_id);
         my $options           = $option_text{$product_id};

         $options = substr($options, 0, length($options)-2);

         my $cart_options      = $dbh->quote("$options");
         my $options_price     = $option_price{$product_id};
         my $cart_option_price = $dbh->quote("$options_price");
         my $cart_time         = $dbh->quote("$time");

         ##################################################
         # Members Inventory Control Code
         ##################################################

         if (-f "$Path/library/members_inventory_control.pl")
         {
            &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_inventory_control.pl");

            my $error = &check_available($product_id, $quantity);
            if ($error)
            {
               return ($error);
            }
         }

         ##################################################

         $query = "UPDATE $table{'cart'} SET quantity=quantity+$quantity WHERE cart_id=$cart_session_id AND pid=$cart_product_id AND option_text=$cart_options";
         $sth = $dbh->prepare($query) || &update_error_log("QUERY PREPARE ERROR: $query $DBI::errstr", __FILE__, __LINE__);
         $sth->execute || &update_error_log("QUERY PREPARE ERROR: $query $DBI::errstr", __FILE__, __LINE__);
         my $item_add_count = $sth->rows;

         unless ($item_add_count)
         {
            my $id = &write_db($table{'cart'},
                               'cart_id'      => $cart_id,
                               'quantity'     => $quantity,
                               'pid'          => $product_id,
                               'option_text'  => $options,
                               'option_price' => $options_price,
                               'add_time'     => $time,
                               'ip'           => $ENV{'REMOTE_ADDR'});
         }
      }
   }

   return(0);
}

#######################################################################
#                Modify Quantity of Items in the Cart                 #
#######################################################################

sub modify_quantity_of_items_in_cart
{
   my ($sth, $query);

   foreach $key (keys (%form_data))
   {
      if ($key =~ /[\d]/ && $form_data{$key} =~ /[\d]/ && $form_data{$key} ne "")
      {
         my $q_key = $dbh->quote($key);
         my $q_id  = $dbh->quote($cart_id);
         my $qty   = $dbh->quote($form_data{"$key"});


         if ($form_data{$key} eq "0")
         {
            if (-f "$Path/library/members_inventory_control.pl")
            {
               &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_inventory_control.pl");
               &add_from_deleted_carts('', $key);
            }

            $query = "DELETE FROM $table{'cart'} WHERE cart_id=$q_id AND id=$q_key";
            $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);

         } elsif ($form_data{$key} > "0") {
            unless ($form_data{$key} =~ /[\D]/ )
            {
               if (-f "$Path/library/members_inventory_control.pl")
               {
                  &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_inventory_control.pl");
                  $DATA .= &update_available($key, $form_data{"$key"});
               }

               unless($DATA)
               {
                  $query = "UPDATE $table{'cart'} SET quantity=$qty WHERE cart_id=$q_id AND id=$q_key";
                  $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
               }
            }
         }
      }
   }
}

#######################################################################
#                 Delete Item From Cart                               #
#######################################################################

sub delete_from_cart
{
   my $delete_row = $dbh->quote($form_data{'delete_row'});
   my $tid        = $dbh->quote($cart_id);

   if (-f "$Path/library/members_inventory_control.pl")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_inventory_control.pl");
      &add_from_deleted_carts('', $form_data{'delete_row'});
   }

   $query = "DELETE FROM $table{'cart'} WHERE cart_id=$tid AND id=$delete_row";
   $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
}

#######################################################################
#                    cart_table_header Subroutine                     #
#######################################################################

sub cart_table_header
{
   my ($reason_to_display_cart) = @_;
   my ($cart_table_header, $counter);

   if ($reason_to_display_cart =~ /edit/i)
   {
      $cart_table_header .= qq~
         <FORM METHOD="POST" ACTION="$config{'script_url'}">
      ~;

      $cart_table_header .= &hidden_fields('category' => "$category",
                                           'keywords' => "$keywords",
                                           'cart_id'  => "$cart_id",
                                           'next'     => "$next");
   }

   $cart_table_header .= qq~
      <TABLE class="cart_table" width="100%" BORDER="0" cellspacing="0" cellpadding="2">
      <TR>
   ~;

   foreach $field (@cart_display_fields)
   {
      $cart_table_header .= qq~
         <td class="cart_header" align="$cart_display_alignment[$counter]" width="$cart_display_width[$counter]">$field&nbsp;</td>
      ~;

      $counter++;
   }

   $cart_table_header .= "</TR>\n";

   return ($cart_table_header);
}

#######################################################################
#                    display_cart_table Subroutine                    #
#######################################################################

sub display_cart_table
{
   my ($reason_to_display_cart) = @_;
   my ($row_count, $total_weight, $display_cart_table, $cart_body, $cart_footer);
   my ($query, $sth);

   my ($total_quantity) = 0;

   my $tid = $dbh->quote($cart_id);
   $query = "SELECT * FROM $table{'cart'},$table{'products'} where cart_id=$tid AND $table{'cart'}.pid=$table{'products'}.rowid";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   while(@row = $sth->fetchrow)
   {
      my $class = "cart_row";

      my $col_count = 0;

      $cart_body .= qq~<tr>\n~;

      foreach my $display_index (@cart_index_for_display)
      {
         if ($row[$display_index] eq "")
         {
            $row[$display_index] = "&nbsp;";
         }

         if ($display_index == $cart{'name'})
         {
            my $link = &build_link('cart_id' => $cart_id,
                                   'pid'     => $row[$cart{'rowid'}]);

            $cart_body .= qq~
               <TD class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]">
               <a href="$link">$row[$display_index]</a><br>$row[$cart{'option_text'}]</TD>
            ~;

         } elsif ($display_index == $cart{'image'}) {
            my $image = $row[$display_index];
            $image =~ s/%%URLofImages%%//;
            if ($image =~ /.*\"(.*)\".*/)
            {
               $image = $1;
            }

            $cart_body .= qq~
               <TD class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]">
               <img src="$config{'image_url'}/product/small/$image" alt="$cart{'name'}" border="0">
               </TD>
            ~;

         } elsif ($display_index == $cart{'price'}) {
            my $price = &display_price(&format_price($row[$display_index]));
            $cart_body .= qq~
               <TD class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]" nowrap>$price</TD>
            ~;

         } elsif ($display_index eq "price_after_options") {

            my $price = &display_price(&format_price($row[$cart{'price'}]+$row[$cart{'option_price'}]));
            $cart_body .= qq~
               <TD class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]" nowrap>$price</TD>
            ~;

         } elsif ($display_index eq "total") {
            my $price = &display_price(&format_price($row[$cart{'quantity'}]*($row[$cart{'price'}]+$row[$cart{'option_price'}])));

            $cart_body .= qq~
               <TD class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]" nowrap>$price</TD>
            ~;

         } elsif (($display_index == $cart{'quantity'}) && ($reason_to_display_cart =~ /edit/i)) {

            my $link = &build_link('cart_id'                   => $cart_id,
                                   'next'                      => $next,
                                   'keywords'                  => $keywords,
                                   'category'                  => $category,
                                   'submit_deletion_button'    => 'yes',
                                   'delete_row'                => $row[$cart{'id'}]);

            $cart_body .= qq~
               <td class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]" nowrap>
               <INPUT TYPE="text" NAME="$row[$cart{'id'}]" VALUE="$row[$cart{'quantity'}]" SIZE ="3">
               <a href="$link">Delete</a>
               </TD>
            ~;

         } else {
            $cart_body .= qq~
               <TD class="$class" ALIGN="$cart_display_alignment[$col_count]" valign="$cart_display_valign[$col_count]">$row[$display_index]</TD>
            ~;

         }

         $col_count++;
      }

      $row_count++;

      $cart_body .= qq~</TR>\n~;

      $total_weight   += $row[$cart{'quantity'}]*$row[$cart{'weight'}];
      $subtotal       += $row[$cart{'quantity'}]*($row[$cart{'price'}]+$row[$cart{'option_price'}]);
      $total_quantity += $row[$cart{'quantity'}];
   }
   $sth->finish;

   $cart_body .= qq~</table>\n~;

   if ($row_count)
   {
      $display_cart_table .= &cart_table_header($reason_to_display_cart);
      $display_cart_table .= $cart_body;
      $display_cart_table .= &display_calculations($reason_to_display_cart, $subtotal, $total_quantity, $total_weight);

      if ($reason_to_display_cart eq "edit")
      {
         $display_cart_table .= &cart_footer;
      } else {
#         $display_cart_table .= "</FORM>";
      }

   } else {

      my $hidden = &hidden_fields('category' => "$category",
                                  'keywords' => "$keywords",
                                  'cart_id'  => "$cart_id",
                                  'next'     => "$next");

      $display_cart_table .= qq~
         <FORM METHOD="POST" ACTION="$config{'script_url'}">
         $hidden
         <div class="cart_empty">
         Your cart is empty... Please add products to your cart before checking out.
         <p>
         <INPUT TYPE="IMAGE" NAME="continue_shopping_button" VALUE="Continue Shopping" SRC="$config{'templates_path'}/$config{'template_name'}/images/continue_shopping.gif" BORDER="0">
         </p>
         </center>
         </div>

         </FORM>
      ~;
   }

   return ($display_cart_table);
}

###########################################################################
# Display Calculations
###########################################################################

sub display_calculations
{
   my ($reason_to_display_cart, $subtotal, $total_quantity, $total_weight) = @_;
   my ($display_calculations);

   $final_subtotal   = &format_price($subtotal);
   $display_subtotal = &display_price($final_subtotal);

   $display_calculations .= qq~
      <div align="right">
      <table border="0">
      <tr>
      <td class="total_label">Subtotal:</td>
      <td class="total_value">$display_subtotal</td>
      </tr>
      </table>
      </div>
   ~;

   # Chnage "editx" to just "edit" if you don't want to calculate shipping/tax/discount on edit form.
   if ($reason_to_display_cart ne "editx")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/calculations.pl");
      ($final_shipping, $final_discount, $final_salestax, $final_total) = &calculate_final_values($subtotal, $total_quantity, $total_weight);

      $final_shipping   = &format_price($final_shipping);
      $display_shipping = &display_price($final_shipping);

      if ($final_shipping > 0)
      {
         $display_calculations .= qq~
            <div align="right">
            <table border="0">
            <tr>
            <td class="calc_shipping">$calculate</td>
            <td class="total_label">Shipping:</td>
            <td class="total_value">$display_shipping</td>
            </tr>
            </table>
            </div>
         ~;
      } else {
         $display_calculations .= qq~
            <div align="right">
            <table border="0">
            <tr>
            <td class="calc_shipping">$calculate</td>
            <td class="total_label">Shipping:</td>
            <td class="total_value">?????</td>
            </tr>
            </table>
            </div>
         ~;
      }

      $final_discount   = &format_price($final_discount);
      $display_discount = &display_price($final_discount);

      if ($final_discount > 0)
      {
         $display_calculations .= qq~
            <div align="right">
            <table border="0">
            <tr>
            <td class="total_label">Discount:</td>
            <td class="total_value">$display_discount</td>
            </tr>
            </table>
            </div>
         ~;
      }

      $final_salestax   = &format_price($final_salestax);
      $display_salestax = &display_price($final_salestax);

      if ($final_salestax > 0)
      {
         $display_calculations .= qq~
            <div align="right">
            <table border="0">
            <tr>
            <td class="total_label">Sales Tax:</td>
            <td class="total_value">$display_salestax</td>
            </tr>
            </table>
            </div>
         ~;
      }

      $final_total   = &format_price($final_total);
      $display_total = &display_price($final_total);

      if ($reason_to_display_cart eq "edit")
      {
         $total_label = "Pretax Total:";
      } else {
         $total_label = "Grand Total:";
      }

      $display_calculations .= qq~
         <div align="right">
         <table border="0">
         <tr>
         <td class="total_label">$total_label</td>
         <td class="total_value">$display_total</td>
         </tr>
         </table>
         </div>
      ~;

      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/encode.pl");
      my $item = "$final_shipping^$final_discount^$final_salestax^$final_total";
      my $CONTROL = &hmac_hex($item, $control{'encrypt_key'});

      $display_calculations .= &hidden_fields('SUBTOTAL' => "$final_subtotal",
                                              'SHIPPING' => "$final_shipping",
                                              'DISCOUNT' => "$final_discount",
                                              'SALESTAX' => "$final_salestax",
                                              'TOTAL'    => "$final_total");
   }

   return ($display_calculations);
}

#######################################################################
#                       cart_footer Subroutine                        #
#######################################################################

sub cart_footer
{
   my ($cart_footer);

   $keywords = $keywords;
   $keywords =~ s/ /+/g;

   $cart_footer .= qq~
      <br><br>
      <div align="center">
      <center>
      <table width="400" border="0">
      <tr>
      <td valign="top" align="center">
      <INPUT TYPE="IMAGE" NAME="submit_change_quantity_button" VALUE="Change Quantity" SRC="$config{'templates_path'}/$config{'template_name'}/images/edit_items.gif">
      </td>
      <td valign="top" align="center">
      <INPUT TYPE="IMAGE" NAME="continue_shopping_button" VALUE="Continue Shopping" SRC="$config{'templates_path'}/$config{'template_name'}/images/continue_shopping.gif">
      </td>
      </tr>
      </table>
      </center>
      </div>
      </FORM>

      <div align="center">
      <center>
      <table border="0" cellpadding="20" cellspacing="0">
      <tr>
$gateway_checkout_buttons
      </tr>
      </table>
      </center>
      </div>
   ~;

   return ($cart_footer);
}

1;
