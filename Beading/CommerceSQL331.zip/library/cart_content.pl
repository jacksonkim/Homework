#######################################################################
#                             Cart Content                            #
#######################################################################

sub cart_content
{
   my ($cart_content, $quantity, $query, $sth, $price, $total_cost, $total_qty);

   my $count = 0;
   my $tid = $dbh->quote($cart_id);

   $query = "SELECT * FROM $table{'cart'},$table{'products'} WHERE cart_id=$tid AND $table{'cart'}.pid=$table{'products'}.rowid";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   while(@row = $sth->fetchrow)
   {
      $count++;

      $quantity     = $row[$cart{'quantity'}];
      $price        = $row[$cart{'price'}]+$row[$cart{'option_price'}];
      $total_cost   = $total_cost + $quantity * $price;
      $total_qty    = $total_qty + $quantity;
   }
   $sth->finish;

   if ($count > 0)
   {
     $cart_content = "Total Quantity: $total_qty &nbsp; Subtotal: " . &display_price(&format_price($total_cost)) . "\n";
   } else {
     $cart_content = 'Total Quantity: 0 &nbsp; Subtotal: ' . &display_price(&format_price("0.00"));
   }

   return ($cart_content);
}

1;
