%config = (site_name                   => 'CommerceSQL FREE Shopping Cart Software DEMO',
           email_admin_orders          => 'yes',
           order_to_email              => 'test@example.com',
           order_from_email            => 'test@example.com',
           script_url                  => 'http://www.example.com/DEV3/',
           secure_script_url           => 'https;//www.example.com/',
           image_url                   => 'http://www.example.com/DEV3/images',
           secure_image_url            => 'https;//www.example.com/images',
           domain_name_for_cookie      => '.commercesql.com',
           path_for_cookie             => '/DEV3/',
           mysql_server_name           => 'localhost',
           mysql_database_name         => 'XXXXXXXXXX',
           mysql_username              => 'YYYYYYYY',
           mysql_password              => 'ZZZZZZ',
           email_on_error              => 'no',
           notify_item_added           => 'no',
           gateway_name                => 'Offline',
           templates_path              => './templates',
           templates_path_manager      => '../templates',
           template_name               => 'default',
           products_per_row            => '3',
           products_per_page           => '6',
           money_symbol                => '$',
           money_symbol_placement      => 'front',
           money_format                => '%.2f',
           encrypt_key                 => 'somethinghardtoguess',
           time_dif                    => '-3');

@sales_tax_form_values = (CA, WA);
@sales_tax             = (.06, .086);

@credit_cards = ('Visa','MasterCard','Discover','American Express');

@sc_db_query_criteria = ('query_price_low_range|price|<=|number',
                         'query_price_high_range|price|>=|number',
                         'pid|rowid|=|number',
                         'category|category|=|string',
                         'name|name|=|string',
                         'keywords|name,category,description|LIKE|string');

# increasing numerical value (1,2,3) if its 0,
# then it never gets calculated at this stage
$calculate_discount_loop = 1;
$calculate_shipping_loop = 2;
$calculate_salestax_loop = 2;

$mail_lib = "send_mail.pl";

1;