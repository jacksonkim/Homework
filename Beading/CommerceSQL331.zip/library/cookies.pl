############################################################
# Get Cookie
############################################################

sub get_cookie
{
   my ($chip, $val, %cookie);

   foreach (split(/; /, $ENV{'HTTP_COOKIE'}))
   {
      s/\+/ /g;
      ($chip, $val) = split(/=/,$_,2);
      $chip =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
      $val =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
      $cookie{$chip} .= "\1" if (defined($cookie{$chip}));
      $cookie{$chip} .= $val;
   }

   return (%cookie);
}

############################################################
# Set Cookie
############################################################

sub SetCookies
{
   my @days = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
   my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
   my ($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime(time);

   $cookie{'cart_id'} = "$cart_id";

   $sec = "0" . $sec if $sec < 10;
   $min = "0" . $min if $min < 10;
   $hour = "0" . $hour if $hour < 10;
   local(@secure) = ("","secure");

   $year += 1901;
   my $expires = "expires\=$days[$wday], $mday-$months[$mon]-$year $hour:$min:$sec GMT; "; #form expiration from value passed to function.
   my $secure = "0";

   foreach my $key (keys %cookie)
   {
      if ($cookie{$key} eq '')
      {
         &expire_cookie($key);

      } else {
         $cookie{$key} =~ s/ /+/g;
         print "Set-Cookie: $key\=$cookie{$key}; $expires; path\=$config{'path_for_cookie'}; domain\=$config{'domain_name_for_cookie'}; $secure[$sec]\n";
      }
   }
}

############################################################
# Set Cookie
############################################################

sub expire_cookie
{
   my ($key) = @_;

   my @days = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
   my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
   my ($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime(0);

   $sec = "0" . $sec if $sec < 10;
   $min = "0" . $min if $min < 10;
   $hour = "0" . $hour if $hour < 10;
   local(@secure) = ("","secure");

   $year += 1901;
   my $expires = "expires\=$days[$wday], $mday-$months[$mon]-$year $hour:$min:$sec GMT; "; #form expiration from value passed to function.
   my $secure = "0";

   print "Set-Cookie: $key\=$cookie{$key}; $expires; path\=$config{'path_for_cookie'}; domain\=$config{'domain_name_for_cookie'}; $secure[$sec]\n";
}
1;
