#################################################################
#                      get_date Subroutine                      #
#################################################################

sub get_date
{
   my ($t, $format) = @_;

   my @days = ('Sunday','Monday','Tuesday','Wednesday','Thursday', 'Friday','Saturday');
   my @months = ('January','February','March','April','May','June','July','August','September','October','November','December');

   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($t);

   $min  = sprintf("%02d", $min);
   $mday = sprintf("%02d", $mday);

   my $month = $mon + 1;
   $month = sprintf("%02d", $month);

   $year += 1900;

   if ($hour > 11)
   {
      $am_pm = "PM";
   } else {
      $am_pm = "AM";
   }

   if ($hour > 12)
   {
      $hour -= 12;
   }

   if ($hour eq "0")
   {
      $hour = 12;
   }

   if ($format eq "1")
   {
      $date = "$days[$wday], $months[$mon] $mday, $year $hour\:$min $am_pm";
   } elsif ($format eq "2") {
      $date = "$month\/$mday\/$year";
   } elsif ($format eq "3") {
      $date = "$mday\/$month\/$year";
   } elsif ($format eq "4") {
      $date = "$year$month$mday";
   } else {
      $date = "$days[$wday], $months[$mon] $mday, $year";
   }

   return ($date);
}

1;