###########################################################################
# Store Header
###########################################################################

sub StoreHeader
{
   my ($StoreHeader);

   if ($template && -f "$config{'templates_path'}/$config{'template_name'}/template-$template.dwt")
   {
      open (TEMPLATE, "$config{'templates_path'}/$config{'template_name'}/template=$template.dwt") || &update_error_log("FILE OPEN ERROR: $config{'templates_path'}/$config{'template_name'}/template-$template.dwt $!", __FILE__, __LINE__);
   } else {
      open (TEMPLATE, "$config{'templates_path'}/$config{'template_name'}/template.dwt") || &update_error_log("FILE OPEN ERROR: $config{'templates_path'}/$config{'template_name'}/template.dwt $!", __FILE__, __LINE__);
   }

   while (<TEMPLATE>)
   {
      if ($_ =~ /\{DATA\}/i){ last; }

      if ($_ =~ /<!--.*#include/)
      {
         my $file = (split(/\"/, $_))[1];
         open(DAT, "$config{'templates_path'}/$config{'template_name'}/$file") || &update_error_log("Unable to open $config{'templates_path'}/$config{'template_name'}/$file $!", __FILE__, __LINE__);
         foreach my $line (<DAT>)
         {
            $StoreHeader .= $line;
         }
         close(DAT);

      }  elsif ($_ =~ /<!--.*&/i) {
         my $cmd = (split(/--/, $_))[1];
         $cmd =~ /([\w]+)/;
         $cmd = "$1";
         $StoreHeader .= eval($cmd);

      } elsif ($_ =~ /<!--.*echo/i) {
         my $cmd = (split(/\"/, $_))[1];
         $StoreHeader .= $ENV{$cmd};

      } else {
         $StoreHeader .= $_;
      }
   }

   return ($StoreHeader);
}

###########################################################################
# Store Footer
###########################################################################

sub StoreFooter
{
   my ($StoreFooter);

   while (<TEMPLATE>)
   {
      if ($_ =~ /<!--.*#include/)
      {
         my $file = (split(/\"/, $_))[1];
         open(DAT, "$config{'templates_path'}/$config{'template_name'}/$file") || &update_error_log("Unable to open $config{'templates_path'}/$config{'template_name'}/$file $!", __FILE__, __LINE__);
         foreach my $line (<DAT>)
         {
            $StoreFooter .= $line;
         }
         close(DAT);

      }  elsif ($_ =~ /<!--.*&/i) {
         my $cmd = (split(/--/, $_))[1];
         $cmd =~ /([\w]+)/;
         $cmd = "$1";
         $StoreFooter .= eval($cmd);

      } elsif ($_ =~ /<!--.*echo/i) {
         my $cmd = (split(/\"/, $_))[1];
         $StoreFooter .= $ENV{$cmd};

      } else {
         $StoreFooter .= $_;
      }
   }
   close (TEMPLATE);

   return ($StoreFooter);
}

############################################################
# subroutine: create_html_page_from_db
############################################################

sub create_html_page_from_db
{
   my (@fields);
   my ($counter, $query);
   my ($sth, $temp, $limit, $order_by);
   my ($mysql_where_expr, $mysql_count_query_expr);

   my $exact_match = $form_data{'exact_match'};

   if ($form_data{'add_to_cart_button.x'} ne "" && $config{'notify_item_added'} eq "yes")
   {
      open (PAGE, "<$config{'templates_path'}/$config{'template_name'}/item_added_message.htm") || &update_error_log("Can't open file $config{'templates_path'}/$config{'template_name'}/item_added_message.htm $!", __FILE__, __LINE__);
      while (<PAGE>)
      {
         $create_html_page_from_db .= $_;
      }
      close (PAGE);
   }

   if (-f "$config{'templates_path'}/$config{'template_name'}/category_header.htm" && $pid eq "" && $keywords eq "")
   {
      open (PAGE, "<$config{'templates_path'}/$config{'template_name'}/category_header.htm") || &update_error_log("Can't open file $config{'templates_path'}/$config{'template_name'}/category_header.htm $!", __FILE__, __LINE__);
      while (<PAGE>)
      {
         $create_html_page_from_db .= $_;
      }
      close (PAGE);
   }

   if (-f "$config{'templates_path'}/$config{'template_name'}/$category\_header\.htm" && $pid eq "" && $keywords eq "" && $next < 1)
   {
      open (PAGE, "<$config{'templates_path'}/$config{'template_name'}/$category\_header\.htm") || &update_error_log("Can't open file $config{'templates_path'}/$config{'template_name'}/$category\_header\.htm $!", __FILE__, __LINE__);
      while (<PAGE>)
      {
         $create_html_page_from_db .= $_;
      }
      close (PAGE);
   }

   if ($pid)
   {
      $mysql_where_expr = "rowid=" . $dbh->quote($pid);

   } else {
      foreach $criteria (@sc_db_query_criteria)
      {
         $temp = &mysql_build_criteria($exact_match, $criteria);
         if ($temp ne "")
         {
            $mysql_where_expr .= $temp." AND ";
         }
      }

      $mysql_where_expr =~ s/ AND $//;
   }

   if ($pid eq "")
   {
      unless ($next)
      {
         $next = 0;
      }

      $order_by = "ORDER BY name";
      $limit    = "LIMIT $next,$config{'products_per_page'}";
   }

   $mysql_count_query_expr = "SELECT count(*) ".
                             "FROM $table{'products'} ".
                             "WHERE $mysql_where_expr";

   $sth = $dbh->prepare($mysql_count_query_expr) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $total_row_count = $sth->fetchrow_array();
   $sth->finish;

   if  ($total_row_count)
   {
      $mysql_full_query_expr = "SELECT * " .
                               "FROM $table{'products'} " .
                               "WHERE $mysql_where_expr " .
                               "$order_by " .
                               "$limit";

      # Uncomment this to print the product query for debugging
      # print "SQL: $mysql_full_query_expr<br>\n";

      my $width = int(100/$config{'products_per_page'});

      if ($pid eq "")
      {
         $create_html_page_from_db .= qq~
            <div align="center">
            <center>
            <table border="0" width="100%">
            <tr>
            <td width="$width\%" valign="top" class="category_cell">
         ~;

         $desCount = "1";
      }

      $query = "$mysql_full_query_expr";
      $sth = $dbh->prepare ($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
      $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
      while( @fields = $sth->fetchrow_array () )
      {
         if ($pid eq "")
         {
            if ($counter)
            {
               if ($desCount == $config{'products_per_row'}){
                  $create_html_page_from_db .= qq~
                     </td>
                     </tr>
                     <tr>
                     <td width="$width\%" valign="top"  class="category_cell">
                  ~;
                  $desCount = "1";
               } else {
                  $create_html_page_from_db .= qq~
                     </td>
                     <td width="$width\%" valign="top"  class="category_cell">
                  ~;
                  $desCount++;
               }
            }
            $counter++;
         } else {
            $title = $fields[$db{'name'}];
         }

         # Edit Price
         $fields[$db{'price'}] = &display_price(&format_price($fields[$db{'price'}]));

         # Edit Image
         # $fields[$db{'image'}] =~ s/%%URLofImages%%//g;
         # if ($fields[$db{'image'}] =~ /.*\"(.*)\".*/)
         # {
         #    $fields[$db{'image'}] = $1;
         # }

         # Edit option value
         $fields[$db{'options'}] =~ s/%%OPTION%%//;
         if ($fields[$db{'options'}])
         {
            open (OPTION_FILE, "<$Path/options/$fields[$db{'options'}]") || &update_error_log("$Path/options/$fields[$db{'options'}] $!", __FILE__,__LINE__);
            $fields[$db{'options'}] = "";
            while (<OPTION_FILE>)
            {
               s/{PRODUCT_ID}/$fields[$db{'rowid'}]/g;
               $fields[$db{'options'}] .= $_;
            }
            close (OPTION_FILE);
         }

         # Open template file
         if ($pid)
         {
            $itemID = "item-$fields[$db{'rowid'}]";

            $fields[$db{'image'}] = "$config{'image_url'}/product/$fields[$db{'image'}]";

            my $link = &build_link('cart_id'  => $cart_id,
                                   'next'     => $back,
                                   'keywords' => $keywords,
                                   'category' => $category);

            open(NIF, "$config{'templates_path'}/$config{'template_name'}/template_product.htm") || &update_error_log("Could not open template file: template_product.htm $!", __FILE__, __LINE__);
            foreach my $line (<NIF>)
            {
               $create_html_page_from_db .= $line;
            }
            close(NIF);

            $create_html_page_from_db =~ s/{itemID}/$itemID/g;
            $create_html_page_from_db =~ s/{back_link}/$link/g;

            if ($create_html_page_from_db =~ /{common_products}/)
            {
               if (-f "$Path/library/members_common_products.pl")
               {
                  &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_common_products.pl");
                  $common_products = &common_products("$fields[$db{'userone'}]");
               }

               $create_html_page_from_db =~ s/{common_products}/$common_products/g;
            }

            if ($create_html_page_from_db =~ /{reviews}/)
            {
               if (-f "$Path/library/members_reviews.pl")
               {
                  &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_reviews.pl");
                  $reviews = &reviews("$fields[$db{'rowid'}]");
               }

               $create_html_page_from_db =~ s/{reviews}/$reviews/g;
            }

            if ($fields[$db{'avail'}] ne "")
            {
               $fields[$db{'avail'}] = qq~<div class="inventory">Quantity Available: $fields[$db{'avail'}]</div>~;
            }

         } else {
            $fields[$db{'image'}] = "$config{'image_url'}/product/small/$fields[$db{'image'}]";

            my $link = &build_link('cart_id'  => $cart_id,
                                   'back'     => $next,
                                   'pid'      => $fields[$db{'rowid'}],
                                   'keywords' => $keywords,
                                   'category' => $category);

            open(NIF, "$config{'templates_path'}/$config{'template_name'}/template_category.htm") || &update_error_log("Could not open template file: template_category.htm $!", __FILE__, __LINE__);
            foreach my $line (<NIF>)
            {
               $create_html_page_from_db .= $line;
            }
            close(NIF);

            $create_html_page_from_db =~ s/{link}/$link/g;
         }

         # Replace place holders
         foreach my $field (@mysql_product_table)
         {
            $create_html_page_from_db =~ s/{$field}/$fields["$db{$field}"]/g;
         }
      }
      $sth->finish ();

      if ($pid eq "")
      {
         while ($config{'products_per_row'} % $desCount)
         {
            $create_html_page_from_db .= qq~
               </td>
               <td width="$width\%" valign="top"  class="category_cell">
            ~;
            $desCount++;
         }

         $create_html_page_from_db .= qq~
            </td>
            </tr>
            </table>
            </center>
            </div>
         ~;
      }

   } else {
      if ($form_data{'continue_shopping_button.x'})
      {
         $create_html_page_from_db .= &display_page("Home", __FILE__, __LINE__);
      } else {
         open(NIF, "$config{'templates_path'}/$config{'template_name'}/no_items_found.htm") || &update_error_log("Could not open template file: no_items_found.htm $!", __FILE__, __LINE__);
         foreach my $line (<NIF>)
         {
            $create_html_page_from_db .= $line;
         }
         close(NIF);
      }
   }

   return ($create_html_page_from_db);
}

#################################################################
#                     display_price Subroutine                  #
#################################################################

sub display_price
{
   my ($price) = @_;

   if ($config{'money_symbol_placement'} eq "front")
   {
      $price = "$config{'money_symbol'} $price";
   } else {
      $price = "$price $config{'money_symbol'}";
   }

   return $price;
}

#######################################################################
#                            format_price                             #
#######################################################################

sub format_price
{
   my ($price) = @_;

   $price = sprintf ($config{'money_format'}, $price);

   return $price;
}

#######################################################################
#                     display_page Subroutine                         #
#######################################################################

sub display_page
{
   my ($page, $file, $line) = @_;
   my ($display_page);

   if (-f "$Path/pages/$page\.htm")
   {
      open (PAGE, "<$Path/pages/$page\.htm") || &update_error_log("Can't open file $page\.htm $!", $file, $line);
   } elsif (-f "$Path/pages/$page\.html") {
      open (PAGE, "<$Path/pages/$page\.html") || &update_error_log("Can't open file $page\.html $!", $file, $line);
   }

   while (<PAGE>)
   {
      $display_page .= $_;
   }
   close (PAGE);

   return ($display_page);
}

#######################################################################
# Build Link
#######################################################################

sub build_link
{
   my (%hash) = @_;
   my ($string, @data);

   foreach my $key (keys %hash)
   {
      if ($hash{$key} ne "")
      {
         $hash{$key} =~ s/ /\%20/g;
         push(@data, "$key=$hash{$key}");
      }
   }

   $string = $config{'script_url'} . "?" . join('&amp;', @data);

   return ($string);
}

#######################################################################
#                    make_hidden_fields Subroutine                    #
#######################################################################

sub hidden_fields
{
   my (%hash) = @_;
   my ($hidden);

   foreach my $key (keys %hash)
   {
      if ($hash{$key} ne "")
      {
         $hidden .= qq~<INPUT TYPE="hidden" NAME="$key" VALUE="$hash{$key}">\n~;
      }
   }

   return ($hidden);
}

1;