#######################################################################
#                Database Definition Variables                        #
#######################################################################

%table = ('cart'          => 'cart',
          'customers'     => 'customers',
          'downloads'     => 'downloads',
          'emaillog'      => 'emaillog',
          'errorlog'      => 'errorlog',
          'orders'        => 'orders',
          'order_details' => 'order_details',
          'prd_stats'     => 'prd_stats',
          'products'      => 'products',
          'reviews'       => 'reviews',
          'shipping'      => 'shipping',
          'wishlists'     => 'wishlists');

# Products table format
@mysql_product_table = ('rowid',           # 0
                       'category',        # 1
                       'price',           # 2
                       'name',            # 3
                       'image',           # 4
                       'description',     # 5
                       'weight',          # 6
                       'filename',
                       'avail',
                       'userone',         # 7
                       'usertwo',         # 8
                       'userthree',       # 9
                       'userfour',        # 10
                       'userfive',        # 11
                       'options');        # 12

$count = "0";
foreach my $db_id (@mysql_product_table)
{
   $db{$db_id} = $count;
   $count++;
}

@mysql_shipping_table = ('id',
                         'abv',
                         'name',
                         'price',
                         'percent',
                         'weight',
                         'sub');

$count = "0";
foreach my $db_id (@mysql_shipping_table)
{
   $shipping{$db_id} = $count;
   $count++;
}

# Cart table format
@mysql_cart_table = ('id',
                     'cart_id',
                     'quantity',
                     'pid',
                     'option_text',
                     'option_price',
                     'add_time',
                     'ip');

$count = "0";
foreach my $db_id (@mysql_cart_table)
{
   $cart{$db_id} = $count;
   $count++;
}

foreach my $db_id (@mysql_product_table)
{
   $cart{$db_id} = $count;
   $count++;
}

# Cart table format
@mysql_cust_table = ('id',
                     'email',
                     'account_password',
                     'b_name',
                     'b_address_1',
                     'b_address_2',
                     'b_city',
                     'b_state',
                     'b_zip',
                     'b_country',
                     'b_phone',
                     'fax',
                     's_name',
                     's_address_1',
                     's_address_2',
                     's_city',
                     's_state',
                     's_zip',
                     's_country',
                     's_phone',
                     'time');

$count = "0";
foreach my $db_id (@mysql_cust_table)
{
   $cust{$db_id} = $count;
   $count++;
}

# This is for the text version of the products that will show in the text version
# of the customers email.
our @cart_email_fields      = ("Quantity"       ,"Product",     "Price");
our @cart_index_for_email   = ($cart{"quantity"},$cart{"name"}, $cart{"price"});

our @cart_display_fields    = ('',             'Item',        'Price',                      'Quantity',        'Total');
our @cart_index_for_display = ($cart{'image'}, $cart{'name'}, price_after_options,          $cart{'quantity'}, 'total');
our @cart_display_alignment = ('left',         'left',        'right',                      'center',          'right');
our @cart_display_valign    = ('top',          'top',         'top',                        'top',             'top');
our @cart_display_width     = ('75',           '300',         '50',                         '200',             '50');

$sc_mysql_dsn = "DBI:mysql:$config{'mysql_database_name'}:$config{'mysql_server_name'}";

our $dbh = DBI->connect($sc_mysql_dsn, $config{'mysql_username'}, $config{'mysql_password'}) || die "Couldn't connect to database: " . DBI->errstr;

#########################################################################################
# Insert Into Database table
#########################################################################################

sub write_db
{
   my ($table, %hash) = @_;
   my ($query, $sth, @row, $data, @insert_fields, $new_record);

   my $password = $dbh->quote($config{'encrypt_key'});

   $query = "DESCRIBE $table";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   while (@row = $sth->fetchrow)
   {
      if ($hash{$row[0]})
      {
         $data = $dbh->quote($hash{$row[0]});

         if ($row[0] =~ /^card\_/)
         {
            $data = "encode($data, $password)";
         }

      } else {
         $data = "\'\'";
      }
      push (@insert_fields, "$data");
   }
   $sth->finish;

   $new_record = join ",", @insert_fields;

   $query = "INSERT INTO $table VALUES \($new_record\)";
   my $id = $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);

   return ($id);
}

#########################################################################################
# Update Database table
#
# NOTE: Don't use in the manager because it will not update price_class!
#########################################################################################

sub update_db
{
   my ($table, $where) = @_;
   my ($query, $sth, @row, $data, @insert_fields, $update_record, $count);

	$query = "DESCRIBE $table";
	$sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	$sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	while (@row = $sth->fetchrow)
	{
	   if ($row[0] ne $field)
	   {
	      $data = "$row[0]\=" . $dbh->quote($form_data{$row[0]});
	      push (@insert_fields, "$data");
		}
	}
	$value = $dbh->quote($value);
	$sth->finish;

	$update_record   = join ", ", @insert_fields;

	$query = "UPDATE $table SET $update_record WHERE $where";
   print STDERR "$query\n";
	$count = $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	$count =~ s/0E0//;

	return ($count);
}

############################################################
# subroutine: mysql_build_criteria
############################################################

sub mysql_build_criteria
{
   my ($exact_match, $criteria) = @_;
   my (@word_list);
   my ($criteria_string) = "";

   my ($c_name, $c_fields, $c_op, $c_type) = split(/\|/, $criteria);

   my @criteria_fields = split(/,/,$c_fields);
   my $form_value      = $form_data{$c_name};

   if ($form_value eq "")
   {
      return;
   }

   if ($exact_match =~ /yes/i) {
      $word_list[0] = $form_value;
   } else {
      $form_value =~ s/\+/ /g;
      @word_list = split(/\s+/,$form_value);
   }
   $criteria_string = "(";

   foreach $word (@word_list)
   {
      foreach $db_name (@criteria_fields)
      {
         if ($form_data{'exact_match'} =~ /yes/i)
         {
            my $qword = $dbh->quote($word);
            $criteria_string .= qq~$db_name=$qword or ~;

         } elsif ($c_op =~ /LIKE/i) {
            my $qword = "\%$word\%";
            $qword = $dbh->quote($qword);
            $criteria_string .= qq~$db_name LIKE $qword OR ~;

         } else {
            my $qword = $dbh->quote($word);
            $criteria_string .= qq~$db_name $c_op $qword OR ~;

         }
      }
      $criteria_string =~ s/ OR $//i;
      $criteria_string .= ") AND (";
   }

   $criteria_string =~ s/ AND \($//i;

   return ($criteria_string);
}

1;
