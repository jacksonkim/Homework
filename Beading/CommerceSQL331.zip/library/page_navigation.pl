#######################################################################
# Multi product page navigation links
#######################################################################

sub page_navigation
{
   my ($total_rows_returned) = @_;
   my ($page_navigation);

   if ($total_rows_returned > $config{'products_per_page'})
   {
      $page_navigation .= qq~
         <div class="page_navigation">Page:
      ~;

      my $pages = int($total_rows_returned/$config{'products_per_page'});
      if ($total_rows_returned % $config{'products_per_page'})
      {
         $pages++;
      }

      for my $nnext (1..$pages)
      {
         my $prevCount = ($nnext-1)*$config{'products_per_page'};
         my $link = &build_link('cart_id'  => $cart_id,
                                'next'     => $prevCount,
                                'pid'      => $dbrow[$db{'rowid'}],
                                'keywords' => $keywords,
                                'category' => $category);

         if ($nnext eq int($next/$config{'products_per_page'})+1)
         {
            $page_navigation .= qq~
               $nnext
            ~;
         } else {
            $page_navigation .= qq~
               <a href="$link">$nnext</a>
            ~;
         }
      }

      $page_navigation .= qq~
         </div>
      ~;
   }

   return ($page_navigation);
}

1;