############################################################
#             Send Email
############################################################

sub send_mail
{
   my ($fromuser, $touser, $subject, $messagebody) = @_;
   my ($old_path) = $ENV{"PATH"};

   $ENV{"PATH"} = "";
   $ENV{ENV} = "";

   my $flags = "-t";

   $mailer  = '/usr/lib/sendmail';
   $mailer1 = '/usr/bin/sendmail';
   $mailer2 = '/usr/sbin/sendmail';
   if ( -e $mailer) {
       $mail_program=$mailer;
   } elsif( -e $mailer1){
       $mail_program=$mailer1;
   } elsif( -e $mailer2){
       $mail_program=$mailer2;
   } else {
       &update_error_log("Unable to locate sendmail", __FILE__, __LINE__)
   }

   $mail_program = "$mail_program $flags ";

   open (MAIL, "|$mail_program") || &update_error_log("Could Not Open Mail Program $!", __FILE__, __LINE__);

   $ENV{"PATH"} = $old_path;

   print MAIL qq~To: $touser\n~;
   print MAIL qq~From: $fromuser\n~;
   print MAIL qq~Subject: $subject\n\n~;
   print MAIL qq~$messagebody\n\n~;

   close (MAIL);
}

1;
