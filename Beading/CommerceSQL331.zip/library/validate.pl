############################################################
# process_order_form
############################################################

sub process_order_form
{
   my ($process_order_form, $required_fields_filled_in);

   &{$gateway . "_gateway_prep"};

   $required_fields_filled_in = "yes";

   foreach $required_field (@sc_order_form_required_fields)
   {
      if ($form_data{$required_field} eq "")
      {
         $required_fields_filled_in = "no";
         my $field = $required_field . "_error";
         $form_data{$field} = "You forgot $sc_order_form_array->{$required_field}";
      }
   }

   unless ($form_data{'email'} =~ /^[^@]+@([-\w]+\.)+[A-Za-z]{2,4}$/)
   {
      $required_fields_filled_in = "no";
      $form_data{'email_error'} = "That does not appear to be a valid email address.";
   }

   if (&validate_credit_card_information($form_data{'card_type'}, $form_data{'card_number'}, "$form_data{'card_month'}\/$form_data{'card_year'}"))
   {
      $required_fields_filled_in = "no";
   }

   if ($form_data{'account_password'} && $required_fields_filled_in eq "yes")
   {
      &require_supporting_libraries (__FILE__, __LINE__, "$Path/library/members_customers.pl");
      $form_data{'account_password_error'} = &validate_account_password;
      if ($form_data{'account_password_error'})
      {
         $required_fields_filled_in = "no";
      } else {
         if ($form_data{'account_update'})
         {
            $error = &update_account;
         } else {
            $error .= &create_new_account;
         }

         if ($error)
         {
            $required_fields_filled_in = "no";

            $process_order_form .= $error;
         }
      }
   }

   if ($required_fields_filled_in eq "yes")
   {
      $process_order_form .= &{$gateway . "_printSubmitPage"};
   } else {
      $process_order_form .= &{$gateway . "_OrderForm"};
   }

   return ($process_order_form);
}

################################################################################
# validate_credit_card_information
################################################################################

sub validate_credit_card_information
{
   my ($credit_card_name, $credit_card_number, $credit_card_expiration_date) = @_;

   $credit_card_name = "\U$credit_card_name\E";

   if (&validate_credit_card_name($credit_card_name))
   {
      $form_data{'card_type_error'} = qq~$credit_card_name is not supported in the credit card validation.~;
      return(1);
   }

   if (&validate_credit_card_number($credit_card_name, $credit_card_number))
   {
      $form_data{'card_number_error'} = "$credit_card_number is not a valid number for $credit_card_name.";
      return(1);
   }

   if (&validate_credit_card_expiration_date($credit_card_expiration_date))
   {
      $form_data{'card_month_error'} = "That credit card has expired.";
      return(1);
   }

   return(0);
}

################################################################################
# validate_credit_card_name
################################################################################

sub validate_credit_card_name
{
   my ($credit_card_name) = @_;

   @valid_credit_cards = ("VISA", "MASTERCARD", "AMERICAN EXPRESS", "DISCOVER");

   foreach $valid_credit_card (@valid_credit_cards)
   {
      if($credit_card_name eq $valid_credit_card)
      {
         return(0);
         last;
      }
   }

   return(1);
}

################################################################################
# validate_credit_card_number
################################################################################

# In this routine, the first step is to remove any dashes or spaces from the
# credit card number.  If there are any non-numeric characters remaining in the
# number, an error is returned.  The next check is validating the correct number
# of digits for each card type. If not, return an error.
#
# The algorithm used to validate the card number is the Check Digit Algorithm.
# This is the algorithm step by step:
#
# 1. Reverse the credit card number and split into individual digits.  The
#    reason for this is that for an odd digit count, the digits of interest are
#    the even ones.  For an even digit count, the digits of interest are the odd
#    ones.  Reversing a number with an odd number of digits leaves the same
#    digits in the even positions.  Reversing a number with an even number of
#    digits swaps the even and odd positions.  For example:
#
#    123456789 (Odd digit count)   987654321 (Odd digit count reversed)
#    OEOEOEOEO                     OEOEOEOEO
#     \      \_____________________/      /
#      \_________________________________/
#                      |
#    Notice that both 1 and 8 are in an odd and even position, respectively, in
#    both cases.
#
#
#    12345678 (Even digit count)   87654321 (Even digit count reversed)
#    OEOEOEOE                      OEOEOEOE
#    --------                      --------
#     \      \____________________/      /
#      \________________________________/
#                      |
#    Notice that 1 changes from an odd position to an even position, and 8
#    changes from an even position to an odd position.
#
# 2. Multiply every even numbered digit by 2.  If the result is greater than 9,
#    9 is subtracted from the product.  The original even digit is replaced with
#    the result of these calculations.
#
# 3. Add all the digits together (the original odd digits and the replaced even
#    digits)
#
# 4. Divide this sum by 10.  If the remainder is zero, the number is valid.
#    Otherwise, the number is invalid.

sub validate_credit_card_number
{
   my ($credit_card_name, $credit_card_number) = @_;
   my ($credit_card_number_length, $digit_times_two, $digit, @credit_card_number_digit, $validation_number);

   # Remove dashes and spaces from $credit_card_number.
   $credit_card_number =~ s/-//g;
   $credit_card_number =~ s/ //g;
   $credit_card_number_length = length($credit_card_number);

   # Make sure that only numbers exist
   if(!($credit_card_number =~ /^[0-9]*$/))
   {
      return(1); # Error 1: Invalid Characters in Credit Card Number.
   }

   # Check for correct number of digits for each credit card type.
   if($credit_card_name eq "VISA" && ($credit_card_number_length != 13 && $credit_card_number_length != 16))
   {
      return(1); # Error 2: Invalid Number of Digits for Given Credit Card.

   }  elsif($credit_card_name eq "MASTERCARD" && $credit_card_number_length != 16) {
      return(1); # Error 2: Invalid Number of Digits for Given Credit Card.

   } elsif($credit_card_name eq "AMERICAN EXPRESS" && $credit_card_number_length != 15) {
      return(1); # Error 2: Invalid Number of Digits for Given Credit Card.

   } elsif($credit_card_name eq "DISCOVER" && $credit_card_number_length != 16) {
      return(1); # Error 2: Invalid Number of Digits for Given Credit Card.

   }

   # Step 1.
   @credit_card_number_digit = split(/ */, reverse($credit_card_number));

   # Step 2.
   for ($digit_position = 1; $digit_position < $credit_card_number_length; $digit_position += 2)
   {
      $digit_times_two = ($credit_card_number_digit[$digit_position] * 2);

      if($digit_times_two > 9)
      {
         $credit_card_number_digit[$digit_position] = ($digit_times_two - 9);

      } else {
         $credit_card_number_digit[$digit_position] = $digit_times_two;

      }

   }

   $validation_number = 0;

   # Step 3.
   foreach $digit (@credit_card_number_digit)
   {
      $validation_number += $digit;
   }

   # Step 4.
   $validation_number % 10;

} # END: sub validate_credit_card_number

################################################################################
# validate_credit_card_expiration_date
################################################################################

sub validate_credit_card_expiration_date
{
   my ($credit_card_expiration_date) = @_;
   my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst);
   my ($expiration_month,$expiration_day,$expiration_year,$expiration_card);
   my ($my_today);

   ($expiration_month,$expiration_year) = split(/\//,$credit_card_expiration_date);

   if ($expiration_year < 100)
   {
      $expiration_year = $expiration_year + 2000; # works for a few years yet
   }

   if ($expiration_day < 1)
   {
      $expiration_day = 31;# works no matter what month ... assume end of month
   }

   # Get current month and year.
   ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime($time);

   $mon++;

   $my_today = $mday + 100*($mon + 100*(1900 + $year));
   $expiration_card = 100* (100 * $expiration_year + $expiration_month) + $expiration_day;

   if($my_today > $expiration_card)
   {
      return(1); # Error 2: Credit Card Expired.
   }

   return(0); # Card has not expired.
}

1;