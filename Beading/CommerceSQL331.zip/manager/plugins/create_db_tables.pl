#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action3 = ('Create DB Tables', 'create_db_tables_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################


############################################################
# Create the database tables
############################################################

sub create_db_tables_screen
{
   print qq~
      <p><font size="3" face="Arial"><b>Create Database Tables:</b></font></p>
      <p><font size="3" face="Arial">This will create the database tables that are
      needed for the shopping cart. </font></p>
      <p><font size="3" face="Arial">In order to use this feature you must first have
      a database created on the server for you to use, and you must go into the
      configuration section and make sure that you have entered all of the database
      information.</font></p>
      <p align="center"><font size="3" face="Arial"><a href="index.cgi?action=create_db_tables">CREATE
      DATABASE TABLES!</a></font></p>
   ~;
}


sub create_db_tables
{
   $file = "./webstore.sql";

   open QF, "$file";
   while ($line = <QF>) {

      my $isComment = 0;
      my $isBlankLine = 0;

      if ($line =~ /^\s*#/)  {$isComment   = 1}
      if ($line =~ /^\s*--/) {$isComment   = 1}
      if ($line =~ /^\s*\n/) {$isBlankLine = 1}
      if (!$isComment and !$isBlankLine) { $query .= " $line"; }

      if ($line =~ /;\s*(\n|$)/) {

          # strips out the beginning and ending spaces.
          $query =~ s/^\s+//;
          $query =~ s/\s+$//;
          $query =~ s/(\r|\n)+/ /g;

          if ($query ne ';') {
              # run query.
              $dbh->do($query);
          }
          # clean up query and prepare to take in the next one.
          $query = '';
      }
   }
   close QF;

   # In case the last query does not end with a semi-colon.
   $query =~ s/^\s+//;
   $query =~ s/\s+$//;
   $query =~ s/(\r|\n)+/ /g;

   if (!($query =~ /;$/) and ($query ne '')) {
      # run query.
      $dbh->do($query) || print "Error: $DBI::errstr<br>\n";
   }

   print qq~
   <p align="center"><font face="Arial">The database files have been created!</font></p>
   ~;
}

1;