#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action2 = ('Email Addresses', 'dl_email_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub dl_email_screen
{
   print qq~
      <font face="Arial"><b>Email Download:</b></font>
      <p><font face="Arial">This will allow you to download a list of the email
      addresses from customers that have opted to be contacted by you. You can then
      use this list with a third party email program to contact the people on this
      list.</font></p>
      <p align="center"><font face="Arial"><a href="index.cgi?action=dl_emails&amp;template=none">DOWNLOAD
      EMAIL ADDRESSES!</a></font></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
   ~;
}

############################################################
# Export orders to log file
############################################################

sub dl_emails
{
   $query = "SELECT address FROM emaillog";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $nr_of_fields = $sth->{NUM_OF_FIELDS};
   while(@row = $sth->fetchrow)
   {
      for $x (0..$nr_of_fields)
      {
         $row[$x] =~ s/\n/<br>/g;
         chomp ($row[$x]);
         $data .= "$row[$x]\|";
      }

   	$data .= "\r\n";
   }
   $sth->finish;

   $size = length($data);

   print "Content-type: text\nContent-Disposition: attachment\; filename=email_list.txt\nContent-Length: $size\nContent-Description: Commerce.CGI File Downloader\n\n";
   print $data;
}

1;