#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action2 = ('Error Log', 'error_log_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub error_log_screen
{
   $query = "SELECT * FROM $table{'errorlog'}";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   # while(@row = $sth->fetchrow)
   while($field = $sth->fetchrow_hashref)
   {
      my $etime = &get_date($field->{'time'});

      $errors .= qq~DATE: $etime\r\n~;
   	$errors .= qq~FILE: $field->{'error_file'}\r\n~;
   	$errors .= qq~LINE: $field->{'error_line'}\r\n~;
   	$errors .= qq~ERROR: $field->{'error_text'}\r\n~;
   	$errors .= qq~IP: $field->{'ip'}\r\n~;
   	$errors .= "------------------------------------------------------\r\n";
   }
   $sth->finish;

   print qq~
      <b>Error Log:</b>
      <textarea rows="14" name="errors" cols="77" style="width: 100%; height: 80%">$errors</textarea>
      <br>
      <a href="index.cgi?action=clear_error_log">Clear Error Log</a>
   ~;
}

############################################################
# Export orders to log file
############################################################

sub clear_error_log
{
   $query = "DELETE FROM $table{'errorlog'}";
   $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);

   &error_log_screen;
}

1;