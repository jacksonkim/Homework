#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action2 = ('Download Orders', 'export_orders_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub export_orders_screen
{
   print qq~
      <p><b>Export Orders:</b></p>
      <p>This will download any NEW orders that you have received
      since the last time that you downloaded orders.</p>
      <p>Once you have successfully downloaded the new
      orders make sure that you use the 'COMPLETE LAST DOWNLOAD' function to mark
      previously downloaded items as complete.</p>
      <p><a href="index.cgi?action=export_orders&amp;template=none">DOWNLOAD NEW ORDERS!</a></p>
      <p><a href="index.cgi?action=download_orders&amp;template=none">RE-DOWNLOAD LAST ORDERS!</a></p>
      <p><a href="index.cgi?action=complete_orders">COMPLETE LAST DOWNLOAD!</a></p>
   ~;
}

sub complete_orders
{
   my $query = "UPDATE orders SET status=2 WHERE status=1";
   my $id = $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);

   print qq~
      <p align="center"><font size="3" face="Arial">The previous orders has
      been marked as completed so you can now download any new orders.</font></p>
   ~;
}

sub download_orders
{
   my ($orderfields, @fields);

   my $password = $dbh->quote($config{'encrypt_key'});

   $query = "DESCRIBE orders";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $nr_of_fields = $sth->{NUM_OF_FIELDS};
   while(@row = $sth->fetchrow)
   {
      if ($row[0] =~ /^card_/)
      {
         $row[0] = "decode(orders\.$row[0], $password)";
         push(@fields, $row[0]);
      } else {
         push(@fields, "orders\.$row[0]");
      }
   }
   $sth->finish;

   $orderfields = join(',', @fields);

   $query = "SELECT $orderfields, order_details.* FROM orders, order_details WHERE orders.invoice=order_details.invoice AND orders.status=1";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $nr_of_fields = $sth->{NUM_OF_FIELDS};

   while(@row = $sth->fetchrow)
   {
      for $x (0..$nr_of_fields)
      {
         $row[$x] =~ s/\r\n/<br>/g;
         $row[$x] =~ s/\n/<br>/g;
         chomp ($row[$x]);
         $data .= "$row[$x]\|";
      }

   	$data .= "\r\n";
   }
   $sth->finish;

   $size = length($data);

   my $d = &get_date($time, 4);

   print "Content-type: text\nContent-Disposition: attachment\; filename=orders$d\.txt\nContent-Length: $size\nContent-Description: Commerce.CGI File Downloader\n\n";
   print $data;
}

sub export_orders
{
   $query = "SELECT count(*) FROM orders WHERE status=1";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   my $total_row_count = $sth->fetchrow_array();
   $sth->finish;

   if ($total_row_count)
   {
      &page_header;

      print qq~
         <p>You have orders that you have downloaded and not marked as complete!</p>
         <a href="index.cgi?action=download_orders&amp;template=none">DOWNLOAD LAST ORDER FILE!</a><br>
         <a href="index.cgi?action=complete_orders">COMPLETE LAST DOWNLOAD!</a>
      ~;

      &page_footer;

   } else {
      my $query = "UPDATE orders SET status=1 WHERE status=0";
      my $id = $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
      $id =~ s/0E0//;

      if ($id)
      {
         &download_orders;
      } else {

         &page_header;
         print qq~
            There are no new orders to download!
         ~;
         &page_footer;
      }
   }
}

1;