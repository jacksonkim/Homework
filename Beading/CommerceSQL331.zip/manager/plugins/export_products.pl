#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Export Products', 'export_prd_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub export_prd_screen
{
   print qq~
      <p><font size="3" face="Arial"><b>Export Products:</b></font></p>
      <p><font size="3" face="Arial">You can use this function to download the
      products from your products table.</font></p>
      <p><font size="3" face="Arial">You can then use this file with third party
      programs to edit your product database.</font></p>

      <form method="POST" action="index.cgi">
      <input type="hidden" name="action" value="export_prd">
      <input type="hidden" name="template" value="none">
        <p><font face="Arial">Pipe<input type="radio" value="|" checked name="seperator"> Comma<input type="radio" value="," name="seperator">
        Tab<input type="radio" value="t" name="seperator"> <input type="submit" value="   Download   "></font></p>
      </form>
   ~;
}
############################################################
# Export Products to data file
############################################################

sub export_prd
{
   my ($ext);

   $query = "SELECT * FROM $table{'products'}";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $nr_of_fields = $sth->{NUM_OF_FIELDS};

   if ($form_data{'seperator'} eq 't')
   {
      $form_data{'seperator'} = "\t";
   }

   while(@row = $sth->fetchrow)
   {
      $trow = join($form_data{'seperator'}, @row);
      chomp ($trow);
      $trow =~ s/\n/<br>/g;

   	$data .= "$trow\r\n";
   }
   $sth->finish;

   if ($form_data{'seperator'} eq "\t")
   {
      $ext = "tab";
   } elsif ($form_data{'seperator'} eq ",") {
      $ext = "csv";
   } else {
      $ext = "txt";
   }

   $size = length($data);

   print "Content-type: text\nContent-Disposition: attachment\; filename=products.$ext\nContent-Length: $size\nContent-Description: Commerce.CGI File Downloader\n\n";
   print $data;
}



1;