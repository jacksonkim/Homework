#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$optfile_path = "../options";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('Option Files',          'options');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub options
{
   $unixpath = "$optfile_path";
   opendir(CURDIR,"$unixpath") || &update_error_log("Can't open DIR $unixpath $!", __FILE__, __LINE__);
   @names=readdir(CURDIR);
   for $name(@names)
   {
      # if ($name =~ /\.inc/i)
      if ($name =~ /\.html$/i)
      {
         # $name =~ s/\.inc//g;
         $options .= "<option>$name</option>\n";
      }
   }

   print qq~
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
      <td width="50%">

      <form method="POST">
      <input type="hidden" name="action" value="option_page">
      <p align="center">

      <select size="1" name="editoption">

      $options
      </select>
      <input type="submit" value=" Edit Option "> </p>
      </form>

      </td>
      <td width="50%">

      <form method="POST">
      <p align="center">
      <input type="hidden" name="action" value="confirmdeleteoption">
      <select size="1" name="confirmdeleteoption">

      $options
      </select>
      <input type="submit" value="Delete Option"> </p>
      </form></td>
      </tr>
      </table>

      <p align="center"><font face="Verdana"><b>&nbsp;Create a new Option File!</b></font></p>

      <form method="POST">
      <input type="hidden" name="action" value="option_page">
      <p align="center"><font face="Verdana">How many options in your option file: <input type="text" name="n_option" size="4"></font></p>
      <p align="center"><font face="Verdana">How many choices for each option: <input type="text" name="c_option" size="4"></font></p>
      <p align="center"><font face="Verdana"><input type="submit" value="    Continue  &gt;&gt; "></font></p>
      </form>
   ~;
}

#######################################################################################

sub option_page
{
   my ($x, $y);

   if ($form_data{'editoption'} ne "")
   {
      $optfile = "$form_data{'editoption'}";
      $optfile =~ /([\w\-\_]+)\.(\w+)/;
      $optfile = "$1.$2";
      $optfile = "" if ($page eq ".");

      if (-f "$optfile_path/$optfile.inc")
      {
         &require_supporting_libraries (__FILE__, __LINE__, "$optfile_path/$optfile.inc");

      } else {
         open (OPT, "< $optfile_path/$optfile") || &update_error_log("Can't open $optfile_path/$optfile $!", __FILE__, __LINE__);
         while ($line=<OPT>)
         {
            chomp $line;

            if ($line =~ /\<select name\s*\=\s*\"(.+)\"\>/ig)
            {
               $n_option++;
               $value_count = 0;
               $nl = "Option$n_option";
               ${$nl} = "$nl";

            } elsif ($line =~ /\<option value\s?\=\s?\"(.+)\"\>(.+)/ig) {

               $value_count++;

               my ($label, $price) = split(/\|/, $1);

               $ol = "Option$n_option\_$value_count";
               $od = $ol . "d";

               ${$ol} = $label;
               ${$od} = $price;

               if ($value_count > $c_option) { $c_option = $value_count; }
            }
         }
         close (OPT);
      }

      unless ($n_option){ $n_option=1; }
      unless ($c_option){ $c_option=3; }

      $form_data{'n_option'} = $n_option;
      $form_data{'c_option'} = $c_option;
   }

   print qq~
      <form method="POST">
      <input type="hidden" name="editoption" value="$form_data{'editoption'}">
      <p align="center"><b><font face="Arial" size="2">File Name:
      <input type="text" name="optionfilename" size="26" value="$form_data{'editoption'}">
      <font color="#FF0000" size="2" face="Arial">- filename.html</font>
      &nbsp;</font></b></p>
      <p align="center"><b><font face="Arial" size="2">Options:
      <input type="text" name="n_option" size="5" value="$form_data{'n_option'}">
      <font size="2" face="Arial">Choices: </font>
      <input type="text" name="c_option" size="4" value="$form_data{'c_option'}"></p>
   ~;

   for $x (1..$form_data{'n_option'})
   {
      $o_name = "Option" . $x;
      print qq~
         <p align="center"><font face="Arial" size="2"><b>Option Name: </b></font><b><font face="Arial" size="2"><input type="text" name="$o_name" size="26" value="${$o_name}"></font></b></p>
         <p align="center"><b><font face="Arial" size="2">
      ~;

      for $y (1..$form_data{'c_option'})
      {
         $option_v_name = "Option" . $x . "_" . $y;
         $option_d_name = "Option" . $x . "_" . $y . "d";

         print qq~
            $y.<input type="text" name="$option_v_name" size="17" value="${$option_v_name}"> $money_symbol<input type="text" name="$option_d_name" size="7" value="${$option_d_name}"><br>
         ~;
      }

      print qq~
         </font></b></p>
      ~;
   }

   print qq~
      <p align="center"><font face="Arial">
      <input type="hidden" name="action" value="create_option_file">
      <input type="submit" value="Create Option File"></font></p>
      </form>
      <p>&nbsp;</p>
   ~;
}

#######################################################################################

sub create_option_file
{
   &require_supporting_libraries (__FILE__, __LINE__, "../library/encode.pl");

   unless ($form_data{'optionfilename'} =~ /\.html$/)
   {
      $form_data{'optionfilename'} .= ".html";
   }

   $optfile = "$form_data{'optionfilename'}";
   $optfile =~ /([\w\-\_]+)\.(\w+)/;
   $optfile = "$1.$2";
   $optfile = "" if ($page eq ".");

   open (NEWFILE, ">$optfile_path/$optfile.inc");
	foreach $tag ( keys %form_data )
	{
	   if ($tag ne "action")
	   {
	      if ($form_data{$tag})
	      {
            print NEWFILE "\$$tag \= \"$form_data{$tag}\"\;\n";
         }
      }
	}
	print NEWFILE "1\;\n";
   close (NEWFILE);

   open (NEWFILE, ">$optfile_path/$optfile") || &update_error_log("Can't open $optfile_path/$optfile $!", __FILE__, __LINE__);
   print NEWFILE  qq~
      <!-- Start Option File -->
      <table border="0"><tr><td><p align="right"><font size="2" face="Arial">
      <input type="hidden" name="option_count" value="$form_data{'n_option'}">
   ~;

   for $x (1..$form_data{'n_option'})
   {
      $o_title = "Option" . $x;
      if ($form_data{$o_title})
      {
         print NEWFILE qq~
            <input type="hidden" name="label$x" value="$form_data{$o_title}">
            <b>$form_data{$o_title}:</b> <SELECT NAME = "option|$x|{PRODUCT_ID}">
         ~;

         for $y (1..$form_data{'c_option'})
         {
            $option_v_name = "Option" . $x . "_" . $y;
            $option_d_name = "Option" . $x . "_" . $y . "d";

            if ($form_data{$option_v_name})
            {
               if ($form_data{$option_d_name})
               {
                  $o_description = "$form_data{$option_v_name} \(\+ $money_symbol $form_data{$option_d_name}\)";
               } else {
                  $o_description = "$form_data{$option_v_name}";
               }

               $item = &trim("$form_data{$option_v_name} $form_data{$option_d_name}");

               $control = &hmac_hex($item, $config{'encrypt_key'});

               $form_data{$option_v_name} = &trim($form_data{$option_v_name});

               print NEWFILE qq~
                  <OPTION VALUE = "$form_data{$option_v_name}|$form_data{$option_d_name}|$control">$o_description</OPTION>
               ~;
            }
         }

         print NEWFILE qq~
            </select><br><br>
         ~;
      }
   }

   print NEWFILE  qq~
      </font></td></tr></table>
      <!-- END Option File -->
   ~;
   close (NEWFILE);

   &option_page;
}

############################################################
# Delete Option
############################################################

sub deleteoption
{
   unlink "$optfile_path/$form_data{'deleteoption'}";
   unlink "$optfile_path/$form_data{'deleteoption'}.inc";
   &options;
}

############################################################
# Confirm Delete Option
############################################################

sub confirmdeleteoption
{
   print qq~
      <p align="center">&nbsp;</p>
      <p align="center"><font face="Arial">Are you sure you want to
      <font color="#FF0000"><b>DELETE</b></font> option file <b><font color="#FF0000">
      $form_data{'confirmdeleteoption'}</font></b>?</font></p>
      <form method="POST" action="index.cgi">
      <p align="center">
      <input type="hidden" name="deleteoption" value="$form_data{'confirmdeleteoption'}">
      <input type="hidden" name="action" value="deleteoption">
      <input type="submit" value="     YES!     "></p>
      </form>
      <p align="center">&nbsp;</p>
   ~;
}

1;