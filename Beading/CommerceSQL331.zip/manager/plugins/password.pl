#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action3 = ('Set Password', 'passform');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

############################################################
# Password input form
############################################################

sub passform
{
   print qq~
      <p><font size="3" face="Arial"><b>Password Manager:</b></font></p>
      <p><font size="3" face="Arial">This will create an .htaccess and .htpasswd file
      for the manager folder. Note this will only create a single password in the
      file, so if you decide to change it just fill out the form again and the old
      files will be overwritten.</font></p>
      <form method="POST">
      <input type="hidden" name="action" value="pass">
        <p align="center"><font face="Arial">Username: <input type="text" name="username" size="20"></font></p>
        <p align="center"><font face="Arial">Password: <input type="text" name="password" size="20"></font></p>
        <p align="center"><input type="submit" value="Submit"></p>
      </form>
   ~;
}

############################################################
# Password the admin folder
############################################################

sub pass
{
   $password = crypt($form_data{'password'}, "YL");
   open (PASSFILE, ">.htpasswd");
   print PASSFILE "$form_data{'username'}\:";
   print PASSFILE "$password\n";
   close(PASSFILE);

   $mylength = length($ENV{'SCRIPT_FILENAME'})-10;
   $path = substr($ENV{'SCRIPT_FILENAME'},0,$mylength);
   open (ACCESSFILE, ">.htaccess");
   print ACCESSFILE "Options All\n";
   print ACCESSFILE "AuthType \"Basic\"\n";
   print ACCESSFILE "AuthName \"Protected Access\"\n";
   print ACCESSFILE "AuthUserFile $path/.htpasswd\n";
   print ACCESSFILE "require valid-user\n";

   print qq~
      <center>
      <p><font face="Arial">Your username $form_data{'username'} and password $form_data{'password'} ($password) has been set</font></p>
      </center>
   ~;
}


1;