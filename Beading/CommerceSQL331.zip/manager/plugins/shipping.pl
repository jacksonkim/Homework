#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action3 = ('Shipping',          'shipping_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub shipping_screen
{
   my ($counter);

	print qq~
      $ship_done_message

      <form method="POST">

      <div class="default_bold">Shipping Settings:</div><br>
      <div class="default_text">Use this form to set up your shipping options!</div><br>
      <div align="center">
      <center>
      <table border="0" cellpadding="2" cellspacing="0" width="90%">
      <tr>
      <td class="colored_cell_header">Abbreviation:</b></td>
      <td class="colored_cell_header">Ship Name:</b></td>
      <td class="colored_cell_header">Price:</b></td>
      <td class="colored_cell_header">Percentage:</b></td>
      <td class="colored_cell_header">Product:</b></td>
      <td class="colored_cell_header">Special Sub Routine:</b></td>
      </tr>
   ~;

   $query = "SELECT * FROM $table{'shipping'}";
   $sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
   $nr_of_fields = $sth->{NUM_OF_FIELDS};
   while(@row = $sth->fetchrow)
   {
      $counter++;

      %selected = ();
      $selected{"$row[$shipping{'weight'}]"} = "selected";

      print qq~
         <tr>
         <td>
         <input type="hidden" name="id$counter" value="$row[$shipping{'id'}]">
         <input type="text" name="abv$counter" size="7" MAXLENGTH="6" value="$row[$shipping{'abv'}]"></td>
         <td><input type="text" name="name$counter" size="31" MAXLENGTH="30" value="$row[$shipping{'name'}]"></td>
         <td><input type="text" name="price$counter" size="14" MAXLENGTH="13" value="$row[$shipping{'price'}]"></td>
         <td><input type="text" name="percent$counter" size="4" MAXLENGTH="3" value="$row[$shipping{'percent'}]"></td>
         <td><select size="1" name="weight$counter">
         <option $selected{'yes'}>yes</option>
         <option $selected{'no'}>no</option>
         </select></td>
         <td><input type="text" name="sub$counter" size="21" MAXLENGTH="20" value="$row[$shipping{'sub'}]"></td>
         </tr>
      ~;

   }
   $sth->finish;

   for my $x (1..5)
   {
      $counter++;

      print qq~
         <tr>
         <td><input type="text" name="abv$counter" size="7" MAXLENGTH="6" value=""></td>
         <td><input type="text" name="name$counter" size="31" MAXLENGTH="30" value=""></td>
         <td><input type="text" name="price$counter" size="14" MAXLENGTH="13" value=""></td>
         <td><input type="text" name="percent$counter" size="4" MAXLENGTH="3" value=""></td>
         <td><select size="1" name="weight$counter">
         <option>yes</option>
         <option selected>no</option>
         </select></td>
         <td><input type="text" name="sub$counter" size="21" MAXLENGTH="20" value=""></td>
         </tr>
      ~;
   }

   print qq~
      </table>
      </center>
      </div>
      <ul class="default_text">
      <li><b>Abbreviate:</b> This is a unique abbreviation of the shipping method such as UPS, FEDEX, UPR, PICKUP.</li>
      <li><b>Ship Name:</b> This is the descriptive name that will show up on the order form, and the order.</li>
      <li><b>Price:</b> This is a flat price that will be added to the shipping amount for this method.</li>
      <li><b>Percentage:</b> This is a percentage of the subtotal that will be added to the shipping amount.</li>
      <li><b>Product:</b> When adding products you can specify a shipping amount for each item that is multiplied by the quantity. This determines whether or not this is used.</li>
      <li><b>Special Sub Routine:</b> This is for more advanced shipping options. Here you would enter the name of a special sub routine that you have written or downloaded that will calculate the shipping. There are many custom shipping logics that we have written that are in the commerce.cgi members area for download.</li>
      </ul>

      <input type="hidden" name="action" value="update_shipping">
      <input type="hidden" name="counter" value="$counter">
      <div class="centered"><input type="submit" value="     Update Shipping     "></div>
      </form>
	~;
}

#############################################################################################

sub update_shipping
{
   my $counter = $form_data{'counter'};

   for my $x (1..$counter)
   {
      if ($form_data{"abv$x"} && $form_data{"name$x"})
      {
         $form_data{"id"}        = $form_data{"id$x"};
         $form_data{"abv"}       = $form_data{"abv$x"};
         $form_data{"name"}      = $form_data{"name$x"};
         $form_data{"price"}     = $form_data{"price$x"};
         $form_data{"percent"}   = $form_data{"percent$x"};
         $form_data{"weight"}    = $form_data{"weight$x"};
         $form_data{"sub"}       = $form_data{"sub$x"};

         if ($form_data{"id"})
         {
            my $id = $dbh->quote($form_data{'id'});
            &update_db($table{'shipping'}, "id=$id");

         } else {
            &write_db($table{'shipping'}, %form_data);

         }
      }
   }

	&shipping_complete;
}

#####################################################################################

sub shipping_complete
{
   print qq~
      <h1>Shipping settings have been successfully updated.</h1>
   ~;
}

1;