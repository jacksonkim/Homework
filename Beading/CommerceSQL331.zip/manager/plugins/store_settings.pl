#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################



#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action3 = ('Store Settings', 'store_settings');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub store_settings
{
   open (CONFIG, "<../library/configuration.pl") || &update_error_log("Can't open ../library/configuration.pl $!", __FILE__, __LINE__);
   while (<CONFIG>)
   {
      $data .= $_;
   }
   close(CONFIG);

   print qq~
      <form method="POST" action="index.cgi">
      <p align="center">
      <textarea rows="20" name="config_data" cols="75" style="width: 100%;height: 80%;">$data</textarea>
      </p>
      <p align="center"><input type="submit" value="Submit Configuration Settings"></p>
      <input type="hidden" name="action" value="update_settings">
      </form>
   ~;
}

sub update_settings
{
   $form_data{'config_data'} =~ s/\r\n/\n/g;

   open (CONFIG, ">../library/configuration.pl") || &update_error_log("Can't open ../library/configuration.pl $!", __FILE__, __LINE__);
   print CONFIG qq~$form_data{'config_data'}~;
   close(CONFIG);

   print qq~
      <p align="center"><font face="Arial">Your program settings have been updated!</font></p>
   ~;
}


1;