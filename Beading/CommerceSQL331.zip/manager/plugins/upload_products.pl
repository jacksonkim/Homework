#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Upload Products', 'upload_prd_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub upload_prd_screen
{
   print qq~

      <p><font size="3" face="Arial"><b>Upload Products:</b></font></p>
      <p><font size="3" face="Arial">Select your product file and click upload
      and your product file will be upload and imported into your MySQL products
      table.</font></p>
      <p><font size="3" face="Arial">This will delete all of your current
      products and overwrite them with this new information. </font></p>
      <p><font size="3" face="Arial">You file should be in PIPE DELIMITED (|) format!</font></p>

      <form ENCTYPE="multipart/form-data" METHOD="POST" action="index.cgi">
      <p align="center">
      <input type="hidden" name="action" value="upload_products">
        <p><font face="Arial">Pipe<input type="radio" value="|" checked name="seperator"> Comma<input type="radio" value="," name="seperator">
        Tab<input type="radio" value="t" name="seperator">
      <input TYPE="FILE" NAME="file" SIZE="35">
      <input TYPE="SUBMIT" VALUE="Upload">
      </form>
   ~;
}

############################################################
# Upload products from data.file to product table
############################################################

sub upload_products
{
   # if ($form_data{'seperator'} eq "t")
   # {
   #    $form_data{'seperator'} = "\t";
   # }

   if ($form_data{'file'} =~ /([^\/\\]+)$/)
   {
   	$Filename = $1;
   	$Filename =~ s/^\.+//;
   	$File_Handle = $form_data{'file'};

      undef $Buffer;

      while ($Bytes = read($File_Handle,$Buffer,1024))
      {
         $data .= $Buffer;
      }
   	close(OUTFILE);

      $query = "DELETE FROM $table{'products'}";
      $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);

      $data =~ s/\r//g;
      @lines = split(/\n/, $data);

      foreach my $line (@lines)
      {

         my @datas = ();
         my @datafields = ();

         if ($form_data{'seperator'} eq "|")
         {
            @datafields = split(/\|/, $line);
         } elsif ($form_data{'seperator'} eq ",") {
            @datafields = split(/\,/, $line);
         } elsif ($form_data{'seperator'} eq "t") {
            @datafields = split(/\t/, $line);
         }

         for $x (0..@mysql_product_table-1)
         {
            chomp $datafields[$x];
            if ($datafields[$x])
            {
               $data = $dbh->quote($datafields[$x]);
            } else {
               $data = "\'\'";
            }
            push(@datas, $data);
         }

         my $new_item = join(",", @datas);

         $query = "INSERT INTO $table{'products'} VALUES ($new_item)";

         $dbh->do($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
      }

      print qq~
         <p align="center"><font face="Arial">Your product file has been uploaded and imported into your MySQL database!</font></p>
      ~;

   } else {
      &upload_prd_screen;
   }
}

1;