
CREATE TABLE `cart` (
  `id` int(11) auto_increment,
  `cart_id` varchar(30),
  `quantity` varchar(4),
  `pid` int(11) default '0',
  `option_text` text,
  `option_price` double(16,2),
  `add_time` varchar(30),
  `ip` varchar(15),
  PRIMARY KEY  (`id`),
  KEY `cart_id` (`cart_id`),
  KEY `add_time` (`add_time`)
);

CREATE TABLE `coupons` (
  `id` int(11) auto_increment,
  `code` varchar(30),
  `amount` varchar(10),
  `min` varchar(10),
  `expires` varchar(30),
  `uses` varchar(10),
  `used` varchar(10),
  `total` varchar(20),
  PRIMARY KEY  (`id`),
  KEY `code` (`code`)
);

CREATE TABLE `customers` (
  `id` int(11) auto_increment,
  `email` varchar(50),
  `account_password` varchar(20),
  `b_name` varchar(100),
  `b_address_1` varchar(100),
  `b_address_2` varchar(100),
  `b_city` varchar(40),
  `b_state` varchar(5),
  `b_zip` varchar(10),
  `b_country` varchar(50),
  `b_phone` varchar(20),
  `fax` varchar(20),
  `s_name` varchar(100),
  `s_address_1` varchar(100),
  `s_address_2` varchar(100),
  `s_city` varchar(40),
  `s_state` varchar(5),
  `s_zip` varchar(10),
  `s_country` varchar(50),
  `s_phone` varchar(20),
  `time` int(30) default '0',
  PRIMARY KEY  (`id`)
);

CREATE TABLE `downloads` (
  `id` int(11) auto_increment,
  `invoice` varchar(20),
  `filename` varchar(50),
  `time` varchar(15),
  `count` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `invoice` (`invoice`,`filename`)
);

CREATE TABLE `emaillog` (
  `id` int(11) auto_increment,
  `address` varchar(50),
  PRIMARY KEY  (`id`),
  UNIQUE KEY `address` (`address`)
);

CREATE TABLE `errorlog` (
  `id` int(11) auto_increment,
  `error_text` text,
  `error_file` varchar(50),
  `error_line` int(11),
  `time` varchar(30),
  `ip` varchar(15),
  PRIMARY KEY  (`id`)
);

CREATE TABLE `orders` (
  `id` int(10) auto_increment,
  `invoice` varchar(20),
  `cart_id` varchar(20),
  `account` int(11) default '0',
  `b_name` varchar(100),
  `b_address_1` varchar(100),
  `b_address_2` varchar(100),
  `b_city` varchar(40),
  `b_state` varchar(5),
  `b_zip` varchar(10),
  `b_country` varchar(50),
  `b_phone` varchar(20),
  `s_name` varchar(100),
  `s_address_1` varchar(100),
  `s_address_2` varchar(100),
  `s_city` varchar(40),
  `s_state` varchar(5),
  `s_zip` varchar(10),
  `s_country` varchar(50),
  `s_phone` varchar(20),
  `fax` varchar(20),
  `email` varchar(50),
  `card_type` blob,
  `card_number` blob,
  `card_month` blob,
  `card_year` blob,
  `card_cid` blob,
  `subtotal` double(16,2),
  `shipping` double(16,2),
  `shipmethod` varchar(30),
  `discount` double(16,2),
  `salestax` double(16,2),
  `grandtotal` double(16,2),
  `comment` text,
  `status` int(1) default '0',
  `ip` varchar(15),
  `time` varchar(15),
  PRIMARY KEY  (`id`),
  KEY `invoice` (`invoice`),
  KEY `status` (`status`)
);

CREATE TABLE `order_details` (
  `id` int(10) auto_increment,
  `invoice` varchar(20),
  `quantity` varchar(4),
  `category` varchar(50),
  `price` double(16,2),
  `name` varchar(100),
  `options` text,
  `prafo` double(16,2),
  PRIMARY KEY  (`id`),
  KEY `invoice` (`invoice`)
);

CREATE TABLE `prd_stats` (
  `id` int(11) auto_increment,
  `pid1` int(11) default '0',
  `pid2` int(11) default '0',
  `count` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `pid1` (`pid1`),
  KEY `pid2` (`pid2`)
);

CREATE TABLE `products` (
  `rowid` int(11) auto_increment,
  `category` varchar(50),
  `price` double(16,2) default '0.00',
  `name` varchar(100),
  `image` varchar(50),
  `description` text NOT NULL,
  `weight` double(16,2) default '0.00',
  `filename` varchar(50),
  `avail` varchar(10),
  `userone` text,
  `usertwo` text,
  `userthree` text,
  `userfour` text,
  `userfive` text,
  `options` text,
  PRIMARY KEY  (`rowid`),
  KEY `category` (`category`),
  KEY `name` (`name`)
);

--
-- Dumping data for table `products`
--

INSERT INTO `products` VALUES(1, 'Books', 24.00, 'Learning Perl', '0001.jpg', 'In this smooth, carefully paced course, a leading Perl trainer teaches you to program in the language that threatens to make C, sed, awk, and the Unix shell obsolete for many tasks. This book is the "official" guide for both formal (classroom) and informal learning. It is fully accessible to the novice programmer.', 4.00, 'kenwood.gif', '100', '2,3,4,7,8', '', '', '', '', 'gift_option.html');
INSERT INTO `products` VALUES(2, 'Books', 39.96, 'Programming Perl (3rd Edition)', '0002.jpg', 'Perl is a powerful programming language that has grown in popularity since it first appeared in 1988. The first edition of this book, Programming Perl, hit the shelves in 1990, and was quickly adopted as the undisputed bible of the language. Since then, Perl has grown with the times, and so has this book. <br><br>Programming Perl is not just a book about Perl. It is also a unique introduction to the language and its culture, as you might expect only from its authors. ', 4.50, '', '', 'Perl', '', '', '', '2', 'gift_option.html');
INSERT INTO `products` VALUES(3, 'Books', 31.96, 'Perl Cookbook', '0003.jpg', 'The Perl Cookbook is a comprehensive collection of problems, solutions, and practical examples for anyone programming in Perl. Topics range from beginner questions to techniques that even the most experienced Perl programmers can learn from. More than just a collection of tips and tricks, the Perl Cookbook is the long-awaited companion volume to Programming Perl, filled with previously unpublished Perl arcana.', 4.00, '', '', 'Perl', '', '', '', '1', 'gift_option.html');
INSERT INTO `products` VALUES(4, 'Books', 27.96, 'Programming the Perl DBI', '0007.jpg', '"The DBI is a database interface module for Perl. It defines a set of methods, variables and conventions that provide a consistent database interface independent of the actual database being used", explains Bunce, the architect and inventor of DBI. He and Descartes, one of the most active members of the DBI community, explain the architecture of DBI and show how to write DBI-based programs. For the DBI expert, they cover the nuances and peculiarities of each individual database driver. ', 4.00, '', '', 'Perl', '', '', '', '1', 'gift_option.html');
INSERT INTO `products` VALUES(7, 'Books', 39.99, 'MySQL (OTHER NEW RIDERS)', '0014.jpg', 'The unexpected pleasure of reading books about databases is that they are often written by authors with highly organized minds. Paul DuBois and his editors at New Riders have assembled MySQL with a clarity and lucidity that inspires confidence in the subject matter: a (nearly) freely redistributable SQL-interpreting database client/server primarily geared for Unix systems but maintained for Windows platforms as well. What isn''t "free" about MySQL (the application) is its server''s commercial use; all clients and noncommercial server use are free. DuBois''s tome isn''t free either, but its list price is modest in light of its value and the value of its namesake.<br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/0735709211/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '', 'gift_option.html');
INSERT INTO `products` VALUES(8, 'Software', 95.00, 'Sharit - Automated Software Submission', '0015.jpg', 'Internet today is an integral part of any Software marketing and promotion. <br><br>It is very time consuming to list a program with all the review and archive sites on the internet, however with Sharit this can be achieved in just a few minutes.<br><br>Sharit is the first automated submission wizard designed for the promotion of Shareware, Freeware and Commercial Demo Programs. <br><br>Sharit can submit and maintain your program listings with over 80 software archive and review sites on the Internet, including most popular sites such as Winfiles.com, DaveCentral, Tucows .....<br><br><p><a href="http://www.trellian.com/cgi-bin/msw/entry?id=1663&amp;file=sharit/index.html">MORE INFO...</a></p>', 4.00, '', '', '', '', '', '', '5', '');
INSERT INTO `products` VALUES(9, 'Books', 31.96, 'Essential System Administration (Nutshell Handbook)', '0021.jpg', 'Essential System Administration takes an in-depth look at the fundamentals of UNIX system administration in a real-world, heterogeneous environment. Whether you are a beginner or an experienced administrator, you''ll quickly be able to apply its principles and advice to your everyday problems. <br><br>The book approaches UNIX system administration from the perspective of your job -- the routine tasks and troubleshooting that make up your day. <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/1565921275/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '', 'gift_option.html');
INSERT INTO `products` VALUES(10, 'Books', 68.00, 'UNIX System Administration Handbook', '22.jpg', 'The third edition of Unix System Administration Handbook stands as a fantastic Unix book, perhaps one that''s destined for legend. It''s arguably the best general Unix book around. Don''t delay in getting it, and don''t spend too much time flinching at the price; it''s worth it. If you work with Unix--in any of its flavors--you''ll use this book, and frequently.<br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/0130206016/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '', 'gift_option.html');
INSERT INTO `products` VALUES(11, 'Books', 27.95, 'Running Linux', '0023.jpg', 'Earlier editions of O''Reilly''s Running Linux served as central guides on installing, configuring, and using the OS. The third edition of this guide covers the kernel through version 2.2.1 and will prove especially useful to those with high technical aptitudes and a well-tested willingness to experiment with their computing environments. <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/156592469X/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '', 'gift_option.html');
INSERT INTO `products` VALUES(12, 'Books', 39.99, 'Red Hat Linux 7 Unleashed', '0024.jpg', 'Red Hat Linux 7 Unleashed shows you how to install, configure, and manage version 7, the latest version of Red Hat operating system. Version 7 boasts the latest stable Linux kernel, a new and improved installation program, updated libraries and a host of other improvements, including the new Xfree86 4.x. Learn how the operating system works from the inside out. <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/0672319853/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '2', 'gift_option.html');
INSERT INTO `products` VALUES(13, 'Software', 649.99, 'Dreamweaver UltraDev 4.0/Fireworks 4.0 Studio', '0025.jpg', 'This Macromedia UltraDev 4/Fireworks 4 bundle is an efficient way to develop ASP, JSP, or ColdFusion Web applications. Rapidly build database-driven Web applications with total control over source code, plus integrated Web graphics. Professional hand-coding environment includes ASP, JSP, and CFML keyword color-coding, autoindenting, punctuation balancing, and the ability to debug client-side JavaScript directly in your browser. Create, edit, and animate Web graphics in Fireworks 4; add advanced interactivity; optimize images; and integrate seamlessly with UltraDev 4 for efficient development. View live, server-side data in the workspace, and make edits to layout and logic on the fly. Maximize productivity with built-in server behaviors, the ability to create your own library of reusable server behaviors easily, and powerful shortcuts for creating user authentication, master/detail pages, and more. Improve development efficiency with sitewide reports, project tracking, and integration with version-control systems like Microsoft Visual SourceSafe for Windows and leading content-management systems. <br><br>Quickly connect existing, static Web pages to any database<br>Maintain total control over your source code<br>Easily identify keywords and scripts in code<br>See exactly how layouts will display<br>Maximize productivity with Server Behaviors and Live Objects <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B000050XBE/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '1', '');
INSERT INTO `products` VALUES(14, 'Software', 132.99, 'Microsoft FrontPage 2000', '0026.jpg', 'The Internet offers unprecedented publishing possibilities, allowing anyone with a few hundred bucks and some spare time to bypass the middleman and reach readers, viewers, listeners, and buyers directly. If you want to tap into the power of Web publishing without staying up nights learning HTML, try Microsoft FrontPage 2000.<br><br>Features: <br><br>NOTE: In-Box Upgrade Rebate valid only for previous licensed users of Microsoft Windows 95 or later (see product description for complete list)<br>Allows users to easily create Web sites exactly the way they want<br>Makes site management easy<br>Updates sites quickly<br>Works together with Microsoft Office <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00002SFM4/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '1', '');
INSERT INTO `products` VALUES(15, 'Software', 567.99, 'Adobe Photoshop 6.0', '0027.jpg', 'With each new release of Photoshop, Adobe manages both to satisfy the expectations of existing users and to pull a few magic features out of its hat. Version 6 is no exception. Powerful vector editing and masking, improved layer controls, layer styles, incredible typographic control, new Web publishing tools, and a cleaner, more accessible interface are already making version 5.5, itself a groundbreaker, look like ancient history.<br><br>Image editing software with an extensive toolset and powerful new features<br>Use for graphic and website design, photography and collage, pre-press, and more<br>Easily combine crisp, resolution-independent type with pixel-based images<br>Output sharp type edges with your image to produce high-quality results<br>Includes extensive new type formatting controls to produce the best-looking text <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00004YNJJ/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '3', '');
INSERT INTO `products` VALUES(16, 'Software', 354.99, 'Flash 5.0', '0028.jpg', 'Macromedia''s Flash 5 brings substantial changes and improvements to this dominant player in the Web animation tools arena. A new and customizable interface and improved scripting are the most notable of the new features. These, among other enhancements, make this upgrade almost essential to any serious designer.<br><br>Features: <br><br>Design beautiful, compact Web animation<br>Build intuitive interfaces that maintain branding<br>Produce stand-alone, run-time animation applications<br>Create engaging rich-media advertisements<br>Develop interactive e-commerce Web applications for all Internet-enabled devices <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00004WG0L/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '5', '');
INSERT INTO `products` VALUES(17, 'Software', 273.99, 'Dreamweaver 4.0', '0029.jpg', 'Some folks pour Web code from their soul using nothing more than a simple text editor. Others avoid code altogether by building pages in a WYSIWYG editor''s visual interface. Whatever one''s preferences, Macromedia''s Dreamweaver 4.0 delivers a powerful collection of features for building and maintaining even the most complex sites.<br><br>Features: <br><br>Tools to create a professional Web site<br>New code view<br>JavaScript debugger <br>Integrated O''Reilly code reference<br>New layout view--design complex pages easily <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B000050F96/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '6', '');
INSERT INTO `products` VALUES(18, 'Software', 199.99, 'Adobe Acrobat 4.0', '0030.jpg', 'Adobe Acrobat lets you share information electronically in a quick and effective way. It converts any document--including entire Web sites--into an Adobe PDF file, keeping the original appearance preserved, then allows you to distribute it for viewing and printing on any system. In addition, powerful markup tools make electronic review and collaboration a snap. Do late-stage text and image editing on PDF files or reuse text, graphics, and table data from PDF files. "Overall, Acrobat 4.0 merits a standing ovation." --Luis Camus, PC World, May 1999. <br><br>Features: <br><br>Convert any document to Portable Document Format (PDF)<br>Mark up and annotate PDF documents<br>Create PDF Web forms<br>Integrate PDF files with Web servers and e-mail<br>Retain and print sophisticated PostScript 3 graphics <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B0000205ZI/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '', '');
INSERT INTO `products` VALUES(19, 'Electronics', 419.94, 'Creative Labs Nomad Jukebox (Blue)', '0031.jpg', 'The Creative NOMAD Jukebox is a portable, multiformat, compressed audio player with intuitive navigation for easy categorizing and classifying of content. Measuring about the size of a portable CD player and weighing only 14 ounces, this EAX-certified digital audio player features 6 GB of storage capacity. With far more memory than most portable digital audio players, it stores approximately 100 hours of CD-quality audio (equivalent to about 150 albums) or up to 2,600 hours of spoken word content. Unlike other hard drive-based solutions, the NOMAD Jukebox offers an onboard, real-time digital signal processor for superior audio playback and customization. The NOMAD Jukebox is SDMI-capable and supports file formats such as MP3, WAV, and WMA.<br><br>Features: <br><br>Portable digital audio player with 6 GB of built-in storage (over 100 hours of CD-quality music)<br>Plays MP3 files; upgradable to support other formats (such as WMA) and is SDMI compliant<br>USB interface for fast digital transfer; compatible with Windows and Mac<br>Weighs only 14 ounces and measures the size of a portable CD player<br>Comes with headphones, rechargeable batteries, AC adapter, and carrying pouch <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B000026D6I/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '5', '');
INSERT INTO `products` VALUES(20, 'Electronics', 129.94, 'Linksys BEFSR41 4-Port Etherfast Cable/DSL Router', '0032.jpg', 'Linksys is fast making a name for itself in the networking world and the EtherFast Cable/DSL Instant Broadband Router is one of the reasons why. This router lets you connect a group of PCs (up to 253) to a high-speed broadband Internet connection, but instead of requiring you to buy a separate hub to connect them all, Linksys made the extra effort and built the hub in.<br><br>Features: <br><br>Equipped with an internal, 4-port 10/100 Fast Ethernet switch<br>Connects all your PCs to the Internet using a single IP address<br>Includes a firewall<br>Includes DHCP server or client and supports PPPoE<br>Configurable via Web browser <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00004SB92/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '3', '');
INSERT INTO `products` VALUES(21, 'Electronics', 399.00, 'Palm Vx Handheld', '0033.jpg', 'At only 4.7 by 3.2 inches square and 0.4 inches thick, the Palm Vx connected organizer is truly pocket-size; however, this model sports a hefty 8 MB of RAM. The Palm Vx also sports a sleek exterior that looks supercool--an intangible value to be sure, but one that''s hard to argue with.<br><br>Features: <br><br>8 MB RAM <br>HotSync cradle included <br>Easily transfer data from your handheld to your PC or Macintosh<br>Rechargeable lithium-ion battery<br>Stores thousands of addresses, appointments, to-do items, memos, and more <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B000031KIM/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '1', '');
INSERT INTO `products` VALUES(22, 'Electronics', 44.99, 'GPX C3948BI Blue Ice Ultra-Slim CD Player', '0034.jpg', 'You may not be familiar with the GPX C3948BI CD player, but it''s a great unit and definitely worth your consideration. It''s loaded with useful features, such as 22-track programming and random and repeat play modes. It comes with an adapter kit that lets you plug the player into your car''s cassette player for tunes on the road and a six-digit LCD that shows the track number and time counter. And there''s an impressive 40-second antiskip buffer, which GPX calls an Anti-Rolling System, to keep your tunes from jumping forward when you nudge the player.<br><br>Features: <br><br>Car adapter kit<br>Bass boost system<br>40-second antishock protection<br>Headphones with inline volume control<br>6-digit LCD <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00000JBPB/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '3', '');
INSERT INTO `products` VALUES(23, 'Electronics', 39.57, 'Microsoft IntelliMouse Optical', '0035.jpg', 'The IntelliMouse Optical incorporates all the great features of the IntelliMouse Explorer mouse into its design--optical technology, cool red underglow, titanium accents, and superior performance. It also answers the most common complaints about the Explorer. For example, the two troublesome side buttons that were on the Explorer have been moved--there is one on each side of the IntelliMouse Optical, so both right- or left-handers can now program and use these buttons for any number of functions. In addition, the IntelliMouse Optical''s smaller body is comfortable for people who don''t have large hands.<br><br>Features: <br><br>Optical pointing device for right- or left-handed users<br>5 programmable buttons<br>Provides more control and accuracy than trackball mice can<br>Requires no cleaning or mouse pad<br>IntelliPoint software included <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00004S9AK/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '3', '');
INSERT INTO `products` VALUES(24, 'Electronics', 249.00, 'Hewlett Packard CD-Writer 8230e 4 X 4 X 6 USB External Kit', '0036.jpg', 'Features: <br><br>Compile CDs with 74 minutes of your favorite tunes <br>Convert MP3 files into songs you can listen to anywhere<br>Create discs with powerful and reliable CD creation software<br>Back up data easily with disaster-recovery software<br>2 MB buffer <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B000050AOO/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '3', 'blank.html');
INSERT INTO `products` VALUES(25, 'Electronics', 103.94, '3Com HomeConnect PC Digital Camera', '0037.jpg', 'PC Digital Camera is easy to detach from its 9-foot Universal Serial Bus (USB) connector, so there''s no more fumbling behind your PC. Then you just pop it onto the USB cable on a different PC or laptop and you''re ready to go. The unit adjusts automatically from bright to very dim light. You can see bright, clear images in conditions from full sunlight to hotel light to birthday candles. When you travel on business, what''s better than your kids'' snapshots in your wallet? How about saying good-night to them right from your hotel room? When you can''t visit grandpa across the country, try video e-mail, featuring pictures created by his favorite young artists! With the HomeConnect PC Digital Camera, the Internet is more than a business tool or a big library, it''s a way to share smiles. <br><br>Features: <br><br>Video e-mail, video phone calls, and Webcam functionality<br>Sharp, clear pictures <br>1-touch snapshot button for instant digital photos<br>Automatic light-adjustment feature<br>Portable <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00000JDHV/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '5', '');
INSERT INTO `products` VALUES(26, 'Electronics', 79.99, 'Iomega Zip 100 Portable USB Drive', '0039.jpg', 'The Iomega Zip drive is the low-cost removable storage leader--and Iomega''s two latest offerings, the Zip 250 (a SCSI device) and a USB version of the Zip 100, should help maintain its popularity. The USB drive is designed for Win98; you install the drivers and IomegaWare software first, then reboot your system. We got it installed and performing without a hitch.<br><br>Features: <br><br>USB interface<br>Mac and PC compatible<br>Plug and play<br>Unlimited capacity<br>Each disk holds up to 70 floppies <br><br><p align="center"><a href="http://www.amazon.com/exec/obidos/ASIN/B00000J3Q7/thebookstore03">MORE INFO</a></p>', 4.00, '', '', '', '', '', '', '7', 'blank.html');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) auto_increment,
  `pid` int(11) default '0',
  `rating` int(2) default '0',
  `reviewer` varchar(50),
  `review_location` varchar(50),
  `review_comment` text NOT NULL,
  `helpful` int(11) default '0',
  `count` int(11) default '0',
  `status` varchar(20),
  `time` varchar(15),
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`,`time`),
  KEY `status` (`status`),
  KEY `helpful` (`helpful`,`count`)
);

CREATE TABLE `shipping` (
  `id` int(11) auto_increment,
  `abv` varchar(6),
  `name` varchar(30),
  `price` double(10,2) default '0.00',
  `percent` int(3) default '0',
  `weight` char(3),
  `sub` varchar(20),
  PRIMARY KEY  (`id`),
  KEY `method` (`name`),
  KEY `abv` (`abv`)
);

INSERT INTO `shipping` VALUES(1, 'UPS', 'UPS Ground Shipping', 3.00, 0, 'no', '');
INSERT INTO `shipping` VALUES(2, 'UP3', 'UPS Three Day', 3.00, 5, 'no', '');
INSERT INTO `shipping` VALUES(3, 'UPB', 'UPS Two Day', 3.00, 10, 'no', '');
INSERT INTO `shipping` VALUES(4, 'UPR', 'UPS Overnight', 3.00, 15, 'no', '');

CREATE TABLE `wishlists` (
  `id` int(11) auto_increment,
  `pid` int(11) default '0',
  `email` varchar(100),
  PRIMARY KEY  (`id`),
  KEY `pid` (`pid`,`email`)
);

