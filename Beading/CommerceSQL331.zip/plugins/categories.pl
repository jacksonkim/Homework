
#######################################################################
# Create category list from database
#######################################################################

if ($MASTER =~ /{categories}/)
{
   my ($categories, $query, $sth, $cat_name);

   $query = "SELECT DISTINCT category FROM $table{'products'} ORDER BY category";
	$sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	$sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	while(@row = $sth->fetchrow)
	{
	   $cat_name = $row[0];
	   $cat_name =~ s/_/ /g;

      my $link = &build_link('cart_id'     => $cart_id,
                             'exact_match' => 'yes',
                             'category'    => $row[0]);

		$categories .= qq~<a href="$link">$cat_name</a><br>\n~;
   }
   $sth->finish;

   $MASTER =~ s/{categories}/$categories/g;
}

1;
