#######################################################################
# Create links to all the pages in the pages directory
#######################################################################

my ($hpages, $vpages);

my $link = &build_link('cart_id' => $cart_id);

$vpages = qq~<a href="$link">Home</a><br>\n~;

opendir(PAGES,"$Path/pages") || &update_error_log("Cannot open Directory! $!", __FILE__, __LINE__);
@pnames = readdir(PAGES);

foreach my $filename (sort @pnames)
{
   $pnames = $pname = (split (/\./, $filename))[0];
   $pname =~ s/_/ /g;

   if ($pnames eq "Home")
   {
      next;
   }

   my $link = &build_link('cart_id' => $cart_id,
                          'page'    => $pnames);


   if ($filename =~ /\.html$/)
   {
      push(@hpages, qq~<a href="$link">$pname</a>~);

   } elsif ($filename =~ /\.htm$/) {
      $vpages .= qq~<a href="$link">$pname</a><br>\n~;
   }
}
close (PAGES);

$separator = qq~&nbsp;&#8226;&nbsp;~;

$hpages = join($separator, @hpages);

$MASTER =~ s/{hpages}/$hpages/g;
$MASTER =~ s/{vpages}/$vpages/g;

1;
