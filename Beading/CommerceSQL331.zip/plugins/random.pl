#######################################################################
# Display 3 random products from database
#######################################################################

if ($MASTER =~ /{random}/)
{
   my ($random, $query, $sth);

   $query = "SELECT * FROM $table{'products'} ORDER BY RAND() LIMIT 3";
   # $query = "SELECT rowid,category,price,name,image,rand((rowid)+curtime()+0) as rand FROM $table{'products'} order by rand LIMIT 3";
	$sth = $dbh->prepare($query) || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	$sth->execute || &update_error_log("$query\n$DBI::errstr", __FILE__, __LINE__);
	while(@row = $sth->fetchrow)
	{
	   my $image = $row[$db{'image'}];
	   $image =~ s/%%URLofImages%%//;

      if ($image =~ /.*\"(.*)\".*/)
      {
         $image = $1;
      }

      my $price = &display_price(&format_price($row[$db{'price'}]));

      my $link = &build_link('cart_id'     => $cart_id,
                             'exact_match' => 'yes',
                             'pid'         => $row[$db{'id'}],
                             'category'    => $row[$db{'category'}]);

      $random .= qq~
         <div class="random_data">
         <a href="$link">
         <img src="$config{'image_url'}/product/small/$image" alt="$row[$db{'name'}]" border="0">
         </a><br>
         $row[$db{'name'}]<br>
         Only: $price</div><br>
      ~;
   }
   $sth->finish;

   $MASTER =~ s/{random}/$random/g;
}

1;