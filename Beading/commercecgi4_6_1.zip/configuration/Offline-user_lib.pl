$cc_names = "Visa,MasterCard,Discover,American Express";
$sc_gateway_user_lib_was_loaded = "yes";
1;
