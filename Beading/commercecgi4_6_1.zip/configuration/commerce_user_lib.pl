## This file contains the user specific variables
## necessary for Commerce.cgi

$sc_send_order_to_email =            'yes';
$sc_order_email =                    'test@example.com';
$sc_store_url =                      'http://www.example.com/DEV4/commerce.cgi';
$sc_order_script_url =               'http://www.example.com/DEV4/commerce.cgi';
$sc_admin_email =                    'test@example.com';
$sc_domain_name_for_cookie =         'www.example.com';
$sc_path_for_cookie =                '/DEV4';
$URL_of_images_directory =           'http://www.example.com/DEV4/images';
$manager_image_path =                '../images';
$na_image_if_not_found =             'yes';
$URL_of_secure_images_directory =    'http://www.example.com/DEV4/images';
$images_path =                       './images';
$items_per_page =                    '9';
$site_name =                         'FREE Shopping Cart Software';
$highlightcolor =                    '#235C7A';
$highlightfontcolor =                '#FFFFFF';
$ppage =                             '1';
$template =                          '1';
$sc_money_symbol =                   '$';
$sc_money_symbol_placement =         'front';
$sc_shall_i_email_if_error =         'no';
$sc_shall_i_log_errors =             'yes';
$sc_shall_i_log_accesses =           'no';
$encrypt_key =                       'secret';
$display_cart =                      'yes';
$time_dif =                          '-2';
$new_cart_permissions =                0766;
$set_cart_permissions =              '0766';
1;
