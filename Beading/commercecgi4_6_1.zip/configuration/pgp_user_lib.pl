$sc_use_pgp =              'no';
$pgp_public_key_user_id =  'test@example.com';
$pgp_or_gpg =              'GnuPG';
$pgp_config_files =        '/home/www/.gnupg';
$pgp_server_path =         '/usr/bin/gpg';
$pgp_temp_folder =         '/home/www/public_html/cgi-bin/store/data_files';
1;
