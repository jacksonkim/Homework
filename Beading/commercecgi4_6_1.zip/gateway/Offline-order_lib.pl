#######################################################################
#                    Order Form Definition Variables                  #
#######################################################################

# These are the values that are used by the manager to configure this gateway.

%sc_gateway_settings = ('cc_names', 'Credit Cards Accepted (comma seperated with no spaces)');

# The process variable is the unique variable that is passed by this gateway that tells us
# that it is time to call the process order sub.

$process_variable{'Offline'} = "process_order";

# This tells us what the variable name is that contails the cart id
# when returning from the gateway.

$return_cart_id_variable{'Offline'} = "cart_id";

# Image name and description that will show up on the view cart screen for this gateway.

$check_out_image{'Offline'}  = "complete_order.gif";
$check_out_detail{'Offline'} = "Pay by Credit Card!";

###############################################################################
# Gateway Prep
###############################################################################

sub Offline_gateway_prep
{
   # We set the ship-to address values to be the same as the bill-to values
   # if the ship-to values are blank.

   if (! $form_data{'Ecom_ShipTo_Postal_Street_Line1'})
   {
    $form_data{'Ecom_ShipTo_Postal_Street_Line1'} = $form_data{'Ecom_BillTo_Postal_Street_Line1'};
   }

   if (! $form_data{'Ecom_ShipTo_Postal_City'})
   {
    $form_data{'Ecom_ShipTo_Postal_City'} = $form_data{'Ecom_BillTo_Postal_City'};
   }

   if (! $form_data{'Ecom_ShipTo_Postal_StateProv'})
   {
    $form_data{'Ecom_ShipTo_Postal_StateProv'} = $form_data{'Ecom_BillTo_Postal_StateProv'};
   }

   if (! $form_data{'Ecom_ShipTo_Postal_PostalCode'})
   {
    $form_data{'Ecom_ShipTo_Postal_PostalCode'} = $form_data{'Ecom_BillTo_PostalCode'};
   }

   if (! $form_data{'Ecom_ShipTo_Postal_CountryCode'})
   {
    $form_data{'Ecom_ShipTo_Postal_CountryCode'} = $form_data{'Ecom_BillTo_Postal_CountryCode'};
   }

   if (! $form_data{'Ecom_ShipTo_Postal_Name_First'})
   {
    $form_data{'Ecom_ShipTo_Postal_Name_First'} = $form_data{'Ecom_BillTo_Postal_Name_First'};
   }

   if (! $form_data{'Ecom_ShipTo_Postal_Name_Last'})
   {
      $form_data{'Ecom_ShipTo_Postal_Name_Last'} = $form_data{'Ecom_BillTo_Postal_Name_Last'};
   }

   # These are misc. variables that we need to set up.

   $NAME        = "$form_data{'Ecom_BillTo_Postal_Name_First'} $form_data{'Ecom_BillTo_Postal_Name_Last'}";
   $SHIPNAME    = "$form_data{'Ecom_ShipTo_Postal_Name_First'} $form_data{'Ecom_ShipTo_Postal_Name_Last'}";
   $EXPDATE     = "Month: $form_data{'Ecom_Payment_Card_ExpDate_Month'} Year: $form_data{'Ecom_Payment_Card_ExpDate_Year'}";
   $INVOICE     = $time;
   $DESCRIPTION = "Online Order";

   # These are the variables that need to be passed to the checkout process/gateway
   # The first part is what we want to call the variable when it is passed.
   # The second part is what variable  we are going to use.
   # Pass name, Variable name to use.

   $sc_passthrough_variables->{'NAME'}         =                 'NAME';
   $sc_passthrough_variables->{'SHIPNAME'}     =             'SHIPNAME';
   $sc_passthrough_variables->{'EXPDATE'}      =              'EXPDATE';
   $sc_passthrough_variables->{'INVOICE'}      =              'INVOICE';
   $sc_passthrough_variables->{'SHIPPING'}     =  'pass_final_shipping';
   $sc_passthrough_variables->{'SHIPMETHOD'}   =           'shipMethod';
   $sc_passthrough_variables->{'SALESTAX'}     = 'pass_final_sales_tax';
   $sc_passthrough_variables->{'DISCOUNT'}     =  'pass_final_discount';
   $sc_passthrough_variables->{'SUBTOTAL'}     =        'pass_subtotal';
   $sc_passthrough_variables->{'AMOUNT'}       =     'pass_grand_total';
   $sc_passthrough_variables->{'DESCRIPTION'}  =          'DESCRIPTION';
   $sc_passthrough_variables->{'cart_id'}      =              'cart_id';

   $sc_passthrough_variables->{'misc_var_a'}   =           'misc_var_a';
   $sc_passthrough_variables->{'misc_var_b'}   =           'misc_var_b';
   $sc_passthrough_variables->{'misc_var_c'}   =           'misc_var_c';
   $sc_passthrough_variables->{'misc_var_d'}   =           'misc_var_d';
   $sc_passthrough_variables->{'misc_var_e'}   =           'misc_var_e';

   # This is the same as above but instead of variables we are using $form_data{'values'}
   # for the second part.
   # Pass form name as, Order form name.

   $sc_passthrough_form_data->{'ADDRESS'}       =  'Ecom_BillTo_Postal_Street_Line1';
   $sc_passthrough_form_data->{'CITY'}          =          'Ecom_BillTo_Postal_City';
   $sc_passthrough_form_data->{'STATE'}         =     'Ecom_BillTo_Postal_StateProv';
   $sc_passthrough_form_data->{'ZIP'}           =           'Ecom_BillTo_PostalCode';
   $sc_passthrough_form_data->{'COUNTRY'}       =   'Ecom_BillTo_Postal_CountryCode';
   $sc_passthrough_form_data->{'PHONE'}         = 'Ecom_BillTo_Telecom_Phone_Number';
   $sc_passthrough_form_data->{'EMAIL'}         =         'Ecom_BillTo_Online_Email';
   $sc_passthrough_form_data->{'SHIPTOSTREET'}  =  'Ecom_ShipTo_Postal_Street_Line1';
   $sc_passthrough_form_data->{'SHIPTOCITY'}    =          'Ecom_ShipTo_Postal_City';
   $sc_passthrough_form_data->{'SHIPTOSTATE'}   =     'Ecom_ShipTo_Postal_StateProv';
   $sc_passthrough_form_data->{'SHIPTOZIP'}     =    'Ecom_ShipTo_Postal_PostalCode';
   $sc_passthrough_form_data->{'SHIPTOCOUNTRY'} =   'Ecom_ShipTo_Postal_CountryCode';
   $sc_passthrough_form_data->{'METHOD'}        =           'Ecom_Payment_Card_Type';
   $sc_passthrough_form_data->{'CARDNUM'}       =         'Ecom_Payment_Card_Number';

   # This is a list of the form values on the order form and an actual description of what this
   # field actually is. This is used to display an error message to the screen if this is a
   # required field and it is not filled in.

   $sc_order_form_array->{'Ecom_BillTo_Postal_Name_First'}     =               'First Name';
   $sc_order_form_array->{'Ecom_BillTo_Postal_Name_Last'}      =                'Last Name';
   $sc_order_form_array->{'Ecom_BillTo_Postal_Street_Line1'}   =   'Billing Address Street';
   $sc_order_form_array->{'Ecom_BillTo_Postal_City'}           =     'Billing Address City';
   $sc_order_form_array->{'Ecom_BillTo_Postal_StateProv'}      =    'Billing Address State';
   $sc_order_form_array->{'Ecom_BillTo_PostalCode'}            =      'Billing Address Zip';
   $sc_order_form_array->{'Ecom_BillTo_Postal_CountryCode'}    =  'Billing Address Country';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_Name_First'}     =       'Ship To First Name';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_Name_Last'}      =        'Ship To Last Name';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_Street_Line1'}   =  'Shipping Address Street';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_City'}           =    'Shipping Address City';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_StateProv'}      =   'Shipping Address State';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_PostalCode'}     =     'Shipping Address Zip';
   $sc_order_form_array->{'Ecom_ShipTo_Postal_CountryCode'}    = 'Shipping Address Country';
   $sc_order_form_array->{'upgradeShipping'}                   =          'Shipping Method';
   $sc_order_form_array->{'Ecom_BillTo_Telecom_Phone_Number'}  =             'Phone Number';
   $sc_order_form_array->{'Ecom_BillTo_Online_Email'}          =            'Email Address';
   $sc_order_form_array->{'Ecom_Payment_Card_Type'}            =             'Type of Card';
   $sc_order_form_array->{'Ecom_Payment_Card_Number'}          =              'Card Number';
   $sc_order_form_array->{'Ecom_Payment_Card_ExpDate_Month'}   =    'Card Expiration Month';
   $sc_order_form_array->{'Ecom_Payment_Card_ExpDate_Year'}    =     'Card Expiration Year';

   # This is a list of the required fields on the order form.

   push(@sc_order_form_required_fields, "Ecom_BillTo_Postal_Name_First");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Postal_Name_Last");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Postal_Street_Line1");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Postal_City");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Postal_StateProv");
   push(@sc_order_form_required_fields, "Ecom_BillTo_PostalCode");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Postal_CountryCode");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Telecom_Phone_Number");
   push(@sc_order_form_required_fields, "Ecom_BillTo_Online_Email");
   push(@sc_order_form_required_fields, "upgradeShipping");
   push(@sc_order_form_required_fields, "Ecom_Payment_Card_Type");
   push(@sc_order_form_required_fields, "Ecom_Payment_Card_Number");
   push(@sc_order_form_required_fields, "Ecom_Payment_Card_ExpDate_Month");
   push(@sc_order_form_required_fields, "Ecom_Payment_Card_ExpDate_Year");

   # Fields to replace in templates (Emails, and log files), form post value to replace with.

   $sc_process_order_fields->{'INVOICE'}         =        'INVOICE';
   $sc_process_order_fields->{'cart_id'}         =        'cart_id';
   $sc_process_order_fields->{'NAME'}            =           'NAME';
   $sc_process_order_fields->{'ADDRESS'}         =        'ADDRESS';
   $sc_process_order_fields->{'CITY'}            =           'CITY';
   $sc_process_order_fields->{'STATE'}           =          'STATE';
   $sc_process_order_fields->{'ZIP'}             =            'ZIP';
   $sc_process_order_fields->{'COUNTRY'}         =        'COUNTRY';
   $sc_process_order_fields->{'PHONE'}           =          'PHONE';
   $sc_process_order_fields->{'EMAIL'}           =          'EMAIL';
   $sc_process_order_fields->{'SHIPNAME'}        =       'SHIPNAME';
   $sc_process_order_fields->{'SHIPTOSTREET'}    =   'SHIPTOSTREET';
   $sc_process_order_fields->{'SHIPTOCITY'}      =     'SHIPTOCITY';
   $sc_process_order_fields->{'SHIPTOSTATE'}     =    'SHIPTOSTATE';
   $sc_process_order_fields->{'SHIPTOZIP'}       =      'SHIPTOZIP';
   $sc_process_order_fields->{'SHIPTOCOUNTRY'}   =  'SHIPTOCOUNTRY';
   $sc_process_order_fields->{'SUBTOTAL'}        =       'SUBTOTAL';
   $sc_process_order_fields->{'SHIPPING'}        =       'SHIPPING';
   $sc_process_order_fields->{'SHIPMETHOD'}      =     'SHIPMETHOD';
   $sc_process_order_fields->{'SALESTAX'}        =       'SALESTAX';
   $sc_process_order_fields->{'DISCOUNT'}        =       'DISCOUNT';
   $sc_process_order_fields->{'AMOUNT'}          =         'AMOUNT';
   $sc_process_order_fields->{'METHOD'}          =         'METHOD';
   $sc_process_order_fields->{'EXPDATE'}         =        'EXPDATE';
}

###############################################################################
# Display the order form
###############################################################################

sub Offline_display_order_form
{
   local ($line, $total_quantity, $total_measured_quantity);
   local ($text_of_cart, $hidden_fields_for_cart, $AllshipMethods);
   local ($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

   ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
   $year += 1900;

	# $year = substr($year,2,2);

   $cc_year = $year;

   while ($cc_year <= ($year + 10))
   {
      $cc_years .= "<option>$cc_year</option>\n";
      $cc_year++;

		# if ($cc_year < 10 && substr($cc_year,0,1) ne "0"){$cc_year = "0" . $cc_year;}
   }

   &display_cart_table("orderform");

   for $i (1..6)
   {
      $letter_index = int(rand 994);
      $secret_images .= qq~<img alt="" src="image.cgi?i=$letter_index">~;
      $secret_letter = $rand_key[$letter_index];
      $secret_word .= $secret_letter;
   }

   $hidden_security_key = &hmac_hex($secret_word ."^",$encrypt_key);

   if (!($sc_gateway_user_lib_was_loaded =~ /yes/i))
   {
      require "$sc_configuration_directory_path/Offline-user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/$sc_gateway_name-user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
   }

	open(SHIPPINGFILE, "$sc_log_file_directory_path/shipping.txt") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/shipping.txt", "$!", "print", "FILE OPEN ERROR", "1");
   seek (SHIPPINGFILE,0,0);
	while (<SHIPPINGFILE>)
	{
	   @ship_options = split(/\|/, $_);

#      $tempKey = $ship_options[0];
#      $tempShipAmt = &calculate_shipping($subtotal, $total_measured_quantity);
#      $tempShipAmt = &format_price($tempShipAmt);
#      $tempShipAmt = &display_price($tempShipAmt);
# Add $tempShipAmt to next line

      $AllshipMethods .= "<OPTION VALUE=\"$ship_options[0]|$ship_options[1]\">$ship_options[1]&nbsp;</OPTION>\n";
	}
	close (SHIPPINGFILE);

   @credit_cards = split(/\,/, $cc_names);
   foreach (@credit_cards)
   {
      $cards .= qq~
         <option>$_</option>
      ~;
   }

   print qq~
      <!-- Start Orderform -->
      </FORM>
      <FORM METHOD="POST" ACTION="$sc_order_script_url">
      <INPUT TYPE="hidden" NAME="page" VALUE="$form_data{'page'}">
      <INPUT TYPE="hidden" NAME="cart_id" VALUE="$cart_id">
      <INPUT TYPE="hidden" NAME="gateway" VALUE="Offline">

      <CENTER>

      <TABLE WIDTH="90%" BORDER="0" CELLPADDING="5">

      $Offline_order_form_top1
      $Offline_order_form_top2

      <TR>
      <TD COLSPAN="2" class="colored_cell_header">Billing Address:</TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">First Name</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_BillTo_Postal_Name_First" SIZE="30" MAXLENGTH="30" value="$form_data{'Ecom_BillTo_Postal_Name_First'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_Postal_Name_First_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD class="row_title">Last Name</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_BillTo_Postal_Name_Last" SIZE="30" MAXLENGTH="30" value="$form_data{'Ecom_BillTo_Postal_Name_Last'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_Postal_Name_Last_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Street:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_BillTo_Postal_Street_Line1" SIZE="30" value="$form_data{'Ecom_BillTo_Postal_Street_Line1'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_Postal_Street_Line1_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">City:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_BillTo_Postal_City" SIZE="30" value="$form_data{'Ecom_BillTo_Postal_City'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_Postal_City_error'}&nbsp;</span>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">State/Province/Region:</TD>
      <TD>

      <input type="text" name="Ecom_BillTo_Postal_StateProv" value="$form_data{'Ecom_BillTo_Postal_StateProv'}" size="8">
      <span class="default_small">(US residence enter 2 digit state code)</span>
      <span class="red_comment">$form_data{'Ecom_BillTo_Postal_StateProv_error'}&nbsp;</span>
      </TR>

      <TR>
      <TD class="row_title">Zip/Postal Code:</TD>
      <TD WIDTH="450"><INPUT TYPE="text" NAME="Ecom_BillTo_PostalCode" SIZE="11" MAXLENGTH="11" value="$form_data{'Ecom_BillTo_PostalCode'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_PostalCode_error'}&nbsp;</span></TD>
      </TR>


      <TR>
      <TD WIDTH="100" class="row_title">Country:</TD>
      <TD WIDTH="450">
      <input type="text" name="Ecom_BillTo_Postal_CountryCode" value="$form_data{'Ecom_BillTo_Postal_CountryCode'}" size="2" maxlength="2">
      <span class="red_comment">$form_data{'Ecom_BillTo_Postal_CountryCode_error'}&nbsp;</span>
      </TD>
      </TR>

      <TR>
      <TD COLSPAN="2" class="colored_cell_header">Shipping Address:
        (if different then billing address)</TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">First Name</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_ShipTo_Postal_Name_First" SIZE="30" MAXLENGTH="30" value="$form_data{'Ecom_ShipTo_Postal_Name_First'}">
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_Name_First_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD class="row_title">Last Name</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_ShipTo_Postal_Name_Last" SIZE="30" MAXLENGTH="30" value="$form_data{'Ecom_ShipTo_Postal_Name_Last'}">
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_Name_Last_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Street:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_ShipTo_Postal_Street_Line1" SIZE="30" value="$form_data{'Ecom_ShipTo_Postal_Street_Line1'}">
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_Street_Line1_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">City:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_ShipTo_Postal_City" SIZE="30" value="$form_data{'Ecom_ShipTo_Postal_City'}">
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_City_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">State/Province/Region:</TD>
      <TD><input type="text" name="Ecom_ShipTo_Postal_StateProv" value="$form_data{'Ecom_ShipTo_Postal_StateProv'}" size="8">
      <span class="default_small">(US residence enter 2 digit state code)</span>
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_StateProv_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD class="row_title">Zip/Postal Code:</TD>
      <TD WIDTH="450"><INPUT TYPE="text" NAME="Ecom_ShipTo_Postal_PostalCode" SIZE="11" MAXLENGTH="11" value="$form_data{'Ecom_ShipTo_Postal_PostalCode'}">
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_PostalCode_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Country:</TD>
      <TD WIDTH="450"><input type="text" name="Ecom_ShipTo_Postal_CountryCode" value="$form_data{'Ecom_ShipTo_Postal_CountryCode'}" size="2" maxlength="2">
      <span class="red_comment">$form_data{'Ecom_ShipTo_Postal_CountryCode_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD COLSPAN="2" class="colored_cell_header">Method Of Shipping</TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Shipping</TD>
      <TD WIDTH="450">

      <!-- Shipping Options (Offline-orderform.html-->
      <SELECT NAME="upgradeShipping" size="1">
      <OPTION VALUE="$form_data{'upgradeShipping'}">$shipMethod&nbsp;</OPTION>
$AllshipMethods
      </SELECT>
      <!-- End Shipping Options -->

      <span class="red_comment">$form_data{'upgradeShipping_error'}&nbsp;</span>

      </TD>
      </TR>

      <TR>
      <TD COLSPAN="2" class="colored_cell_header">Phone/Email</TD>
      </TR>


      <TR>
      <TD WIDTH="100" class="row_title">Phone:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_BillTo_Telecom_Phone_Number" SIZE="15" value="$form_data{'Ecom_BillTo_Telecom_Phone_Number'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_Telecom_Phone_Number_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">E-Mail:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_BillTo_Online_Email" size="32" value="$form_data{'Ecom_BillTo_Online_Email'}">
      <span class="red_comment">$form_data{'Ecom_BillTo_Online_Email_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD COLSPAN="2" class="colored_cell_header">Credit Card Information:</TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Card Type:</TD>
      <TD><select size="1" name="Ecom_Payment_Card_Type">
      <option value="$form_data{'Ecom_Payment_Card_Type'}">$form_data{'Ecom_Payment_Card_Type'}&nbsp;</option>
$cards
      </select> <span class="red_comment">$form_data{'Ecom_Payment_Card_Type_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Number:</TD>
      <TD><INPUT TYPE="text" NAME="Ecom_Payment_Card_Number" MAXLENGTH="20" size="20" value="$form_data{'Ecom_Payment_Card_Number'}">
      <span class="red_comment">$form_data{'Ecom_Payment_Card_Number_error'}&nbsp;</span></TD>
      </TR>

      <TR>
      <TD WIDTH="100" class="row_title">Exp. Date: MM/YYYY</TD>
      <TD>



      <SELECT NAME="Ecom_Payment_Card_ExpDate_Month" size="1">
      <OPTION value="$form_data{'Ecom_Payment_Card_ExpDate_Month'}">$form_data{'Ecom_Payment_Card_ExpDate_Month'}&nbsp;</OPTION>
      <OPTION>1</OPTION>
      <OPTION>2</OPTION>
      <OPTION>3</OPTION>
      <OPTION>4</OPTION>
      <OPTION>5</OPTION>
      <OPTION>6</OPTION>
      <OPTION>7</OPTION>
      <OPTION>8</OPTION>
      <OPTION>9</OPTION>
      <OPTION>10</OPTION>
      <OPTION>11</OPTION>
      <OPTION>12</OPTION>
      </SELECT>

      <SELECT NAME="Ecom_Payment_Card_ExpDate_Year" size="1">
      <OPTION value="$form_data{'Ecom_Payment_Card_ExpDate_Year'}">$form_data{'Ecom_Payment_Card_ExpDate_Year'}&nbsp;</OPTION>
      $cc_years
      </SELECT>

      <span class="red_comment">$form_data{'Ecom_Payment_Card_ExpDate_Month_error'}&nbsp; $form_data{'Ecom_Payment_Card_ExpDate_Year_error'}&nbsp;</span>

      </TD>
      </TR>

      <TR>
      <TD WIDTH="100" valign="top" class="colored_cell_header" colspan="2">Security Check:</TD>
      </TR>

      <tr>
      <TD colspan="2" align="center">

<div>$secret_images</div><br>
<INPUT TYPE="hidden" NAME="hidden_security_key" VALUE="$hidden_security_key">
<span class="row_title">
Enter the letters that you see above: <input type="text" name="security_key" size="20">&nbsp;
</span><span class="red_comment">$form_data{'security_key_error'}&nbsp;</span>

      </TD>
      </TR>

      $Offline_order_form_bottom1
      $Offline_order_form_bottom2

      </TABLE>

      <TABLE WIDTH="400">
      <TR>
      <TD WIDTH="400" class="default_text">
      Only one more step! Please click the <strong>Verify Order</strong>
      button below. This will give you the chance to examine your order one last time
      before you actually submit it to be processed.
      </TD>
      </TR>
      </TABLE>

      <INPUT TYPE=submit NAME="submit_order_form_button"  VALUE=" Verify Order "><BR>
      </CENTER>
      </FORM>
      <!-- End Offline-orderform.html -->
   ~;

   &StoreFooter("secure");
}

###############################################################################
# Print Submit Page where they verify the order
###############################################################################

sub Offline_printSubmitPage
{
   local ($back);

   &Offline_gateway_prep;

   if (!($sc_gateway_user_lib_was_loaded =~ /yes/i))
   {
      require "$sc_configuration_directory_path/Offline-user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/$sc_gateway_name-user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
   }

   print qq~
      </FORM>
      <FORM METHOD="POST" ACTION=\"$sc_order_script_url\" onSubmit="return checkClicks()">
      <!--Customer/Order Data-->
      <hr noshade size="1" width="90%">
      <INPUT TYPE="hidden" NAME="gateway" VALUE="Offline">
   ~;

	open (PAGE, "$sc_template_directory_path/confirmation.txt") ||
	&errorcode(__FILE__, __LINE__, "$sc_template_directory_path/confirmation.txt", "$!", "print", "FILE OPEN ERROR", "0");
	while (<PAGE>)
	{
	   $mypage .= $_;
	}
	close (PAGE);

   while ( my ($pass_key, $pass_value) = each(%$sc_passthrough_form_data) )
   {
      print "<INPUT TYPE=\"hidden\" NAME=$pass_key VALUE=\"$form_data{$pass_value}\">\n";
   }

	$encypt_code = "$pass_grand_total $pass_final_shipping $pass_final_discount $pass_final_sales_tax";
	$control     = &hmac_hex($encypt_code, $encrypt_key);
	print "<INPUT TYPE=\"HIDDEN\" NAME=\"control\" VALUE=\"$control\">\n";

	($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

   while ( my ($pass_key, $pass_value) = each(%$sc_passthrough_variables) )
   {
      print "<INPUT TYPE=\"hidden\" NAME=$pass_key VALUE=\"${$pass_value}\">\n";
      $mypage =~ s/\{$pass_key\}/${$pass_value}/g;
   }

	foreach $key (keys(%form_data))
	{
 		$mypage =~ s/\{$key\}/$form_data{$key}/g;
 		if ($key ne "submit_order_form_button" && $key ne "submit_order_form_button.x")
 		{
 		   $back .= "<INPUT TYPE=\"hidden\" NAME=$key VALUE=\"$form_data{$key}\">\n";
 		}
	}

   $back = qq~
      </FORM>
      <FORM METHOD="POST" ACTION=\"$sc_order_script_url\">
      <INPUT TYPE="hidden" NAME="gateway" VALUE="Offline">
      $back
   ~;

	$mypage =~ s/\{highlightfontcolor\}/$highlightfontcolor/g;
	$mypage =~ s/\{highlightcolor\}/$highlightcolor/g;
	$mypage =~ s/\{back\}/$back/g;

   print $mypage;

   print qq~
      </FORM>
   ~;
}
###############################################################

sub Offline_processOrder
{
   local($subtotal, $total_quantity, $total_measured_quantity, $text_of_cart,
         $required_fields_filled_in, $product, $quantity, $options,
         $text_of_confirm_email, $text_of_admin_email, $emailCCnum, $logCCnum,
         $display_counter, $d_counter);

   &Offline_gateway_prep;

	$encypt_code = "$form_data{'AMOUNT'} $form_data{'SHIPPING'} $form_data{'DISCOUNT'} $form_data{'SALESTAX'}";
	$control     = &hmac_hex($encypt_code, $encrypt_key);

	if ($control ne $form_data{'control'})
	{
      &errorcode(__FILE__, __LINE__, "Control number", "Control number does not match", "die", "CONTROL NUMBER MISS MATCH", "9");
	}

   $orderDate = &get_date;

   require "$sc_configuration_directory_path/pgp_user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/pgp_user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");

   if ($sc_use_pgp =~ /yes/i)
   {
      $emailCCnum    = $form_data{'CARDNUM'};
      $logCCnum      = $form_data{'CARDNUM'};
   } else {
      $emailCCnum    = "XXXXXXXX";
      $emailCCnum   .= substr($form_data{'CARDNUM'},8,20);
      $logCCnum      = substr($form_data{'CARDNUM'},0,8);
      $logCCnum     .= "XXXXXXXX";
   }

   ##############################################################
   # Here we generate the html cart header code.
   ##############################################################

   $product_html       .= qq~<tr>~;
   $admin_product_html .= qq~<tr>~;

   $display_counter = 0;
   foreach (@sc_cart_display_fields)
   {
      if ($sc_cart_index_for_display[$display_counter] == $cart{"price"} ||
          $sc_cart_index_for_display[$display_counter] == $cart{"shipping"} ||
          $sc_cart_index_for_display[$display_counter] == $cart{"price_after_options"})
      {
         $product_html .= qq~
            <td bgColor="#000080" align="right">
            <p align="right"><strong><font face="Arial" size="2" color="#FFFFFF">
            $_
            </font></strong>
            </td>
         ~;
      } else {
         $product_html .= qq~
            <td bgColor="#000080" align="left">
            <p align="left"><strong><font face="Arial" size="2" color="#FFFFFF">
            $_
            </font></strong>
            </td>
         ~;
	   }
	   $display_counter++;
   }

   $display_counter = 0;
   foreach (@sc_cart_display_fields)
   {
      if ($sc_cart_index_for_admin_email[$display_counter] == $cart{"price"} ||
          $sc_cart_index_for_admin_email[$display_counter] == $cart{"shipping"} ||
          $sc_cart_index_for_admin_email[$display_counter] == $cart{"price_after_options"})
      {
         $admin_product_html .= qq~
            <td bgColor="#000080" align="right" class="colored_cell_header">$_</td>
         ~;
      } else {
         $admin_product_html .= qq~
            <td bgColor="#000080" align="left" class="colored_cell_header">$_</td>
         ~;
	   }
	   $display_counter++;
   }

   $product_html       .= qq~</tr><tr>~;
   $admin_product_html .= qq~</tr><tr>~;

   ##############################################################
   # Open Cart to generate product information
   ##############################################################

   open (CART, "$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");
   while (<CART>)
	{
   	$cartData++;
   	@cart_fields   = split (/\|/, $_);

   	$cart_fields[$cart{"price"}]               = &display_price(&format_price($cart_fields[$cart{"price"}]));
   	$cart_fields[$cart{"shipping"}]            = &display_price(&format_price($cart_fields[$cart{"shipping"}]));
   	$cart_fields[$cart{"price_after_options"}] = &display_price(&format_price($cart_fields[$cart{"price_after_options"}] * $cart_fields[$cart{"quantity"}]));

#      &subtract_inventory($cart_fields[$cart{"product_id"}], $cart_fields[$cart{"quantity"}]);

      ##############################################################
      # Generate the html version of products for customer email
      ##############################################################

      $admin_display_counter = 0;
      foreach $field (@sc_cart_index_for_display)
      {
         if ($field == $cart{"price"} ||
             $field == $cart{"shipping"} ||
             $field == $cart{"price_after_options"})
         {
            $product_html .= qq~<td vAlign="top" align="right"><font face="Arial" size="2">$cart_fields[$field]</font></td>~;
         } elsif ($field == $cart{"options"}) {
   	      $cart_fields[$field]  =~ s/<br>/ /g;
            $product_html .= qq~</tr><tr><td></td><td vAlign="top" align="left" colspan="$field"><font face="Arial" size="2">$cart_fields[$field]</font></td></tr>~;
         } else {
            $product_html .= qq~<td vAlign="top" align="left"><font face="Arial" size="2">$cart_fields[$field]</font></td>~;
         }
         $admin_display_counter++;
      }

      ##############################################################
      # Generate the html version of products for admin email and log
      ##############################################################

      $display_counter = 0;
      foreach $field (@sc_cart_index_for_admin_html)
      {
         if ($field == $cart{"price"} ||
             $field == $cart{"shipping"} ||
             $field == $cart{"price_after_options"})
         {
            $admin_product_html .= qq~<td vAlign="top" align="right" class="cart_contents">$cart_fields[$field]</td>~;
         } elsif ($field == $cart{"options"}) {
   	      $cart_fields[$field]  =~ s/<br>/ /g;
            $admin_product_html .= qq~</tr><tr><td></td><td vAlign="top" align="left" colspan="$field" class="cart_contents">$cart_fields[$field]</td></tr>~;
         } else {
            $admin_product_html .= qq~<td vAlign="top" align="left" class="cart_contents">$cart_fields[$field]</td>~;
         }
         $display_counter++;
      }

      ##############################################################
      # Generate the text version of products for customer email
      ##############################################################

      $d_counter = 0;
      foreach $field (@sc_cart_index_for_email)
      {
         if ($field == $cart{"price"} ||
             $field == $cart{"shipping"} ||
             $field == $cart{"price_after_options"})
         {
            $product_text .= "$sc_cart_email_fields[$d_counter]\:      $cart_fields[$field]\n";
         } else {
            $product_text .= "$sc_cart_email_fields[$d_counter]\:      $cart_fields[$field]\n";
         }
         $d_counter++;
      }
      $product_text .= "\n";

      ##############################################################
      # Generate the text version of products for admin email and log
      ##############################################################

      $d_counter = 0;
      foreach $field (@sc_cart_index_for_admin_email)
      {
         if ($field == $cart{"price"} ||
             $field == $cart{"shipping"} ||
             $field == $cart{"price_after_options"})
         {
            $admin_product_text .= "$sc_cart_display_admin_email[$d_counter]\:      $cart_fields[$field]\n";
         } else {
            $admin_product_text .= "$sc_cart_display_admin_email[$d_counter]\:      $cart_fields[$field]\n";
         }
         $d_counter++;
      }
      $admin_product_text .= "\n";
	}
   close(CART);

   $display_counter = $display_counter - 2;
   $admin_display_counter = $admin_display_counter - 2;

   if ($cartData)
   {
   	open (EMAIL, "$sc_template_directory_path/email.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/email.txt", "$!", "print", "FILE OPEN ERROR", "0");
    	while (<EMAIL>)
    	{
    	   $text_of_confirm_email .= $_;
    	}
    	close (EMAIL);

   	open (EMAIL, "$sc_template_directory_path/admin_email.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/admin_email.txt", "$!", "print", "FILE OPEN ERROR", "0");
    	while (<EMAIL>)
    	{
    	   $text_of_admin_email .= $_;
    	}
    	close (EMAIL);

   	open (EMAIL, "$sc_template_directory_path/admin_log.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/admin_log.txt", "$!", "print", "FILE OPEN ERROR", "0");
    	while (<EMAIL>)
    	{
    	   $text_of_log .= $_;
    	}
    	close (EMAIL);

      while ( my ($pass_key, $pass_value) = each(%$sc_process_order_fields) )
      {
         if ($pass_key eq 'SUBTOTAL' || $pass_key eq 'SHIPPING' ||
             $pass_key eq 'SALESTAX' || $pass_key eq 'DISCOUNT' || $pass_key eq 'AMOUNT')
         {
            $form_data{$pass_value} = &display_price(&format_price($form_data{$pass_value}));
         }

    		$text_of_confirm_email =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
    		$text_of_admin_email   =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
    		$text_of_log           =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
      }

      while ( my ($pass_key, $pass_value) = each(%$sc_process_custom_order_fields) )
      {
    		$text_of_admin_email   .= "$pass_key\: $form_data{$pass_value}\n";
    		$text_of_log           .= "$pass_key\: $form_data{$pass_value}\n";
      }

    	$text_of_confirm_email =~ s/\{product_text\}/$product_text/g;
    	$text_of_confirm_email =~ s/\{product_html\}/$product_html/g;
    	$text_of_confirm_email =~ s/\{colSpan\}/$display_counter/g;
      $text_of_confirm_email =~ s/\{date\}/$orderDate/g;

    	$text_of_admin_email   =~ s/\{product_text\}/$admin_product_text/g;
    	$text_of_admin_email   =~ s/\{product_html\}/$admin_product_html/g;
    	$text_of_admin_email   =~ s/\{colSpan\}/$d_counter/g;
      $text_of_admin_email   =~ s/\{date\}/$orderDate/g;
      $text_of_admin_email   =~ s/\{emailCCnum\}/$emailCCnum/g;

    	$text_of_log           =~ s/\{product_text\}/$admin_product_text/g;
    	$text_of_log           =~ s/\{product_html\}/$admin_product_html/g;
    	$text_of_log           =~ s/\{colSpan\}/$d_counter/g;
      $text_of_log           =~ s/\{date\}/$orderDate/g;
      $text_of_log           =~ s/\{logCCnum\}/$logCCnum/g;

      if ($sc_use_pgp =~ /yes/i)
      {
         require "$sc_library_directory_path/pgp_lib.pl" ||
         &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/pgp_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");

         $text_of_log = &make_pgp_file($text_of_log, "$pgp_temp_folder/$$.pgp");
         $text_of_log = "\n" . $text_of_log . "\n";

         $text_of_admin_email = &make_pgp_file($text_of_admin_email, "$pgp_temp_folder/$$.pgp");
         $text_of_admin_email = "\n" . $text_of_admin_email . "\n";
      }

      if ($sc_send_order_to_email =~ /yes/i)
      {
         if (!($sc_mail_lib_was_loaded =~ /yes/i))
         {
            require "$sc_mail_lib_path" || &errorcode(__FILE__, __LINE__, "$sc_mail_lib_path", "$!", "die", "FILE REQUIRE ERROR", "8");
         }
         &send_mail($form_data{'EMAIL'}, $sc_order_email, "Commerce.cgi Order: $form_data{'INVOICE'}",$text_of_admin_email);

         if ($sc_order_email_two)
         {
            &send_mail($form_data{'EMAIL'}, $sc_order_email_two, "Commerce.cgi Order: $form_data{'INVOICE'}",$text_of_admin_email);
         }

         if ($sc_order_email_three)
         {
            &send_mail($form_data{'EMAIL'}, $sc_order_email_three, "Commerce.cgi Order: $form_data{'INVOICE'}",$form_data{'AMOUNT'});
         }
      }

      $log_invoice = $form_data{'INVOICE'};
      $log_invoice =~ /([0-9]+)/;
      $log_invoice = $1;

      open (ORDERLOG, "+>>$sc_order_directory_path/$log_invoice") || &errorcode(__FILE__, __LINE__, "INVOICE $log_invoice", "$!", "print", "ERROR SAVING ORDER TO SERVER", "4");
      print ORDERLOG $text_of_log;
      close (ORDERLOG);

      chmod ($new_cart_permissions, "$sc_order_directory_path/$log_invoice");

      if (!($sc_mail_lib_was_loaded =~ /yes/i))
      {
         require "$sc_mail_lib_path" || &errorcode(__FILE__, __LINE__, "$sc_mail_lib_path", "$!", "die", "FILE REQUIRE ERROR", "8");
      }
   	&send_mail($sc_admin_email, $form_data{'EMAIL'}, "Thank you for your order!", "$text_of_confirm_email");

      # This empties the cart after the order is successful

      open (CART, ">$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR: ERROR CLEARING SHOPPING CART!", "0");
      close (CART);
      unlink $sc_cart_path;
   }

   # First, we output the header of
   # the processing of the order

   &StoreHeader("Thank you for your order","secure");

   open (THANKYOU, "$sc_template_directory_path/thankyou.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/thankyou.txt", "$!", "print", "FILE OPEN ERROR", "0");
   while (<THANKYOU>)
   {
      $thankyou_page .= $_;
   }
   close (THANKYOU);

   while ( my ($pass_key, $pass_value) = each(%$sc_process_order_fields) )
   {
 		$thankyou_page =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
   }

   $thankyou_page =~ s/\{scriptURL\}/$sc_store_url/g;

   print $thankyou_page;

   # and the footer is printed

   &StoreFooter("secure");

} # End of process_order_form

#################################################################

1;
