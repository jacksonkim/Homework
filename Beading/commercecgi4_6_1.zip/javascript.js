<!-- This script will validate that the required fields are set  -->
<!-- Begin
function fixElement(element, message) {
alert(message);
element.focus();
}

function isFormReady(form) {
var passed=false;
if (form.keywords.value == "") {
fixElement(form.keywords, "Please enter something to search for!");
}

else {
passed=true;
}
return passed;
}
function ViewCrossReference (selSelectObject)
{
if(selSelectObject.options[selSelectObject.selectedIndex].value != "")
{
location.href=selSelectObject.options[selSelectObject.selectedIndex].value
}
}

var popUpWin=0;
function popUpWindow(URLStr, width, height)
{
   var left = (screen.width - width) / 2;
   var top = (screen.height - height) / 2;
   popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=no,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}
// End -->