$sc_use_ip = "no";

#######################################################################
# Set the cart_id and path
#######################################################################

sub set_cart_id
{
   my ($junk, $check_time, $ip, $cart_time);

   if ($form_data{$return_cart_id_variable{$gateway}})
   {
      $cart_id = $form_data{$return_cart_id_variable{$gateway}};
   } else {

      $ip         = $ENV{'REMOTE_ADDR'};
      $ip         =~ /([0-9]{1,4})\.([0-9]{1,4})\.([0-9]{1,4})\.([0-9]{1,4})/;
      $ip         = "$1.$2.$3.$4";
      $ip         = "" if ($ip eq '...');
      $sc_ip_path = "$Path/shopping_carts/$ip";

      if ($form_data{'cart_id'} eq "" && $cookie{'cart_id'} eq "" && $sc_use_ip eq "yes")
      {
         if (-f "$sc_ip_path")
         {
         	require "$sc_ip_path" || &errorcode(__FILE__, __LINE__, "$sc_ip_path", "$!", "ignore", "FILE REQUIRE ERROR", "8");
         }
      }

      if ($form_data{'cart_id'} eq "")
      {
         $form_data{'cart_id'} = $cookie{'cart_id'};
      }

      ($cart_time, $junk) = split(/\./, $form_data{'cart_id'});
      $check_time = $time - 86400;

      if ($cart_time < $check_time)
      {
         $form_data{'cart_id'} = "";
      }

      $cart_id = $form_data{'cart_id'};

      if ($cart_id eq "")
      {
         &delete_old_carts;
         &assign_a_unique_shopping_cart_id;
      }
   }

   $cart_id =~ /([0-9]+)\.([0-9]+)/;
   $cart_id = "$1.$2";
   $cart_id = "" if ($cart_id eq ".");
   if (! $OS =~ /Win/i)
   {
      $cart_id =~ s/^\/+//; # Get rid of any residual / prefix
   }

   $sc_cart_path = "$Path/shopping_carts/$cart_id";

   # Make sure that the cart_id starts with a digit.
   if (substr($cart_id, 0, 1) =~ /\D/)
   {
      print "Content-type: text/html\n";
      &errorcode(__FILE__, __LINE__, "$cart_id", "$!", "die", "CART ID ERROR", "10");
   }
}

#######################################################################
# Delete Old Carts.
#######################################################################

sub delete_old_carts
{
   local ($sc_number_days_keep_old_carts, $cart, $sc_cart_path);

   $sc_number_days_keep_old_carts = .5;

   opendir (USER_CARTS, "$sc_carts_directory_path") || &errorcode(__FILE__, __LINE__, "$sc_carts_directory_path", "$!", "print", "OPENDIR ERROR", "3");
   @carts = grep(/\.[0-9]/,readdir(USER_CARTS));
   closedir (USER_CARTS);

   foreach $cart (@carts)
   {
      if (-M "$sc_carts_directory_path/$cart" > $sc_number_days_keep_old_carts)
      {
         $cart =~ /(.*)/;
         $cart = $1;
         $sc_cart_path = "$sc_carts_directory_path/$cart";
         unlink("$sc_cart_path");
      }
   }
}

#######################################################################
#                        Assign a Shopping Cart.                      #
#######################################################################

sub assign_a_unique_shopping_cart_id
{
   my ($new_access);
   local ($date, $remote_addr, $request_uri, $http_user_agent);
   local ($http_referer, $cart_count);

   if ($sc_shall_i_log_accesses eq "yes")
   {
      $date = &get_date;
      &get_file_lock("$sc_log_file_directory_path/access.log.lockfile");
      open (ACCESS_LOG, ">>$sc_log_file_directory_path/access.log") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/access.log", "$!", "ignore", "FILE OPEN ERROR", "0");

      $remote_addr = $ENV{'REMOTE_ADDR'};
      $request_uri = $ENV{'REQUEST_URI'};
      $http_user_agent = $ENV{'HTTP_USER_AGENT'};

      if ($ENV{'HTTP_REFERER'} ne "")
      {
         $http_referer = $ENV{'HTTP_REFERER'};
      } else {
         $http_referer = "possible bookmarks";
      }

#      $remote_host = $ENV{'REMOTE_HOST'};
#      chop ($shortdate);

      $new_access = "$form_data{'url'}\|$date\|$request_uri\|$cookie{'visit'}\|$remote_addr\|$http_user_agent\|$http_referer\|$time\|";

      chop $new_access;
      print ACCESS_LOG "$new_access\n";
      close (ACCESS_LOG);

      &release_file_lock("$sc_log_file_directory_path/access.log.lockfile");

   }

#   srand (time|$$);

   # $cart_id = int(rand(10000000));
   # $cart_id .= ".$$";

   $cart_id = time . "." . substr($$, 0, 3);

#   $cart_id =~ s/-//g;

   $sc_cart_path = "$sc_carts_directory_path/$cart_id";

   $cart_count = 0;

   while (-e "$sc_cart_path")
   {
      if ($cart_count == 3)
      {
         &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "COULD NOT CREATE UNIQUE CART ID", "5");
         exit;
      }

#       $cart_id = int(rand(10000000));
#       $cart_id .= "_.$$";
      $cart_id = time . "." . substr($$, 0, 3);
#      $cart_id =~ s/-//g;

      $sc_cart_path = "$sc_carts_directory_path/$cart_id";
      $cart_count++;

   } # End of while (-e $sc_cart_path)

#   $form_data{'cart_id'} = $cart_id;
   if ($ENV{'HTTP_USER_AGENT'} =~ /http\:\/\//i && $ENV{'HTTP_USER_AGENT'} !~ /BSALSA/i)
   {
      $cart_id = "";
      $form_data{'cart_id'} = "";
   } else {

      &SetCookies;

      if ($sc_use_ip eq "yes")
      {
      	open(FILE, ">$sc_ip_path") || &errorcode(__FILE__, __LINE__, "$sc_ip_path", "$!", "ignore", "FILE OPEN ERROR", "0");
      	print(FILE "\$form_data{'cart_id'} =\"$cart_id\";\n1\;\n");
      	close(FILE);
   	}
   }
}

#######################################################################
#                    Add to Shopping Cart                             #
#######################################################################

sub add_to_the_cart
{
   my ($control, $item, $cart_item, $x, $duplicate_id, $product_check, $option_check);

   $form_data{'unique_cart_line_id'} = 100;

   if (($form_data{'quantity'} =~ /\D/) || ($form_data{'quantity'} == 0))
   {
      &StoreHeader("Error","regular");

      print qq~
         <CENTER>
         <TABLE WIDTH="500">
         <TR>
         <TD class="default_text">
         I'm sorry, it appears that you did not enter a valid numeric
         quantity (whole numbers greater than zero). Please use your
         browser's Back button and try again. Thanks\!
         </TD>
         </TR>
         </TABLE>
         </CENTER>
      ~;

      &StoreFooter("regular");
      exit;
   }

   if ($form_data{'product_id'} ne "00")
   {
      $item = qq~$form_data{'name'} $form_data{'price'} $form_data{'shipping'}~;
      $control = &hmac_hex($item, $encrypt_key);
      if ($control ne $form_data{'control'})
      {
         &errorcode(__FILE__, __LINE__, "Control number", "Control number does not match", "die", "CONTROL NUMBER MISS MATCH", "9");
      }
   } else {
      $form_data{'name'} = "AUCTION: $form_data{'name'}";

      unless ($form_data{'price'} =~ /^\d+(\.\d{0,2})?$/)
      {
         &StoreHeader("Error","regular");

         print qq~
            <CENTER>
            <TABLE WIDTH="500">
            <TR>
            <TD class="default_text">
            I'm sorry, it appears that you did not enter a valid price.
            Please use your browser's Back button and try again. Thanks\!
            </TD>
            </TR>
            </TABLE>
            </CENTER>
         ~;

         &StoreFooter("regular");
         exit;
      }
   }

   my $use_option_labels = "yes";

   for $x (1..$form_data{'option_count'})
   {
      if ($form_data{"option$x"})
      {
         ($option_name, $option_price, $option_control1) = split (/\|/,$form_data{"option$x"});
         if($option_name)
         {
            if ($option_price)
            {
               $control_item    = "$option_name $option_price";
               $option_control2 = &hmac_hex($control_item, $encrypt_key);

               if ($option_control1 ne $option_control2)
               {
                  &errorcode(__FILE__, __LINE__, "Control number", "Option file control number does not match", "die", "OPTION CONTROL NUMBER MISS MATCH", "9");
               }
            }

            if ($form_data{"label$x"})
            {
               $option_label = qq~$form_data{"label$x"}: ~;
            } else {
               $option_label = "";
            }

            if ($option_price)
            {
               if ($option_price =~ /\%/)
               {
                  $option_price = $form_data{'price'} * $option_price;
               }

               $option_display_price = &display_price(&format_price($option_price));
               $form_data{'options'} .= "$option_label$option_name (+ $option_display_price)<br>";
            } else {
               $form_data{'options'} .= "$option_label$option_name<br>";
            }
         }
         $option_grand_total += $option_price;
      }
   }

	if (-f "$sc_cart_path")
	{
	   open (CART, "$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");
	   while (<CART>)
	   {
	      chomp $_;
	      my @row = split (/\|/, $_);
	      my $item_number = pop (@row);
	      $product_check  = $row[$cart{"product_id"}];
	      $option_check   = $row[$cart{"options"}];
	      if ($item_number > $form_data{'unique_cart_line_id'})
	      {
	         $form_data{'unique_cart_line_id'} = $item_number;
	      }

	      if ($product_check eq $form_data{'product_id'} && $option_check eq $form_data{'options'})
	      {
	         $duplicate_id = $item_number;
	      }

	   }
	   close (CART);
	}

   $form_data{'unique_cart_line_id'}++;

   $form_data{'price_after_options'} = $form_data{'price'} + $option_grand_total;

   foreach $cart_item (@sc_cart_items)
   {
      $cart_row .= "$form_data{$cart_item}\|";
   }

   if ($duplicate_id)
   {
      open (CART, "<$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");

      while (<CART>)
      {
         @database_row    = split (/\|/, $_);
         if ($database_row[$cart{"unique_cart_line_id"}] eq $duplicate_id)
         {
            $database_row[$cart{"quantity"}] += $form_data{'quantity'};
            $shopper_row .= join("\|", @database_row);
         } else {
            $shopper_row .= $_;
         }
      }
      close (CART);

      open (CART, ">$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");
      print CART "$shopper_row";
      close (CART);

   } else {
      open (CART, ">>$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");
      print CART "$cart_row\n";
      close (CART);
   }

   chmod ($new_cart_permissions, $sc_cart_path);

   if ($display_cart eq "yes" || $form_data{'viewOrder'} eq "yes")
   {
      &display_cart_table("");
      &cart_footer;
   } else {
      &create_html_page_from_db;
   }
}

#######################################################################
#                Modify Quantity of Items in the Cart                 #
#######################################################################

sub modify_quantity_of_items_in_cart
{
   local ($qtest, $key, $database_row, $cart_row_number, $old_quantity);
   local ($item, $shopper_row, $quantity_modified);

   @incoming_data = keys (%form_data);

   foreach $key (@incoming_data)
   {
      if ($key =~ /\d/ && $form_data{$key} =~ /^\d+$/)
      {
         push (@modify_items, $key);
      }
   }

   open (CART, "<$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");

   while (<CART>)
   {
      chomp $_;
      @database_row = split (/\|/, $_);
      $cart_row_number = $database_row[$cart{"unique_cart_line_id"}];
      $old_quantity    = $database_row[$cart{"quantity"}];

      foreach $item (@modify_items)
      {
         if ($item eq $cart_row_number && $form_data{$item} > 0)
         {
            $database_row[$cart{"quantity"}] = $form_data{$item};

            foreach $field (@database_row)
            {
               $shopper_row .= "$field\|";
            }
            $shopper_row .= "\n";
            $quantity_modified = "yes";
         }

         # This next part will allow for '0' quantity to delete this item.

         if ($item eq $cart_row_number && $form_data{$item} == 0)
         {
            $quantity_modified = "yes";
         }
      }

      if ($quantity_modified ne "yes")
      {
         $shopper_row .= "$_\n";
      }

      $quantity_modified = "";
   }

   close (CART);

   open (CART, ">$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");
   print CART "$shopper_row";
   close (CART);

   &display_cart_table("");
   &cart_footer;
}

#######################################################################
#                 Delete Item From Cart                               #
#######################################################################

sub delete_from_cart
{
   local ($key, $cart_row_number, $item, $delete_item, $shopper_row);

   @incoming_data = keys (%form_data);

   foreach $key (@incoming_data)
   {
      unless ($key =~ /[\D]/)
      {
         if ($form_data{$key} ne "")
         {
            push (@delete_items, $key);
         }
      }
   }

   open (CART, "<$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "noprint", "FILE OPEN ERROR", "0");

   while (<CART>)
   {
      @database_row    = split (/\|/, $_);

      $cart_row_number = $database_row[$cart{"unique_cart_line_id"}];

      $delete_item = "";
      foreach $item (@delete_items)
      {
         if ($item eq $cart_row_number)
         {
            $delete_item = "yes";
         }
      }

      if ($delete_item ne "yes")
      {
         $shopper_row .= $_;
      }
   }

   close (CART);

   open (CART, ">$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "noprint", "FILE OPEN ERROR", "0");
   print CART "$shopper_row";
   close (CART);

   &display_cart_table("");
   &cart_footer;
}

1;