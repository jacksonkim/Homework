
$sc_db_lib_was_loaded = "yes";

############################################################
# check_db_with_product_id
############################################################

sub check_db_with_product_id
{
	local($product_id, $product_name, $product_price) = @_;
	local($db_product_id, $db_row_found, $db_cart_error, *db_row);

   $db_row_found = "no";

  	open(DATAFILE, "$sc_log_file_directory_path/products.txt") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/data.file", "$!", "print", "FILE OPEN ERROR", "0");
	while (($line = <DATAFILE>) && ($product_id ne $db_product_id))
	{
		@db_row = split(/\|/,$line);
		$db_product_id    = $db_row[$db{"product_id"}];
		$db_product_name  = $db_row[$db{"name"}];
      $db_product_price = $db_row[$db{"price"}];
      $db_row_found     = "yes";
	}
	close (DATAFILE);

	if ($db_row_found eq "no")
	{
      $cart_error .= qq~
         <div class="default_text">
         One of the products in your shopping cart no longer exists in our product database.<br>
         Your order cannot be processed without this validation.<br><br>
         PRODUCT ID: $product_id<br>
         PRODUCT NAME: $product_name<br><br>
         Please contact the
         <a href=mailto:$sc_admin_email>site administrator with questions</a>.
         </div>
      ~;
   } elsif ($db_row[$db{"name"}] ne $product_name) {
      $cart_error .= qq~
         <div class="default_text">
         The name of one of the products in your cart does not match the name in our database!<br>
         Your order cannot be processed without this validation.<br><br>
         PRODUCT NAME: $product_name<br>
         DATABASE NAME: $db_row[$db{"name"}]<br><br>
         Please contact the
         <a href=mailto:$sc_admin_email>site administrator with questions</a>.
         </div>
      ~;
	} elsif ($db_row[$db{"price"}] ne $product_price) {
      $cart_error .= qq~
         <div class="default_text">
         The price of one of the items in your shopping cart did not match the price in our database! <br>
         Your order cannot be processed without this validation.<br>
         PRODUCT: $product_name<br><br>
         PRODUCT PRICE: $product_price<br>
         DATABASE PRICE: $db_row[$db{"price"}]<br><br>
         Please contact the
         <a href=mailto:$sc_admin_email>site administrator with questions</a>.
         </div>
      ~;
	}

	return ($cart_error);
}

############################################################
# submit_query
############################################################

sub submit_query
{
	local(*database_rows) = @_;
	local($status);
	local(@fields);
	local($row_count);
	local(@not_found_criteria);
	local($line); # Read line from database

	local($exact_match) = $form_data{'exact_match'};
	local($case_sensitive) = $form_data{'case_sensitive'};

	$row_count = 0;

	open(DATAFILE, "$sc_log_file_directory_path/products.txt") ||
   &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/products.txt", "$!", "print", "FILE OPEN ERROR", "0");

	while($line = <DATAFILE>)
  	{
		chop($line);
    	@fields = split(/\|/, $line);

    	$not_found = 0;
    	foreach $criteria (@sc_db_query_criteria)
    	{
      	$not_found += &flatfile_apply_criteria($exact_match, $case_sensitive, *fields, $criteria);
    	}

    	if ($not_found == 0)
    	{
      	unshift(@database_rows, join("\|", @fields));
			$row_count++;
		}
	}

	close (DATAFILE);

	if ($row_count > $items_per_page)
	{
		$status = "max_rows_exceeded";
	}

	if ($row_count == 0)
	{
		&PrintNoHitsBodyHTML;
	}

	return($status,$row_count);
}

############################################################
# flatfile_apply_criteria
############################################################

sub flatfile_apply_criteria
{
  local($exact_match, $case_sensitive, *fields, $criteria) = @_;

	local($c_name, $c_fields, $c_op, $c_type);
	# array of c_fields
	local(@criteria_fields);
	# flag for whether we found something
	local($not_found);
	# Value for form field
	local($form_value);
	# Value for db field
	local($db_value);
	# Date Comparison Place holders
	local($month, $year, $day);
	local($db_date, $form_date);
	# Place marker for current database
	# field index we are looking at
	local($db_index);
	# list of words in a string for matching
	local(@word_list);

	# Get criteria information
	($c_name, $c_fields, $c_op, $c_type) = split(/\|/, $criteria);

	@criteria_fields = split(/,/,$c_fields);

	# We get the value of the form.

	$form_value = $form_data{$c_name};

	if ($form_value eq "")
	{
		return 0;
	}

	if (($c_type =~ /date/i) || ($c_type =~ /number/i) || ($c_op ne "="))
	{
		$not_found = "yes";

		foreach $db_index (@criteria_fields)
		{
			$db_value = $fields[$db_index];

			if ($c_type =~ /date/i)
			{
        		($month, $day, $year) = split(/\//, $db_value);
        		$month = "0" . $month if (length($month) < 2);
        		$day = "0" . $day if (length($day) < 2);
        		if ($year > 50 && $year < 1900)
        		{
          		$year += 1900;
        		}
        		if ($year < 1900)
        		{
          		$year += 2000;
        		}
        		$db_date = "$year$month$day";

        		($month, $day, $year) = split(/\//, $form_value);
        		$month = "0" . $month if (length($month) < 2);
        		$day = "0" . $day if (length($day) < 2);
            if ($year > 50 && $year < 1900)
            {
               $year += 1900;
            }
            if ($year < 1900)
            {
               $year += 2000;
            }
            $form_date = "$year $month $day";

            if ($c_op eq ">")
            {
               return 0 if ($form_date > $db_date);
            }
            if ($c_op eq "<")
            {
               return 0 if ($form_date < $db_date);
            }
            if ($c_op eq ">=")
            {
               return 0 if ($form_date >= $db_date);
            }
            if ($c_op eq "<=")
            {
               return 0 if ($form_date <= $db_date);
            }
            if ($c_op eq "!=")
            {
               return 0 if ($form_date != $db_date);
            }
            if ($c_op eq "=")
            {
               return 0 if ($form_date == $db_date);
            }

         } elsif ($c_type =~ /number/i) {
            if ($c_op eq ">")
            {
               return 0 if ($form_value > $db_value);
            }
            if ($c_op eq "<")
            {
               return 0 if ($form_value < $db_value);
            }
            if ($c_op eq ">=")
            {
               return 0 if ($form_value >= $db_value);
            }
            if ($c_op eq "<=")
            {
               return 0 if ($form_value <= $db_value);
            }
            if ($c_op eq "!=")
            {
               return 0 if ($form_value != $db_value);
            }
            if ($c_op eq "=")
            {
               return 0 if ($form_value == $db_value);
            }

         } else { # $c_type is a string
            if ($c_op eq ">")
            {
               return 0 if ($form_value gt $db_value);
            }
            if ($c_op eq "<")
            {
               return 0 if ($form_value lt $db_value);
            }
            if ($c_op eq ">=")
            {
               return 0 if ($form_value ge $db_value);
            }
            if ($c_op eq "<=")
            {
               return 0 if ($form_value le $db_value);
            }
            if ($c_op eq "!=")
            {
               return 0 if ($form_value ne $db_value);
            }
         }
      }
   } else {

   	@word_list = split(/\s+/,$form_value);

      if ($c_name eq 'keywords')
      {
         for ($x=0;$x<=$#word_list;$x++)
         {
            $word_list[$x] = quotemeta($word_list[$x]);
         }
      }

      foreach $db_index (@criteria_fields)
      {
         $db_value = $fields[$db_index];
         $not_found = "yes";

         local($match_word) = "";
         local($x) = "";

         if ($case_sensitive =~ /on/i)
         {
            if ($exact_match =~ /on/i)
            {
               for ($x = @word_list; $x > 0; $x--)
               {
                  # \b matches on word boundary
                  $match_word = $word_list[$x - 1];
                  if ($db_value =~ /\b$match_word\b/)
                  {
                     splice(@word_list,$x - 1, 1);
                  } # End of If
               } # End of For Loop
            } else {
               for ($x = @word_list; $x > 0; $x--)
               {
                  $match_word = $word_list[$x - 1];
                  if ($db_value =~ /$match_word/)
                  {
                     splice(@word_list,$x - 1, 1);
                  } # End of If
               } # End of For Loop
            } # End of ELSE
         } else {
            if ($exact_match eq "on")
            {
               for ($x = @word_list; $x > 0; $x--)
               {
                  # \b matches on word boundary
                  $match_word = $word_list[$x - 1];
                  if ($db_value =~ /\b$match_word\b/i)
                  {
                     splice(@word_list,$x - 1, 1);
                  } # End of If
               } # End of For Loop
            } else {
               for ($x = @word_list; $x > 0; $x--)
               {
                  $match_word = $word_list[$x - 1];
                  if ($db_value =~ /$match_word/i)
                  {
                     splice(@word_list,$x - 1, 1);
                  } # End of If
               } # End of For Loop
            } # End of ELSE
         }
      } # End of foreach $db_index

      if (@word_list < 1)
      {
         $not_found = "no";
      }

   } # End of case 3

   if ($not_found eq "yes")
   {
      return 1;
   } else {
      return 0;
   }
}

1;
