############################################################
# Get Cookie
############################################################

sub get_cookie
{
   local($chip, $val);
   foreach (split(/; /, $ENV{'HTTP_COOKIE'}))
   {
      s/\+/ /g;
      ($chip, $val) = split(/=/,$_,2);
      $chip =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
      $val =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
      $cookie{$chip} .= "\1" if (defined($cookie{$chip}));
      $cookie{$chip} .= $val;
   }
}

############################################################
# Set Cookies
############################################################

sub SetCookies
{
   local(@days) = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
   local(@months) = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
   local($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime($time);

   $cookie{'cart_id'} = "$cart_id";

   $sec = "0" . $sec if $sec < 10;
   $min = "0" . $min if $min < 10;
   $hour = "0" . $hour if $hour < 10;
   local(@secure) = ("","secure");

   $year += 1901;
   $expires = "expires\=$days[$wday], $mday-$months[$mon]-$year $hour:$min:$sec GMT";
   $secure = "0";
   local($key);
   foreach $key (keys %cookie)
   {
      $cookie{$key} =~ s/ /+/g;
      print "Set-Cookie: $key\=$cookie{$key}; $expires; path\=$sc_path_for_cookie; domain\=$sc_domain_name_for_cookie; $secure[$sec]\n";
   }
}

1;