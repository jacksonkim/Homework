################################################################################
#                     CREDIT_CARD_VALIDATION_LIB.PL v1.1
#
# Main Procedures:
#   validate_credit_card_information - This routine validates submitted credit
#                                      card information.
#
#   validate_credit_card_name - This routine validates that the name of the
#                               credit card is one that can be processed by this
#                               library.  (VISA, MASTERCARD, AMERICAN EXPRESS,
#                               DISCOVER)
#
#   validate_credit_card_number - This routine validates that the credit card
#                                 number is valid.
#
#   validate_credit_card_expiration_date - This routine verifies that the credit
#                                          card has not expired.
#
################################################################################

################################################################################
# validate_credit_card_information
################################################################################

sub validate_credit_card_information
{
   local($credit_card_name, $credit_card_number, $credit_card_expiration_date) = @_;
   local($invalid);

   # Convert $credit_card_name to upper case for matching purposes later.
   $credit_card_name = "\U$credit_card_name\E";

   $invalid = &validate_credit_card_name($credit_card_name);

   if($invalid)
   {
      $error{1} = qq~Card type $credit_card_name not supported.~;

      $form_data{'Ecom_Payment_Card_Type_error'} = $error{1};

      # Return the error code and message.
      return(%error);
   }

   $invalid = &validate_credit_card_number($credit_card_name,$credit_card_number);

   if($invalid)
   {
      $error{2} = "$credit_card_number is not a valid number for $credit_card_name.";
      $form_data{'Ecom_Payment_Card_Number_error'} = $error{2};

      # Return the error code and message.
      return(%error);
   }

   $invalid = &validate_credit_card_expiration_date($credit_card_expiration_date);

   if($invalid)
   {
      $error{3} = "That credit card has expired.";
      $form_data{'Ecom_Payment_Card_ExpDate_Month_error'} = $error{3};
      # Return the error code and message.
      return(%error);
   }

   # Error is a misnomer here, but error code zero usually means success.

   $error{0} = "Credit card $credit_card_name: $credit_card_number $credit_card_expiration_date passed validation.";

   # Return the success code and message.
   %error;
}

################################################################################
# validate_credit_card_name
################################################################################

sub validate_credit_card_name
{
  local($credit_card_name) = @_;
  local($invalid);

  # Cards that this routine will accept.
  @valid_credit_cards = ("VISA", "MASTERCARD", "AMERICAN EXPRESS", "DISCOVER");

  foreach $valid_credit_card (@valid_credit_cards)
  {
    if($credit_card_name eq $valid_credit_card)
    {
      return(0); # Credit Card Name is Valid.
    }
  }
  return(1); # Error 1: Credit Card Type Cannot be Processed.
}

################################################################################
# validate_credit_card_number
################################################################################

sub validate_credit_card_number
{
  local($credit_card_name, $credit_card_number) = @_;
  local($credit_card_number_length, $digit_times_two, $digit,
        @credit_card_number_digit, $validation_number);

  # Remove dashes and spaces from $credit_card_number.
  $credit_card_number =~ s/-//g;
  $credit_card_number =~ s/ //g;
  $credit_card_number_length = length($credit_card_number);

  # Make sure that only numbers exist
  if(!($credit_card_number =~ /^[0-9]*$/))
  {

    return(1); # Error 1: Invalid Characters in Credit Card Number.

  }

  # Check for correct number of digits for each credit card type.
  if($credit_card_name eq "VISA" &&
     ($credit_card_number_length != 13 && $credit_card_number_length != 16))
  {

    return(2); # Error 2: Invalid Number of Digits for Given Credit Card.

  }
  elsif($credit_card_name eq "MASTERCARD" &&
        $credit_card_number_length != 16)
  {

    return(2); # Error 2: Invalid Number of Digits for Given Credit Card.

  }
  elsif($credit_card_name eq "AMERICAN EXPRESS" &&
        $credit_card_number_length != 15)
  {

    return(2); # Error 2: Invalid Number of Digits for Given Credit Card.

  }
  elsif($credit_card_name eq "DISCOVER" &&
        $credit_card_number_length != 16)
  {

    return(2); # Error 2: Invalid Number of Digits for Given Credit Card.

  }

  # Step 1.
  @credit_card_number_digit = split(/ */, reverse($credit_card_number));

  # Step 2.
  for($digit_position = 1; $digit_position < $credit_card_number_length;
      $digit_position += 2)
  {

    $digit_times_two = ($credit_card_number_digit[$digit_position] * 2);

    if($digit_times_two > 9)
    {

      $credit_card_number_digit[$digit_position] = ($digit_times_two - 9);

    }
    else
    {

      $credit_card_number_digit[$digit_position] = $digit_times_two;

    }

  }

  $validation_number = 0;

  # Step 3.
  foreach $digit (@credit_card_number_digit)
  {

    $validation_number += $digit;

  }

  # Step 4.
  $validation_number % 10;

} # END: sub validate_credit_card_number

################################################################################
# validate_credit_card_expiration_date
################################################################################

sub validate_credit_card_expiration_date
{
   local($credit_card_expiration_date) = @_;
   local($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst);
   local($expiration_month,$expiration_day,$expiration_year,$expiration_card);
   local($my_today);

   ($expiration_month,$expiration_year) = split(/\//,$credit_card_expiration_date);
   if ($expiration_year < 100)
   {
      $expiration_year = $expiration_year + 2000; # works for a few years yet
   }
   if ($expiration_day < 1)
   {
      $expiration_day = 31;# works no matter what month ... assume end of month
   }

   # Get current month and year.
   ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);

   # localtime returns posible values of 0-11.  Increment to change range to 1-12.
   $mon++;

   $my_today = $mday + 100*($mon + 100*(1900 + $year));
   $expiration_card = 100* (100 * $expiration_year + $expiration_month) + $expiration_day;

   if($my_today > $expiration_card)
   {
      return(2); # Error 2: Credit Card Expired.
   }

   return(0); # Card has not expired.
}

1;

