#######################################################################
#                Database Definition Variables                        #
#######################################################################

# Database Definitions from the products.txt file

$db{'product_id'}  = 0;
$db{'product'}     = 1;
$db{'price'}       = 2;
$db{'name'}        = 3;
$db{'image'}       = 4;
$db{'description'} = 5;
$db{'shipping'}    = 6;
$db{'user1'}       = 7;
$db{'user2'}       = 8;
$db{'user3'}       = 9;
$db{'user4'}       = 10;
$db{'user5'}       = 11;
$db{'options'}     = 12;

# Query fields used for searches

@sc_db_query_criteria = ("query_price_low_range|2|<=|number",
                         "query_price_high_range|2|>=|number",
                         "product|1|=|string",
                         "pid|0|=|number",
                         "keywords|1,3,5|=|string");

# form_data fields used in hidden fields

@sc_hidden_fields = ("cart_id",
                     "page",
                     "ppage",
                     "row",
                     "per",
                     "next",
                     "exact_match",
                     "case_sensitive");

#######################################################################
#                    Cart Definition Variables                        #
#######################################################################

# Defines which form_data values will get written to the shopping cart.

@sc_cart_items = ("quantity",
                  "product",
                  "product_id",
                  "price",
                  "name",
                  "shipping",
                  "options",
                  "price_after_options",
                  "unique_cart_line_id");

# Turns above into $cart{'quantity'} = 1 for use in display
# By using these values in display then things will not get messed up
# if you make changes to the sc_cart_items.

$cart_items_count = 0;
foreach $cart_items (@sc_cart_items)
{
   $cart{$cart_items} = $cart_items_count;
   $cart_items_count++;
}

# Values from shopping cart that will show in cart display to customer.
# These are also the fields that will show in the html version of the
# confirming email to the customer.
# Options must be the last field in @sc_cart_index_for_display, and not
# listed in @sc_cart_display_fields

@sc_cart_display_fields        = ("Quantity"       ,"Product",     "Price",        "Subtotal");
@sc_cart_index_for_display     = ($cart{"quantity"},$cart{"name"}, $cart{"price"}, $cart{"price_after_options"}, $cart{"options"});

# This is for the text version of the products that will show in the text version
# of the customers email.

@sc_cart_email_fields          = ("Quantity"       ,"Product",     "Price",        "Options",        "Subtotal");
@sc_cart_index_for_email       = ($cart{"quantity"},$cart{"name"}, $cart{"price"}, $cart{"options"}, $cart{"price_after_options"});

# This is for the html version of the products that can be show in the admin email and log.
# Options must be the last field in @sc_cart_index_for_display, and not
# listed in @sc_cart_display_fields

@sc_cart_display_admin_html    = ("Quantity"       ,"Product",     "Price",        "Subtotal");
@sc_cart_index_for_admin_html  = ($cart{"quantity"},$cart{"name"}, $cart{"price"}, $cart{"price_after_options"}, $cart{"options"});

# This is for the text version of the products that will show in the admin email and log.

@sc_cart_display_admin_email   = ("Quantity"       ,"Product",     "Price",        "Options",        "Subtotal");
@sc_cart_index_for_admin_email = ($cart{"quantity"},$cart{"name"}, $cart{"price"}, $cart{"options"}, $cart{"price_after_options"});

# Order in which discount, shipping, and sales tax get calculated.
# increasing numerical value (1,2,3) if its 0,
# then it never gets calculated.

$sc_calculate_discount_at_process_form  = 1;
$sc_calculate_shipping_at_process_form  = 2;
$sc_calculate_sales_tax_at_process_form = 3;

# yes for security check to make sure cart item matches database value.

$sc_order_check_db = "yes";


1;