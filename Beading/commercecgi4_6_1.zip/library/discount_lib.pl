############################################################
# calculate_discount
############################################################

sub calculate_discount
{
   local($subtotal, $total_quantity, $total_measured_quantity) = @_;

   @sc_order_form_discount_related_fields = ();

   @sc_discount_logic  = ();

   return(&calculate_general_logic(
           $subtotal,
           $total_quantity,
           $total_measured_quantity,
           *sc_discount_logic,
           *sc_order_form_discount_related_fields));
}

############################################################
# calculate_general_logic
############################################################

sub calculate_general_logic
{
	local($subtotal, $total_quantity, $total_measured_quantity,
         *general_logic, *general_related_form_fields) = @_;

	local($general_value, $x, $count, $logic, $criteria_satisfied, @fields);

	local(@related_form_values) = ();

	$count = 0;

	foreach $x (@general_related_form_fields)
	{
		$related_form_values [$count] = $form_data{$x};
		$count++;
	}

	foreach $logic (@general_logic)
	{
		$criteria_satisfied = "yes";
		@fields = split(/\|/, $logic);

		for (1..@related_form_values)
		{
			if (!(&compare_logic_values($related_form_values[$_ - 1], $fields[$_ - 1])))
			{
			$criteria_satisfied = "no";
			}
    	}

    	for (1..@related_form_values)
    	{
      	shift(@fields);
    	}

    	if (!(&compare_logic_values($subtotal, $fields[0])))
    	{
			$criteria_satisfied = "no";
    	}

    	shift (@fields);

    	if (!(&compare_logic_values($total_quantity, $fields[0])))
    	{
			$criteria_satisfied = "no";
    	}

    	shift (@fields);

    	if (!(&compare_logic_values($total_measured_quantity, $fields[0])))
    	{
			$criteria_satisfied = "no";
    	}

    	shift (@fields);

    	if ($criteria_satisfied eq "yes")
    	{
    		if ($fields[0] =~ /%/)
    		{
				$fields[0] =~ s/%//;
				$general_value = $subtotal * $fields[0] / 100;
			} else {
				$general_value = $fields[0];
      	}
    	}
	}

	return(&format_price($general_value));
}

############################################################
# compare_logic_values
############################################################

sub compare_logic_values
{
	local($input_value, $value_to_compare) = @_;
   local($lowrange, $highrange);

	if ($value_to_compare =~ /-/)
	{
    	($lowrange, $highrange) = split(/-/, $value_to_compare);
    	if ($lowrange eq "")
    	{
      	if ($input_value <= $highrange)
      	{
        		return(1);
      	} else {
        		return(0);
      	}
		} elsif ($highrange eq "") {
      	if ($input_value >= $lowrange)
      	{
				return(1);
			} else {
				return(0);
			}
		} else {
      	if (($input_value >= $lowrange) && ($input_value <= $highrange))
      	{
        		return(1);
      	} else {
        		return(0);
      	}
    	}
	} else {
		if (($input_value =~ /$value_to_compare/i) || ($value_to_compare eq ""))
		{
      	return(1);
    	} else {
      	return(0);
    	}
  	}
}

1;