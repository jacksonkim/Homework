#######################################################################
#                            get_file_lock                            #
#######################################################################

sub get_file_lock
{
   local ($lock_file) = @_;
   local ($endtime);

   $endtime = time + 20;

   while (-e $lock_file && time < $endtime)
   {
      sleep(1);
   }

   open(LOCK_FILE, ">$lock_file") || &errorcode(__FILE__, __LINE__, "$lock_file", "$!", "nolog", "FILE OPEN ERROR, LOCK FILE", "2");

   # Note: If flock is available on your system, feel free to
   # use it.  flock is an even safer method of locking your
   # file because it locks it at the system level.  The above
   # routine is "pretty good" and it will server for most
   # systems.  But if you are lucky enough to have a server
   # with flock routines built in, go ahead and uncomment
   # the next line and comment the one above.

   # flock(LOCK_FILE, 2); # 2 exclusively locks the file

}

#######################################################################
#                            release_file_lock                        #
#######################################################################

sub release_file_lock
{
   local ($lock_file) = @_;

   # flock(LOCK_FILE, 8); # 8 unlocks the file

   # As we mentioned in the discussion of get_file_lock,
   # flock is a superior file locking system.  If your system
   # has it, go ahead and use it instead of the hand rolled
   # version here.  Uncomment the above line and comment the
   # two that follow.

   close(LOCK_FILE);
   unlink($lock_file);

}

1;