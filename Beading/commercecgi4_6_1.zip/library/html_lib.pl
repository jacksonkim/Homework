#######################################################################
#                   Misc. HTML Store Variables                        #
#######################################################################

$sc_shall_i_let_client_know_item_added    = "yes";

$sc_item_ordered_message = qq~
   <!-- Start \$sc_item_ordered_message - html_lib.pl -->
   <div class="item_added_message">Thank you, your selection has been added to your order.</div>
   <!-- End \$sc_item_ordered_message - html_lib.pl -->
~;

#######################################################################
# create_html_page_from_db
#######################################################################

sub create_html_page_from_db
{
   local ($fromshown, $toshown, $pages, $keywords);
   local ($lowrange, $highrange);
   local (@database_rows, @database_fields, @item_ids, @display_fields);
   local ($total_row_count, $id_index, $display_index, $header_title);
   local ($row, $field, $empty, $option_tag, $option_location, $output);

   if (!($sc_db_lib_was_loaded =~ /yes/i))
   {
      require "$sc_library_directory_path/commerce_db_lib.pl" ||
      &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/commerce_db_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
   }

   ($status,$total_row_count) = &submit_query(*database_rows);

   $nextCount = $form_data{'next'}+$items_per_page;
   $prevCount = $form_data{'next'}-$items_per_page;

   $minCount = $form_data{'next'};
   $maxCount = $form_data{'next'}+$items_per_page;

   $item_counter = "1";
   $items_per_row = "3";

   if ($form_data{'row'})
   {
      $items_per_row = $form_data{'row'};
   }

   my $percent = int(100/$items_per_row);

   if ($form_data{'pid'} eq "" && $form_data{'ppage'} eq "")
   {
      $sc_product_display_row .= qq~
         <div align="center">
         <center>
         <table border="0" width="90%"><tr><td width="$percent\%" valign="top">
      ~;
   }

   foreach $row (@database_rows)
   {
      chomp $row;

      if ($form_data{'pid'} eq "" && $form_data{'ppage'} eq "")
      {
         if ($rowCount > $minCount && $rowCount <= $maxCount)
         {
            if ($item_counter == $items_per_row)
            {
               $sc_product_display_row .= qq~
                  </td></tr><tr><td width="$percent\%" valign="top">
               ~;
               $item_counter = "1";
            } else {
               $sc_product_display_row .= qq~
                  </td><td width="$percent\%" valign="top">
                ~;
               $item_counter++;
            }
         }
      }

      $rowCount++;

      $prevHits = $items_per_page;
      $nextHits = $items_per_page;

      if ($rowCount > $minCount && $rowCount <= $maxCount)
      {

         @database_fields = split (/\|/, $row);

         if ($database_fields[$db{"options"}] =~ /^%%OPTION%%/)
         {

            if ($database_fields[$db{"options"}] =~ /^%%OPTION%%user1.html/ && $database_fields[$db{"user1"}] ne "")
            {
               my @items = split(/\,/, $database_fields[$db{"user1"}]);

               $database_fields[$db{"options"}] = "";

               $database_fields[$db{"options"}] .= qq~
                  <input type="hidden" name="option_count" value="1">
                  <select class="selectinput" name="option1" size="1">
               ~;

               foreach my $item (@items)
               {
                  chomp $item;

                  my ($name, $amount) = split(/\+/, $item);
                  my $control = &hmac_hex("$name $amount", $encrypt_key);

                  if ($amount)
                  {
                     my $price = &display_price(&format_price($amount));

                     $database_fields[$db{"options"}] .= qq~
                        <option value="$name|$amount|$control" $selected{$name}>$name (+ $price)</option>
                     ~;
                  } else {
                     $database_fields[$db{"options"}] .= qq~
                        <option value="$name|$amount|$control" $selected{$name}>$item</option>
                     ~;
                  }
               }

               # close select box
               $database_fields[$db{"options"}] .= qq~
                  </select><br>
               ~;
            } else {

               ($empty, $option_tag, $option_location) = split (/%%/, $database_fields[$db{"options"}]);
               $database_fields[$db{"options"}] = "";

               open (OPTION_FILE, "<$sc_options_directory_path/$option_location") ||
               &errorcode(__FILE__, __LINE__, "$sc_options_directory_path/$option_location", "$!", "print", "FILE OPEN ERROR", "0");

               while (<OPTION_FILE>)
               {
                  s/\{PRODUCT_ID\}/$database_fields[$db{"product_id"}]/g;

                  $database_fields[$db{"options"}] .= $_;
               }

               close (OPTION_FILE);
            }
         }

         $sc_product_display_row .= &displayProductPage;
      }
   }

   if ($form_data{'pid'} eq "" && $form_data{'ppage'} eq "")
   {
      $sc_product_display_row .= qq~
         </td></tr></table></center></div>
      ~;
   }

   local ($hidden_string) = &make_hidden_string("no_next");

   $product = $form_data{'product'};

   if ($status ne "")
   {

      if ($status =~ /max.*row.*exceed.*/i)
      {

         $product = $form_data{'product'};

         if($form_data{'next'} > "0")
         {
            if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
            {
               $link = "$sc_store_url?next=$prevCount$hidden_string";
            } else {
               $link = "$html_folder\/$prevCount\/$form_data{'product'}\.htm";
            }

            $back = qq~
               <a href="$link">
               <span class="back_link">&lt;&lt;&lt; Back</span>
               </a>
            ~;
         }

         if ($maxCount == $rowCount-1)
         {
            $nextHits = (@database_rows-$maxCount);
            if ($nextHits == 1)
            {
               if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
               {
                  $link = "$sc_store_url?next=$maxCount$hidden_string";
               } else {
                  $link = "$html_folder\/$maxCount\/$form_data{'product'}\.htm";
               }

               $front = qq~
                  <a href="$link">
                  <span class="next_link">Next &gt;&gt;&gt;</span>
                  </a>
               ~;
            }
         }

         if ($maxCount < $rowCount && $maxCount != $rowCount-1)
         {

            if ($maxCount >= $rowCount-$nextHits )
            {
               $lastCount = $rowCount-$maxCount;

               if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
               {
                  $link = "$sc_store_url?next=$maxCount$hidden_string";
               } else {
                  $link = "$html_folder\/$maxCount\/$form_data{'product'}\.htm";
               }

               $front = qq~
                  <a href="$link">
                  <span class="next_link">Next &gt;&gt;&gt;</span>
                  </a>
               ~;
            } else {
               if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
               {
                  $link = "$sc_store_url?next=$maxCount$hidden_string";
               } else {
                  $link = "$html_folder\/$maxCount\/$form_data{'product'}\.htm";
               }

               $front = qq~
                  <a href="$link">
                  <span class="next_link">Next &gt;&gt;&gt;</span>
                  </a>
               ~;
            }
         }

         if ($status =~ /max.*row.*exceed.*/i)
         {

            $next = $form_data{'next'};
            $product = $form_data{'product'};

            if ($maxCount > $total_row_count)
            {
               $toshown = $total_row_count;
            } else {
               $toshown = $maxCount;
            }

            if ($next < 1)
            {
               $fromshown = 1;
            } else {
               $fromshown = $next;
            }

            $page = $toshown/$items_per_page;
            $pages = $total_row_count/$items_per_page;

            if ($page =~ /\./g)
            {
               $page = int($page)+1;
            }

            if ($pages =~ /\./g)
            {
               $pages = int($pages)+1;
            }

            $cc=1;

            $page_message .= qq~<span class="default_text">Page:&nbsp&nbsp</span>~;

            while ($cc<=$pages)
            {
               $ccnext = ($cc-1)*$items_per_page;

               if ($cc == $page)
               {
                  $page_message .= qq~
                     <span class="default_text">$cc&nbsp</span>
                  ~;
               } else {
                  if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
                  {
                     $link = "$sc_store_url?next=$ccnext$hidden_string";
                  } else {
                     $link = "$html_folder\/$ccnext\/$form_data{'product'}\.htm";
                  }

                  $page_message .= qq~
                     <a href="$link"><span class="default_text">$cc</span></a>&nbsp
                  ~;
               }

               $cc++;
            }
         }
      }
   }

   if ($form_data{'pid'})
   {
      $header_title = "Product Listing - $database_fields[$db{'name'}]";
   } elsif ($form_data{'keywords'}) {
      $header_title = "Search Listing - $form_data{'keywords'}";
   } else {
      $header_title = "Category Listing - $product";
   }

   &StoreHeader($header_title,"regular");

   # Added for expandability
   print "$sub_product_header_message";

   if ($form_data{'add_to_cart_button.x'} ne "" && $sc_shall_i_let_client_know_item_added eq "yes")
   {
      print "$sc_item_ordered_message";
   }

   print $sc_product_display_row;

   # Added for expandability
   print "$sub_product_footer_message";

   &StoreFooter("regular");
}

#######################################################################
#                     display_page Subroutine                         #
#######################################################################

sub display_page
{
   local ($page, $routine, $file, $line) = @_;

   if ($form_data{'secure'})
   {
      &StoreHeader("$site_name", "secure");
   } else {
      &StoreHeader("$site_name", "regular");
   }

   # Added for expandability
   print "$sub_page_header_message";

   open (PAGE, "<$page") || &errorcode(__FILE__, __LINE__, "$page", "$!", "print", "FILE OPEN ERROR", "0");

   while (<PAGE>)
   {
      $page = $form_data{'page'};

      s/\{mini_cart\}/$minicart/g;
      s/\{scriptURL\}/$sc_store_url/g;
      s/\{cart_id\}/$cart_id/g;
      s/\{page\}/$page/g;
      s/\{date\}/$date/g;

      if ($form_data{'secure'})
      {
         s/\{URLofImages\}/$URL_of_secure_images_directory/g;
      } else {
         s/\{URLofImages\}/$URL_of_images_directory/g;
      }

      s/\{highlightcolor\}/$highlightcolor/g;
      s/\{highlightfontcolor\}/$highlightfontcolor/g;
      s/\{site_name\}/$site_name/g;

      s/\{custom1\}/$custom1/g;
      s/\{custom2\}/$custom2/g;
      s/\{custom3\}/$custom3/g;
      s/\{custom4\}/$custom4/g;
      s/\{custom5\}/$custom5/g;
      s/\{custom6\}/$custom6/g;
      s/\{custom7\}/$custom7/g;
      s/\{custom8\}/$custom8/g;
      s/\{custom9\}/$custom9/g;
      s/\{custom10\}/$custom10/g;
      s/\{custom11\}/$custom11/g;
      s/\{custom12\}/$custom12/g;
      s/\{custom13\}/$custom13/g;
      s/\{custom14\}/$custom14/g;
      s/\{custom15\}/$custom15/g;

      if ($form_data{'add_to_cart_button'} ne "" &&
          $sc_shall_i_let_client_know_item_added eq "yes")
      {
         if ($_ =~ /<FORM/i)
         {
            print "$_";
            print "$sc_item_ordered_message";
         }
      }

      if ($_ =~ /<!--.*&/i)
      {
         my $cmd = (split(/--/, $_))[1];
         $cmd =~ /([\w]+)/;
         $cmd = "$1";
         print eval($cmd);
      } else {
         print $_;
      }
   }

   close (PAGE);

   # Added for expandability
   print "$sub_page_footer_message";

   if ($form_data{'secure'})
   {
      &StoreFooter("secure");
   } else {
      &StoreFooter("regular");
   }
}

###############################################################
# Display Product Page
###############################################################

sub displayProductPage
{
   local($keywords, $imageURL, $product_page, $control, $description, $price);

   $keywords = $form_data{'keywords'};
   $keywords =~ s/ /+/g;

   local ($hidden_fields) = &make_hidden_fields;

   $encrypt_text = $database_fields[$db{"name"}] . " " . $database_fields[$db{"price"}] . " " . $database_fields[$db{"shipping"}];
   $control = &hmac_hex($encrypt_text, $encrypt_key);

   $hidden_fields .= qq~
      <input type="hidden" name="control" value="$control">
   ~;

   if ($form_data{'pid'} eq "")
   {
      $ppage = "Thumb";
   }

   if ($form_data{'pid'} eq "" && $ENV{'REQUEST_URI'} !~ /commerce.cgi/i && $use_html eq "yes")
   {
      $ppage = "HTML";
   }

   if ($form_data{'ppage'})
   {
      $ppage = $form_data{'ppage'};
   }

   open (PAGE, "$sc_template_directory_path/productPage$ppage.txt") ||
   &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/productPage$ppage.txt", "$!", "print", "FILE OPEN ERROR", "0");
   while (<PAGE>)
   {
      $product_page .= $_;
   }
   close (PAGE);

   $imageURL = $database_fields[$db{"image"}];

   $small_image_test = "$images_path\/product\/small\/$imageURL";
   $large_image_test = "$images_path\/product\/$imageURL";

   if ($na_image_if_not_found eq "yes")
   {
      if (-f $small_image_test)
      {
         $small_image = "$URL_of_images_directory\/product\/small\/$imageURL";
      } else {
         $small_image = "$URL_of_images_directory\/product\/small\/notavailable.gif";
      }

      if (-f $large_image_test)
      {
         $large_image = "$URL_of_images_directory\/product\/$imageURL";
      } else {
         $large_image = "$URL_of_images_directory\/product\/notavailable.gif";
      }
   } else {
      $small_image = "$URL_of_images_directory\/product\/small\/$imageURL";
      $large_image = "$URL_of_images_directory\/product\/$imageURL";
   }

   my $display_category = $database_fields[$db{"product"}];
   $display_category=~ s/!/ /g;
   $product_page =~ s/{display_category}/$display_category/g;

   $product_page =~ s/{URLofImages}/$URL_of_images_directory/g;
   $product_page =~ s/{image}/$imageURL/g;
   $product_page =~ s/{small_image}/$small_image/g;
   $product_page =~ s/{large_image}/$large_image/g;
   $product_page =~ s/{product_id}/$database_fields[$db{"product_id"}]/g;
   $product_page =~ s/{scriptURL}/$sc_store_url/g;
   $product_page =~ s/{cart_id}/$cart_id/g;
   $product_page =~ s/{product}/$database_fields[$db{"product"}]/g;
   $product_page =~ s/{keywords}/$keywords/g;
   $product_page =~ s/{hidden_fields}/$hidden_fields/g;
   $product_page =~ s/{name}/$database_fields[$db{"name"}]/g;

   $description  = $database_fields[$db{"description"}];
   $description  =~ s/{cart_id}/$cart_id/g;
   $description  =~ s/{URLofImages}/$URL_of_images_directory/g;
   $description  =~ s/{scriptURL}/$sc_store_url/g;

   $product_page =~ s/{description}/$description/g;

   $product_page =~ s/{optionFile}/$database_fields[$db{"options"}]/g;

   if ($database_fields[$db{"price"}])
   {
      $price = &display_price(&format_price($database_fields[$db{"price"}]));
   }

   $product_page =~ s/{price}/$price/g;
   $product_page =~ s/{hidden_price}/$database_fields[$db{"price"}]/g;
   $product_page =~ s/{shipping}/$database_fields[$db{"shipping"}]/g;
   $product_page =~ s/{user1}/$database_fields[$db{"user1"}]/g;
   $product_page =~ s/{user2}/$database_fields[$db{"user2"}]/g;
   $product_page =~ s/{user3}/$database_fields[$db{"user3"}]/g;
   $product_page =~ s/{user4}/$database_fields[$db{"user4"}]/g;
   $product_page =~ s/{user5}/$database_fields[$db{"user5"}]/g;

   $product_page =~ s/{highlightcolor}/$highlightcolor/g;
   $product_page =~ s/{highlightfontcolor}/$highlightfontcolor/g;

   $product_page =~ s/{inventory}/$inventory/g;
   $product_page =~ s/{similar}/$similar/g;

   $product_page =~ s/{custom1}/$custom1/g;
   $product_page =~ s/{custom2}/$custom2/g;
   $product_page =~ s/{custom3}/$custom3/g;
   $product_page =~ s/{custom4}/$custom4/g;
   $product_page =~ s/{custom5}/$custom5/g;
   $product_page =~ s/{custom6}/$custom6/g;
   $product_page =~ s/{custom7}/$custom7/g;
   $product_page =~ s/{custom8}/$custom8/g;
   $product_page =~ s/{custom9}/$custom9/g;
   $product_page =~ s/{custom10}/$custom10/g;
   $product_page =~ s/{custom11}/$custom11/g;
   $product_page =~ s/{custom12}/$custom12/g;
   $product_page =~ s/{custom13}/$custom13/g;
   $product_page =~ s/{custom14}/$custom14/g;
   $product_page =~ s/{custom15}/$custom15/g;

   return ($product_page);
}

############################################################################################

sub StoreHeader
{
   my ($title, $header) = @_;
   my ($hidden_string) = &make_hidden_string;
   my ($dcat, $v_category, $h_category, $d_category);
   my ($pages, $h_pages);

   $keywords = $form_data{'keywords'};
   $keywords =~ s/ /+/g;

   $cart_contents = &cart_content;
   $mini_cart     = &mini_cart;

   ($pages, $h_pages) = &pages;

   if (-f "$sc_template_directory_path/store_template-$form_data{'template'}.htm")
   {
      if ($form_data{'template'}){ $template = $form_data{'template'}; }
   }

   ($d_category, $v_category, $h_category) = &categories;

   open (TEMPLATE, "$sc_template_directory_path/store_template-$template.htm") ||
   &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/store_template-$template.htm", "$!", "print", "FILE OPEN ERROR", "0");

   while (<TEMPLATE>)
   {
      if ($_ =~ /\{DATA\}/i){ last; }
      s/\{v_category\}/$v_category/g;
      s/\{h_category\}/$h_category/g;
      s/\{d_category\}/$d_category/g;
      s/\{mini_cart\}/$minicart/g;
      s/\{cart_id\}/$cart_id/g;
      s/\{cart_contents\}/$cart_contents/g;
      s/\{highlightcolor\}/$highlightcolor/g;
      s/\{highlightfontcolor\}/$highlightfontcolor/g;
      s/\{random_products\}/$random_products/g;
      s/\{keywords\}/$keywords/g;
      s/\{next\}/$form_data{'next'}/g;
      s/\{page\}/$page_message/g;
      s/\{product\}/$form_data{'product'}/g;
      s/\{scriptURL\}/$sc_store_url/g;
      s/\{site_name\}/$site_name/g;
      s/\{title\}/$title/g;
      s/\{pages\}/$pages/g;
      s/\{h_pages\}/$h_pages/g;

      s/\{custom1\}/$custom1/g;
      s/\{custom2\}/$custom2/g;
      s/\{custom3\}/$custom3/g;
      s/\{custom4\}/$custom4/g;
      s/\{custom5\}/$custom5/g;
      s/\{custom6\}/$custom6/g;
      s/\{custom7\}/$custom7/g;
      s/\{custom8\}/$custom8/g;
      s/\{custom9\}/$custom9/g;
      s/\{custom10\}/$custom10/g;
      s/\{custom11\}/$custom11/g;
      s/\{custom12\}/$custom12/g;
      s/\{custom13\}/$custom13/g;
      s/\{custom14\}/$custom14/g;
      s/\{custom15\}/$custom15/g;

      if ($header eq "secure")
      {
         s/\{URLofImages\}/$URL_of_secure_images_directory/g;
      } else {
         s/\{URLofImages\}/$URL_of_images_directory/g;
      }

      s/\{hidden_string\}/$hidden_string/g;

      if (!($_ =~ /\{DATA\}/i))
      {
         if ($_ =~ /<!--.*&/i)
         {
            my $cmd = (split(/--/, $_))[1];
            $cmd =~ /([\w]+)/;
            $cmd = "$1";
            print eval($cmd);
         } else {
            print $_;
         }
      }
   }
}

############################################################################################

sub StoreFooter
{
   local ($footer) = @_;
   local ($d_category, $v_category, $h_category, $pages, $h_pages);
   local ($hidden_string) = &make_hidden_string;

   ($d_category, $v_category, $h_category) = &categories;

   ($pages, $h_pages) = &pages;

   while (<TEMPLATE>)
   {
      s/\{v_category\}/$v_category/g;
      s/\{h_category\}/$h_category/g;
      s/\{d_category\}/$d_category/g;
      s/\{mini_cart\}/$minicart/g;
      s/\{front\}/$front/g;
      s/\{back\}/$back/g;
      s/\{scriptURL\}/$sc_store_url/g;
      s/\{hidden_string\}/$hidden_string/g;
      s/\{pages\}/$pages/g;
      s/\{h_pages\}/$h_pages/g;
      s/\{page\}/$page_message/g;

      if ($footer eq "secure")
      {
         s/\{URLofImages\}/$URL_of_secure_images_directory/g;
      } else {
         s/\{URLofImages\}/$URL_of_images_directory/g;
      }

      s/\{cart_id\}/$cart_id/g;
      s/\{highlightcolor\}/$highlightcolor/g;
      s/\{highlightfontcolor\}/$highlightfontcolor/g;

      s/\{random_products\}/$random_products/g;
      s/\{site_name\}/$site_name/g;

      s/\{custom1\}/$custom1/g;
      s/\{custom2\}/$custom2/g;
      s/\{custom3\}/$custom3/g;
      s/\{custom4\}/$custom4/g;
      s/\{custom5\}/$custom5/g;
      s/\{custom6\}/$custom6/g;
      s/\{custom7\}/$custom7/g;
      s/\{custom8\}/$custom8/g;
      s/\{custom9\}/$custom9/g;
      s/\{custom10\}/$custom10/g;
      s/\{custom11\}/$custom11/g;
      s/\{custom12\}/$custom12/g;
      s/\{custom13\}/$custom13/g;
      s/\{custom14\}/$custom14/g;
      s/\{custom15\}/$custom15/g;

      if (!($_ =~ /\{DATA\}/i))
      {
         if ($_ =~ /<!--.*&/i)
         {
            my $cmd = (split(/--/, $_))[1];
            $cmd =~ /([\w]+)/;
            $cmd = "$1";
            print eval($cmd);
         } else {
            print $_;
         }
      }
   }
   close (TEMPLATE);
}

#######################################################################
# cart_table_header
#######################################################################

sub cart_table_header
{
   my ($modify_type) = @_;
   my ($hidden_fields) = &make_hidden_fields;

   $keywords = $form_data{'keywords'};
   $keywords =~ s/ /+/g;

   if (($modify_type ne "") && ($modify_type ne "orderform") && ($modify_type ne "verify"))
   {
      $modify_type = qq~<td class="colored_cell_header">&nbsp;$modify_type&nbsp;</td>~;
   }

   if ($modify_type eq "")
   {
      $modify_type = qq~<td class="colored_cell_header"></td>~;
   }

   if ($modify_type eq "orderform")
   {
      $modify_type = "";
   }

   if ($modify_type eq "verify")
   {
      $modify_type = "";
   }

   # Added for expandability
   print "$sub_cart_table_header_message";

   print qq~
      <FORM METHOD="post" ACTION="$sc_store_url">
      $hidden_fields

      <table border="0" cellpadding="5" cellspacing="0" WIDTH="90%" align="center">
      <tr>
      $modify_type
   ~;

   $field_counter = 0;
   foreach $field (@sc_cart_display_fields)
   {
      if ($sc_cart_index_for_display[$field_counter] == $cart{"price"} ||
          $sc_cart_index_for_display[$field_counter] == $cart{"shipping"} ||
          $sc_cart_index_for_display[$field_counter] == $cart{"price_after_options"})
      {
         print qq~<td class="colored_cell_header" align="right">&nbsp;$field&nbsp;</td>~;
      } else {
         print qq~<td class="colored_cell_header" align="left">&nbsp;$field&nbsp;</td>~;
      }
      $field_counter++;
   }

   print qq~</tr>~;
}

#######################################################################
#                    display_cart_table Subroutine                    #
#######################################################################

sub display_cart_table
{
   local ($reason_to_display_cart, $required_fields_filled_in) = @_;
   local (@cart_fields, $cart_id_number, $quantity, $unformatted_subtotal);
   local ($subtotal, $unformatted_grand_total, $grand_total, $price);
   local ($total_measured_quantity) = 0;
   local ($display_index, $counter, $hidden_field_name);
   local ($hidden_field_value, $display_counter, $product_id);
   local ($ship_company, $upgradeShipPrice, $shipMethod);
   local ($final_shipping, $final_discount, $final_sales_tax, $grand_total);
   local ($hidden_string, $lineTotal, $cart_error, $product_name, $product_price );

   $total_quantity = 0;

   if (($reason_to_display_cart =~ /orderform/i) || ($reason_to_display_cart =~ /verify/i))
   {
      &StoreHeader("Cart Contents","secure");
   } else {
      &StoreHeader("Cart Contents","regular");
   }

   if (-s "$sc_cart_path")
   {
      if ($reason_to_display_cart =~ /orderform/i)
      {
         $reason_to_display_cart = "orderform";
         &cart_table_header($reason_to_display_cart);
      } elsif ($reason_to_display_cart =~ /verify/i) {
         $reason_to_display_cart = "verify";
         &cart_table_header($reason_to_display_cart);
      } else {
         &cart_table_header("Delete");
      }

      open (CART, "$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");

      while (<CART>)
      {
         $row_count++;
         $remain = $row_count % 2;   # This gets the remainder after division.
         if ($remain)
         {
            $bgcolor = "#FFFFFF";
         } else {
            $bgcolor = "#DDDDDD";
         }

         print "<TR>";

         chomp;

         @cart_fields = split (/\|/, $_);
         $cart_row_number = pop(@cart_fields);
         push (@cart_fields, $cart_row_number);

         $quantity      = $cart_fields[$cart{"quantity"}];
         $product_id    = $cart_fields[$cart{"product_id"}];
         $product_name  = $cart_fields[$cart{"name"}];
         $product_price = $cart_fields[$cart{"price"}];

         if (($reason_to_display_cart =~ /orderform/i) && ($sc_order_check_db =~ /yes/i))
         {
            if (!($sc_db_lib_was_loaded =~ /yes/i))
            {
               require "$sc_library_directory_path/commerce_db_lib.pl" ||
               &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/commerce_db_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
            }

            if ($product_id ne "00" && $product_id ne "0")
            {
               $cart_error = &check_db_with_product_id($product_id, $product_name, $product_price);
            }
         }

         $total_quantity += $quantity;

         $hidden_string = &make_hidden_string;

        if ($reason_to_display_cart =~ /change*quantity/i)
         {
            print qq~
               <TD ALIGN = "center">
               <INPUT TYPE = "text" NAME = "$cart_row_number" SIZE ="3">
               </TD>
            ~;
         } elsif (($reason_to_display_cart =~ /orderform/i) || ($reason_to_display_cart =~ /process order/i) || ($reason_to_display_cart =~ /verify/i)) {
         } else {
            print qq~
               <td class="cartcontents" bgcolor="$bgcolor">
               <a href="$sc_store_url?submit_deletion_button.x=yes&amp;$cart_row_number=checked$hidden_string">Delete</a>
               </td>
            ~;
         }

         $display_counter = 0;

         foreach $display_index (@sc_cart_index_for_display)
         {
            if ($cart_fields[$display_index] eq "")
            {
               $cart_fields[$display_index] = "&nbsp;";
            }

            if ($display_index == $cart{"price"})
            {
               #C
               my $display_price = &display_price(&format_price($cart_fields[$display_index]));

               print qq~
                  <td class="cartcontents" align="right" bgcolor="$bgcolor" nowrap>$display_price</td>
               ~;

            } elsif ($display_index == $cart{"options"}) {
               $cart_html = "";

               if (($reason_to_display_cart =~ /orderform/i) || ($reason_to_display_cart =~ /process order/i) || ($reason_to_display_cart =~ /verify/i))
               {
                  $cart_html .= qq~
                     </tr>
                     <tr>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">$cart_fields[$display_index]&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td></tr>
                  ~;
               } else {
                  $cart_html .= qq~
                     </tr>
                     <tr>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">$cart_fields[$display_index]&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td>
                     <td class="cartcontents" bgcolor="$bgcolor">&nbsp;</td></tr>
                  ~;
               }

               print $cart_html;

            } elsif ($display_index == $cart{"name"}) {
               print qq~
                  <td class="cartcontents" bgcolor="$bgcolor">$cart_fields[$display_index]</td>
               ~;

            } elsif ($display_index == $cart{"price_after_options"}) {
               $lineTotal = $cart_fields[$cart{"quantity"}]*$cart_fields[$display_index];
               my $display_lineTotal = &display_price(&format_price($lineTotal));
               print qq~
                  <td class="cartcontents" align="right" bgcolor="$bgcolor" nowrap>$display_lineTotal</td>
               ~;

            } elsif (($display_index == "0") && ($reason_to_display_cart eq /orderform/i)) {
               print qq~
                  <td class="cartcontents" align="center" bgcolor="$bgcolor">
                  <input class="cart_edit_quantity" type="text" name="$cart_row_number" value="$quantity" size="3">
                  </td>
               ~;

            } else {
               print qq~
                  <td class="cartcontents" align="center" bgcolor="$bgcolor">$cart_fields[$display_index]</td>
               ~;
            }

            if ($display_index == $cart{"shipping"})
            {
               $total_measured_quantity += ($cart_fields[$cart{"quantity"}]*$cart_fields[$cart{"shipping"}]);
               $shipping_total          = $total_measured_quantity;
            }

            $display_counter++;
         }

         $total_measured_quantity += ($cart_fields[$cart{"quantity"}]*$cart_fields[$cart{"shipping"}]);
         $shipping_total          = $total_measured_quantity;

         $unformatted_subtotal    = $cart_fields[$cart{"price_after_options"}];
         #C
         $subtotal                = $cart_fields[$cart{"quantity"}]*$unformatted_subtotal;
         $unformatted_grand_total = $grand_total + $subtotal;
         $grand_total             = $unformatted_grand_total;

         $category_count{$cart_fields[$cart{"product"}]}    += $cart_fields[$cart{"quantity"}];
         $category_subtotal{$cart_fields[$cart{"product"}]} += $cart_fields[$cart{"price_after_options"}] * $cart_fields[$cart{"quantity"}];
         $cart_pid{$cart_fields[$cart{"product_id"}]}       += $cart_fields[$cart{"quantity"}];
      }
      close (CART);

      $price          = &display_price(&format_price($grand_total));
      $shipping_total = &display_price($shipping_total);

      print qq~
         </table>
      ~;

      if ($reason_to_display_cart =~ /verify/i)
      {
         print qq~
            <input type="hidden" name="total" value="$grand_total">
         ~;
      }

      print qq~
         <div align="center">
         <center>
         <table border="0" cellpadding="0" cellspacing="0" width="90%">
         <tr>
         <td width="100%">
         <div align="right">
         <table width="300">
         <tr>
            <td class="cart_totals_labels" width="60%" valign="top" align="right">Subtotal:&nbsp;</td>
            <td class="cart_totals" width="40%" valign="top" align="right">$price</td>
         </tr>
      ~;

      ($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

      if (($form_data{'submit_order_form_button'} || $form_data{'submit_order_form_button.x'}) && $required_fields_filled_in eq "yes")
      {
         ($final_shipping, $final_discount, $final_sales_tax, $grand_total) = &calculate_final_values($grand_total, $total_quantity, $total_measured_quantity);

         if (-f "$sc_extra_directory_path/service_fee.pl")
         {
            $grand_total = &service_fee($grand_total);
         }

         $pass_final_shipping = &format_price($final_shipping);

         if ($final_shipping > 0)
         {

            $final_shipping = &format_price($final_shipping);
            $final_shipping = &display_price($final_shipping);

            if($upgradeShipPrice && $shipMethod)
            {
               $shipText = $shipMethod;
            } else {
               $shipText = "Shipping";
            }

            print qq~
               <tr>
               <td class="cart_totals_labels" width="50%" valign="top" align="right">$shipText:&nbsp;</td>
               <td class="cart_totals" width="50%" valign="top" align="right">$final_shipping</td>
               </tr>
            ~;

         }

         $pass_final_discount = &format_price($final_discount);

         if ($final_discount > 0)
         {

            $final_discount = &format_price($final_discount);
            $final_discount = &display_price($final_discount);

            print qq~
               <tr>
               <td class="cart_totals_labels" width="50%" valign="top" align="right">Discount:&nbsp;</td>
               <td class="cart_totals" width="50%" valign="top" align="right">$final_discount</td>
               </tr>
            ~;
         }

         $pass_final_sales_tax = &format_price($final_sales_tax);

         if ($final_sales_tax > 0)
         {

            $final_sales_tax = &format_price($final_sales_tax);
            $final_sales_tax = &display_price($final_sales_tax);

            print qq~
               <tr>
               <td class="cart_totals_labels" width="50%" valign="top" align="right">Sales Tax:&nbsp;</td>
               <td class="cart_totals" width="50%" valign="top" align="right">$final_sales_tax</td>
               </tr>
            ~;
         }

         $pass_subtotal     = &format_price($unformatted_grand_total);
         $pass_grand_total  = &format_price($grand_total);
         $grand_total       = &display_price(&format_price($grand_total));

         if ($form_data{'submit_order_form_button'} || $form_data{'submit_order_form_button.x'})
         {
            print qq~
               <tr>
               <td class="cart_totals_labels" width="50%" valign="top" align="right">Grand Total:&nbsp;</td>
               <td class="cart_totals" width="50%" valign="top" align="right">$grand_total</td>
               </tr>
            ~;
         }
      }

      print qq~
         </table>
         </div>
         </table>
         </center>
         </div>
      ~;
   }

   if ($cart_error)
   {
      print qq~
         <br><br>
         <div align="center">
         <center>
         <table border="0" cellpadding="0" cellspacing="0" width="90%">
         <tr>
         <td class="cart_error" width="100%">
         $cart_error
         </td>
         </tr>
         </table>
         </center>
         </div>
      ~;
      &StoreFooter("regular");
      exit;
   }
}

#######################################################################
# cart_footer
#######################################################################

sub cart_footer
{
   my ($hidden_fields) = &make_hidden_fields;

   if ($total_quantity eq "0")
   {
      $file_title = "$sc_template_directory_path/empty_cart_footer.txt";
   } else {
      $file_title = "$sc_template_directory_path/cart_footer.txt";
   }

   $gateway_links = qq~
      </form>
      <div align="center">
      <center>
      <table border="0" cellpadding="20" cellspacing="0">
      <tr>
$gateway_checkout_buttons
      </tr>
      </table>
      </center>
      </div>
   ~;

   open (CARTFOOTER, "$file_title") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");

   while (<CARTFOOTER>)
   {
      s/\{scriptURL\}/$sc_store_url/g;
      s/\{gateway_links\}/$gateway_links/g;
      s/\{hidden_fields\}/$hidden_fields/g;
      s/\{URLofImages\}/$URL_of_images_directory/g;
      s/\{cart_id\}/$cart_id/g;
      s/\{highlightcolor\}/$highlightcolor/g;
      s/\{highlightfontcolor\}/$highlightfontcolor/g;

      s/\{custom1\}/$custom1/g;
      s/\{custom2\}/$custom2/g;
      s/\{custom3\}/$custom3/g;
      s/\{custom4\}/$custom4/g;
      s/\{custom5\}/$custom5/g;
      s/\{custom6\}/$custom6/g;
      s/\{custom7\}/$custom7/g;
      s/\{custom8\}/$custom8/g;
      s/\{custom9\}/$custom9/g;
      s/\{custom10\}/$custom10/g;
      s/\{custom11\}/$custom11/g;
      s/\{custom12\}/$custom12/g;
      s/\{custom13\}/$custom13/g;
      s/\{custom14\}/$custom14/g;
      s/\{custom15\}/$custom15/g;

      print $_;
   }
   close CARTFOOTER;

   # Added for expandability
   print "$sub_cart_footer_message";

   &StoreFooter("regular");
}

#######################################################################
#                    make_hidden_fields Subroutine                    #
#######################################################################

sub make_hidden_fields
{
   local($hidden, $field);
   local($db_query_row);
   local($db_form_field);

   foreach $field (@sc_hidden_fields)
   {
      $field = (split(/\|/, $field))[0];
      if ($form_data{$field} ne "")
      {
         $hidden .= qq~
            <input type="hidden" name="$field" value="$form_data{$field}">
         ~;
      }
   }

   foreach $db_query_row (@sc_db_query_criteria)
   {
      $db_form_field = (split(/\|/, $db_query_row))[0];
      if ($form_data{$db_form_field} ne "" && $db_form_field ne "pid")
      {
         $hidden .= qq~
            <input type="hidden" name="$db_form_field" value="$form_data{$db_form_field}">
         ~;
      }
   }

   return ($hidden);
}

#######################################################################
#                    make_hidden_string Subroutine                    #
#######################################################################

sub make_hidden_string
{
   local($no_next) = @_;
   local($hidden, $field, $data);
   local($db_query_row);
   local($db_form_field);

   foreach $field (@sc_hidden_fields)
   {
#      $field = (split(/\|/, $field))[0];

      if ($form_data{$field} ne "")
      {
         unless (($no_next eq "no_next") && ($field eq "next"))
         {
            $hidden .= "\&amp;$field=$form_data{$field}";
         }
      }
   }

   foreach $db_query_row (@sc_db_query_criteria)
   {
      $db_form_field = (split(/\|/, $db_query_row))[0];
      if ($form_data{$db_form_field} ne "" && $db_query_row ne "pid")
      {
         $data = $form_data{$db_form_field};
         $data =~ s/ /+/g;
         $hidden .= "\&amp;$db_form_field=$data";
      }
   }

   return ($hidden);
}

#######################################################################
# PrintNoHitsBodyHTML
#######################################################################

sub PrintNoHitsBodyHTML
{
   &StoreHeader("No Products Found","regular");

   print qq~
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
      <td class="no_items_found" width="100%">
      I'm sorry, no matches were found for &quot;$form_data{'keywords'}$form_data{'product'}&quot;.&nbsp;<br>
      Please try your search again.
      </td>
      </tr>
      </table>
   ~;

   &StoreFooter("regular");
   exit;
}

############################################################
# Cart Contents
############################################################

sub cart_content
{
   local ($cart_contents);

   my $count      = "";
   my $total_qty  = "";
   my $total_cost = "";

   open (CARTFILE, "$sc_cart_path");
   while (<CARTFILE>)
   {
      $count++;
      @cart_fields = split (/\|/, $_);
      $quantity    = $cart_fields[$cart{"quantity"}];
      $product_id  = $cart_fields[$cart{"product_id"}];
      $price       = $cart_fields[$cart{"price_after_options"}];
      $total_cost  = $total_cost + $quantity * $price;
      $total_qty   = $total_qty + $quantity;
   }
   close (CARTFILE);

   if ($count > 0)
   {
      $total_cost = &display_price(&format_price($total_cost));
   } else {
      $total_cost = &display_price(&format_price("0.00"));
      $total_qty  = "0";
   }

   $cart_contents = qq~
      Total Quantity: $total_qty&nbsp;&nbsp;&nbsp;Subtotal: $total_cost
   ~;

   return ($cart_contents);
}

############################################################
# Categories
############################################################

sub categories
{
   local ($d_category, $v_category, $h_category, $dcat);

   $d_category = qq~
      <select name="SeeAlsoSelect" class="d_category" onChange=ViewCrossReference(this);>
      <option> </option>
   ~;

   open(CATFILE, "$sc_log_file_directory_path/category.txt") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/category.txt", "$!", "print", "FILE OPEN ERROR", "1");
   while (<CATFILE>)
   {
      chomp $_;

      $_ =~ s/\r//g;

      $dcat = $_;
      $dcat =~ s/_/ /g;

      if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
      {
         $v_category .= "<a href=\"$sc_store_url?product=$_&amp;cart_id=$cart_id\">$dcat</a><br>\n";
         push (@h_category, "<a href=\"$sc_store_url?product=$_&amp;cart_id=$cart_id\">$dcat</a>");
         $d_category .= "<option value=\"$sc_store_url?product=$_&amp;cart_id=$cart_id\" target=\"_self\">$dcat</option>\n";
      } else {
         $v_category .= "<a href=\"$html_folder\/0\/$_\.htm\">$dcat</a><br>\n";
         push (@h_category, "<a href=\"$html_folder\/0\/$_\.htm\">$dcat</a>");
         $d_category .= "<option value=\"$html_folder\/0\/$_\.htm\" target=\"_self\">$dcat</option>\n";
      }
   }
   close (CATFILE);

   $h_category = join('&nbsp;|&nbsp;', @h_category);

   $d_category .= qq~
      </SELECT>
   ~;

   return ($d_category, $v_category, $h_category);
}

############################################################
# mini_cart
############################################################

sub mini_cart
{
   my ($mini_cart, $mc_count, $mc_quantity, $mc_price, $mc_total_cost);
   my ($mc_product, $mc_id);

   open (CART, "$sc_cart_path");
   while (<CART>)
   {
      $mc_count++;
      @mc_cart_fields = split (/\|/, $_);
      $mc_quantity    = $mc_cart_fields[$cart{"quantity"}];
      $mc_product     = $mc_cart_fields[$cart{"product"}];
      $mc_price       = $mc_cart_fields[$cart{"price_after_options"}];
      $mc_total_cost += $mc_quantity * $mc_price;
      $mc_id = $mc_cart_fields[$cart{"product_id"}];

      # If using buy now button where pid is 0 then just return to home page.
      if ($mc_cart_fields[$cart{"product_id"}] > 0)
      {
         $mc_contents.= qq~
            + <a href="$sc_store_url?pid=$mc_id&amp;product=$mc_product&amp;cart_id=$cart_id">
            $mc_cart_fields[$cart{"name"}]</a><br>
         ~;
      } else {
         $mc_contents.= qq~
            + $mc_cart_fields[$cart{"name"}]<br>
         ~;
      }
   }
   close (CART);

   $cart_total = &display_price(&format_price($mc_total_cost));

   if ($mc_count > 0)
   {
      $minicart = qq~
         $mc_contents
         <div>&nbsp;</div>
         <div>Items in cart: $mc_count </div>
         <div>Sub Total: $cart_total</div>
      ~;
   } else {
      $minicart = qq~
         + Your cart is empty<br><br>Items in cart: 0 <br>Sub Total: $cart_total
      ~;
   }
   return ($minicart);
}

#######################################################################
# Create links to all the pages in the pages directory
#######################################################################

sub pages
{
   local ($pages, $pname, $ext);

   opendir(PAGES,"$Path/pages") || &errorcode(__FILE__, __LINE__, "$Path/pages", "$!", "print", "OPENDIR ERROR", "3");
   @pnames = readdir(PAGES);
   for $pnames(@pnames)
   {
      ($pname, $ext) = split (/\./, $pnames);
      $pname =~ s/_/ /g;

      if ($pname && $pname ne "Home" && $ext eq "htm")
      {
         if ($ENV{'REQUEST_URI'} =~ /commerce.cgi/i || !($use_html))
         {
            $pages   .= "<a href=\"$sc_store_url?page=$pnames&amp;cart_id=$cart_id\">$pname</a><br>\n";
            $h_pages .= "|&nbsp;&nbsp;<a href=\"$sc_store_url?page=$pnames&amp;cart_id=$cart_id\">$pname</a>\n";
         } else {
            $pages   .= "<a href=\"$html_folder\/$pnames\">$pname</a><br>\n";
            $h_pages .= "|&nbsp;&nbsp;<a href=\"$html_folder\/$pnames\">$pname</a>\n";
         }
      }
   }
   close (PAGES);
   return ($pages, $h_pages);
}

#################################################################
# display_price
#################################################################

sub display_price
{
   local ($price) = @_;
   local ($format_price);

   if ($sc_money_symbol_placement eq "front")
   {
      $format_price = "$sc_money_symbol $price";
   } else {
      $format_price = "$price $sc_money_symbol";
   }

   return $format_price;
}

1;
