############################################################
#                       SENDMAIL_LIB.PL
#
# Special Notes: Script is UNIX Specific and ties into the
# Sendmail Program which is usually located in /usr/lib or
# /usr/bin.
#
# Also, remember to escape @ signs with a backslash (\@)
# for compatibility with PERL 5.
#
# Change the $mail_program variable to change location of your
# sendmail program
#
############################################################

$sc_mail_lib_was_loaded = "yes";

# $mail_program is the mail program used to send mail
# with the full path.
#
# The -t flag tells sendmail to
#
# NOTE: BY DEFAULT, I AM NOT USING -n and -f flags.
#
# -n is not supported by QMAILs sendmail replacement.
#
# -f is useful for special cases and can be added as needed.
#
# The -n flag tells sendmail not to use the alias list
# for the UNIX server.  We do not want outsiders using
# the alias list of the webserver in most cases.
#
# The -f flag followed by an email address of your choice
# basically tells sendmail that this email address
# should have bounced mails forwarded.

$flags = "-i -t";

# The following code checks for versions of
# sendmail and lets the user know if one of the
# default locations does not exist.

$mailer  = '/usr/lib/sendmail';
$mailer1 = '/usr/bin/sendmail';
$mailer2 = '/usr/sbin/sendmail';
if ( -e $mailer) {
    $mail_program=$mailer;
} elsif( -e $mailer1){
    $mail_program=$mailer1;
} elsif( -e $mailer2){
    $mail_program=$mailer2;
} else {
    print "Content-type: text/html\n\n";
    print "I can't find sendmail, shutting down...<br>";
    print "Whoever set this machine up put it someplace weird.";
    exit;
}

# Add the command line flags
$mail_program = "$mail_program $flags ";

############################################################
# send_mail
############################################################

sub send_mail
{
   local($from, $to, $subject, $messagebody) = @_;
   local($old_path) = $ENV{"PATH"};

   $ENV{"PATH"} = "";
   $ENV{ENV} = "";

   open (MAIL, "|$mail_program") || print "Could Not Open Mail Program!";

   $ENV{"PATH"} = $old_path;

   print MAIL "To: $to\n";
   print MAIL "From: $from\n";
   print MAIL "Subject: $subject\n\n";
   print MAIL "$messagebody\n\n";
   close (MAIL);

}

1;
