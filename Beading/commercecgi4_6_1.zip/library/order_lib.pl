############################################################
# Process Order Form
############################################################

sub process_order_form
{
	local($subtotal, $total_quantity, $total_measured_quantity);
	local($text_of_cart, $required_fields_filled_in);

   $gateway_prep = $gateway . "_gateway_prep";
   &{$gateway_prep};

	$required_fields_filled_in = "yes";

   foreach $required_field (@sc_order_form_required_fields)
   {
      if ($form_data{$required_field} eq "")
      {
         $required_fields_filled_in = "no";
#         $error_message .= qq~         ~;
         $field = $required_field . "_error";
         $form_data{$field} = "* $sc_order_form_array->{$required_field}";
      }
   }

   $form_data{'security_key'} = uc($form_data{'security_key'});

   $hidden_security_key = &hmac_hex($form_data{'security_key'} ."^",$encrypt_key);
   if ($form_data{'hidden_security_key'} ne $hidden_security_key)
   {
      $form_data{'security_key_error'} = "Key does not match! Try again....";
      $required_fields_filled_in = "no"
   }

   # Start of the email validation code:

   if ($form_data{'Ecom_BillTo_Online_Email'} ne "")
	{

      if (! &valid_address($form_data{'Ecom_BillTo_Online_Email'}))
      {
         $required_fields_filled_in = "no";
         $form_data{Ecom_BillTo_Online_Email_error} = "Please enter a valid email address!";
      }
	}

	# END of the email validation code:

   # Start of the credit card validation code:

   if ($form_data{'Ecom_Payment_Card_ExpDate_Month'} && $form_data{'Ecom_Payment_Card_ExpDate_Year'} && $form_data{"Ecom_Payment_Card_Type"} && $form_data{"Ecom_Payment_Card_Number"})
   {
      require "$sc_library_directory_path/credit_card_validation_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/credit_card_validation_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");

   	$CC_exp_date = $form_data{'Ecom_Payment_Card_ExpDate_Month'} . '/' .
                     $form_data{'Ecom_Payment_Card_ExpDate_Year'};

     ($error_code, $error_message) = &validate_credit_card_information(
                                     $form_data{"Ecom_Payment_Card_Type"},
                                     $form_data{"Ecom_Payment_Card_Number"},
                                     $CC_exp_date);
   }

	if($error_code != 0)
	{
	   $required_fields_filled_in = "no";
	}

	# END of the credit card validation code:

	if ($required_fields_filled_in eq "yes")
	{
	   &display_cart_table("verify", "$required_fields_filled_in");
	   &{$gateway . "_printSubmitPage"};
      &StoreFooter("secure");
	} else {
	   &{$gateway . "_display_order_form"};
	}
} # End of process_order_form

############################################################
# calculate_final_values
############################################################

sub calculate_final_values
{
	local($shipKey, $shipMethod) = split (/\|/,$form_data{'upgradeShipping'});
	local($subtotal, $total_quantity, $total_measured_quantity) = @_;
	local($temp_total) = 0;
	local($grand_total) = 0;
	local($final_shipping, $shipping);
	local($final_discount, $discount);
	local($final_sales_tax, $sales_tax);
	local($calc_loop) = 0;

	$temp_total = $subtotal;

	for (1..3)
	{
		$shipping  = 0;
		$discount  = 0;
		$sales_tax = 0;
		$calc_loop = $_;

		if ($sc_calculate_discount_at_process_form == $calc_loop)
		{
		   require "$sc_library_directory_path/discount_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/discount_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
			$discount = &calculate_discount($temp_total, $total_quantity, $total_measured_quantity);
		}

		if ($sc_calculate_shipping_at_process_form == $calc_loop)
		{
		   require "$sc_library_directory_path/shipping_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/shipping_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
			$shipping = &calculate_shipping($temp_total, $total_measured_quantity);
		}

		if ($sc_calculate_sales_tax_at_process_form == $calc_loop)
		{
		   require "$sc_library_directory_path/sales_tax_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_library_directory_path/sale_tax_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
			$sales_tax = &calculate_sales_tax($temp_total);
		}

      $final_discount  = $discount if ($discount > 0);
      $final_shipping  = $shipping if ($shipping > 0);
      $final_sales_tax = $sales_tax if ($sales_tax > 0);

	   $temp_total = $temp_total - $discount + $shipping + $sales_tax;
	}

	$grand_total = &format_price($temp_total);

	return ($final_shipping, $final_discount, $final_sales_tax, $grand_total);
}

###########################################################
# Validate the email Address
###########################################################

sub valid_address
{
   my($addr) = @_;
   my($domain, $valid);
   return(0) unless ($addr =~ /^[^@]+@([-\w]+\.)+[A-Za-z]{2,4}$/);
   $domain = (split(/@/, $addr))[1];
   $valid = 1;
   return($valid);
}

1;