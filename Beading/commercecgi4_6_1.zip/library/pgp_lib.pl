############################################################
#                       PGP-LIB.PL
#
# Special Notes: Script ties into the pgp executable whose
#  location is specified in the variables below.
#
# *** THIS VERSION OF PGP-LIB.PL WAS MODIFIED TO WORK WITH PGP version 5
# *** ON LINUX
#
# VARIABLES:
#  $pgp_path = path to PGP executable
#  $pgp_options = command line options to the PGP program
#  $pgp_public_key_user_id = which key to use for encrypting
#  $pgp_config_files = path where configuration files are located
#
############################################################

if ($pgp_or_gpg eq "GnuPG")
{
   $pgp1  = '/usr/local/bin/gpg';
   $pgp2  = '/usr/bin/gpg';
   $pgp_options = "--home $pgp_config_files --always-trust --batch -q -a -e -r";
} else {
   $pgp1  = '/usr/local/bin/pgp';
   $pgp2  = '/usr/bin/pgp';
   $pgp_options = "-atz -f -r";
}

if (-e $pgp_server_path)
{
   $pgp_path = $pgp_server_path;
} elsif ( -e $pgp1) {
    $pgp_path = $pgp1;
} elsif( -e $pgp2){
    $pgp_path = $pgp2;
} else {
    print "Unable to locate $pgp_or_gpg at the path supplied!<br>";
    exit;
}

############################################################
# make_pgp_file
############################################################

sub make_pgp_file
{
   local($output_text, $output_file) = @_;
   local($pgp_output);

#   if ($pgp_add_crlf eq 'yes')
#   {
#      $output_text =~ s/\n/\n\r/g;
#   }

   $ENV{"PGPPATH"} = $pgp_config_files;

   $pgp_command =  "$pgp_path $pgp_options ";
   $pgp_command .= "$pgp_public_key_user_id ";

   open (SAVEERR, ">&STDERR") || die ("Could not capture STDERR $!");
   open (SAVEOUT, ">&STDOUT") || die ("Could not capture STDOUT $!");
   open (STDOUT, ">$output_file");
   open (STDERR, ">&STDOUT");

   $pid = open (PGPCOMMAND, "|$pgp_command");
   print PGPCOMMAND $output_text;
   close (PGPCOMMAND);

   close (STDOUT)             || die ("Error closing STDOUT $!");
   close (STDERR)             || die ("Error closing STDERR $!");

   open (STDERR,">&SAVEERR")  || die ("Could not reset STDERR $!");
   open (STDOUT,">&SAVEOUT")  || die ("Could not reset STDOUT $!");

   close (SAVEERR)            || die ("Error closing SAVEERR $!");
   close (SAVEOUT)            || die ("Error closing SAVEOUT $!");

   open(PGPOUTPUT, $output_file);
   my $insidepgp = 0;
   while (<PGPOUTPUT>)
   {
      $insidepgp = 1 if (/BEGIN PGP/i);
   	if ($insidepgp)
   	{
   	   $pgp_output .= $_;
   	}

   	$pgp_error_data .= "$_";
   }
   close (PGPOUTPUT);

   if (!defined($pid))
   {
      &errorcode(__FILE__, __LINE__, "$pgp_command", "No response from program!", "ignore", "PGP ERROR", "11");
      $pgp_output = "";
   }

   if (!$pgp_output)
   {
      &errorcode(__FILE__, __LINE__, "$pgp_command", "<br>$pgp_error_data;", "ignore", "PGP ERROR: No Data", "12");
      $pgp_output = "";
   }

   unlink($output_file);

   return($pgp_output);
}

1;
