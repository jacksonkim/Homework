############################################################
# calculate_sales_tax
############################################################

sub calculate_sales_tax
{
   local($subtotal) = @_;
   local($sales_tax) = 0;
   local($logic, $fields);

	open(SALESTAXFILE, "$sc_log_file_directory_path/sales_tax.txt") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/sales_tax.txt", "$!", "print", "FILE OPEN ERROR", "1");
	while (<SALESTAXFILE>)
	{
      @fields = split(/\|/, $_);
      if ((uc($form_data{$fields[0]}) eq uc($fields[1])) || ($fields[1] eq ""))
      {
         $sales_tax += $subtotal * $fields[2];
      }
	}
	close (SALESTAXFILE);

   return (&format_price($sales_tax));
}

1;