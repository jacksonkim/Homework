############################################################################
# Main Shipping Routine
############################################################################

sub calculate_shipping
{
   local ($subtotal, $total_weight) = @_;
   local ($total_shipping);
   local ($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

   open(SHIPPINGFILE, "$sc_log_file_directory_path/shipping.txt") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/shipping.txt", "$!", "print", "FILE OPEN ERROR", "1");
   while (<SHIPPINGFILE>)
   {
      @ship_options = split(/\|/, $_);
      if ($ship_options[0] eq $shipKey)
      {
         $shipping_price   = $ship_options[2];
         $shipping_percent = $ship_options[3];
         $shipping_weight  = $ship_options[4];
         $shipping_sub     = $ship_options[5];
         chomp $shipping_sub;
      }
   }
   close (SHIPPINGFILE);

   if ($shipping_price)
   {
      $total_shipping += $shipping_price;
   }

   if ($shipping_percent)
   {
      $total_shipping += $subtotal*($shipping_percent/100);
   }

   if ($shipping_weight eq "yes")
   {
      $total_shipping += $total_weight;
   }

   if ($shipping_sub)
   {
      $shipping_sub =~ /([\w]+)/;
      $total_shipping += &{$shipping_sub}($shipKey, $subtotal, $total_weight, $total_shipping);
   }

   return ($total_shipping);
}

1;