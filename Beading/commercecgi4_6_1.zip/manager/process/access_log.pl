#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$access_log_file = "$Path1/data_files/access.log";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('Access Log',          'tracking_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub tracking_screen
{
	print qq~
		<CENTER>
		<TABLE WIDTH=90%>
		<TR>
		<TD>
		<FONT FACE=ARIAL>
		Welcome to the <b>Commerce.cgi</b> Tracking Manager. Here you will learn some important information about
		your visitors and your store.
		</FONT>
		</TD>
		</TR>
		</TABLE>
		<CENTER>

		<TABLE WIDTH=90%>
		<TR>
		<TD>
		<table border="0" cellpadding="3" cellspacing="0" width="100%" bgcolor="$table_color">
		<tr>
		<td width="100%"><font color="#FFFFFF" face="Arial">
		<b>These are the pages that are linking to your store</b>
		</font></td>
		</tr>
		</table>
		<br>
	~;

	open (DATABASE, "$access_log_file") || &errorcode(__FILE__, __LINE__, "$access_log_file", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has readable permissions");

	while(<DATABASE>)
	{
		($url, $shortdate, $requested_page, $visit_number, $ip_address, $browser_type, $referring_page, $unix_date) = split(/\|/, $_);
		# keep the urls 110 characters or less for better display
		$referring_page = substr($referring_page, 0, 110);
		$requested_page = substr($requested_page, 0, 110);

		foreach ($referring_page)
		{
			if ($requested_page ne "")
			{
				$referring_page_count{$referring_page}++;
			}
		}

		foreach ($requested_page)
		{
			if ($referring_page eq "possible bookmarks")
			{
				if ($requested_page ne "")
				{
					$count_bookmarked_pages{$requested_page}++;
				}
			}

			foreach ($requested_page)
			{
				if ($requested_page ne "")
				{
					$count_first_hit_pages{$requested_page}++;
				}
			}

			foreach ($ip_address)
			{
				if ($ip_address ne "")
				{
					$count_ip{$ip_address}++;
				}
			}

			foreach ($visit_number)
			{
				if ($visit_number ne "")
				{

					$count_visit{$visit_number}++;
				}
			}

			foreach ($browser_type)
			{
				if ($browser_type ne ""){
					$count_browser{$browser_type}++;
				}
			}
		}
	}
	close DATABASE;

	foreach $referring_page (sort { $referring_page_count{$b} <=> $referring_page_count{$a} } keys %referring_page_count) {
		if ($referring_page_count{$referring_page} > 1)
		{
			print qq~
				$referring_page_count{$referring_page} visits from <a href=$referring_page>$referring_page</a><br>
			~;
		}
	}

	print qq~
		<br>
		<table border="0" cellpadding="3" cellspacing="0" width="100%" bgcolor="$table_color">
		<tr>
		<td width="100%"><font color="#FFFFFF" face="Arial">
		<b>These pages appear to be accessed directly, possibly through a bookmark.</b>
		</font></td>
		</tr>
		</table>
		<br>
	~;

	foreach $requested_page (sort { $count_bookmarked_pages{$b} <=> $count_bookmarked_pages{$a} } keys %count_bookmarked_pages)
	{
		if ($count_bookmarked_pages{$requested_page} > 1)
		{
			print qq~
				$count_bookmarked_pages{$requested_page} visits to <a href=$requested_page>$requested_page</a><br>
			~;
		}
	}

	print qq~
		<br>
		<table border="0" cellpadding="3" cellspacing="0" width="100%" bgcolor="$table_color">
		<tr>
		<td width="100%"><font color="#FFFFFF" face="Arial">
		<b>These pages were accessed first during visits to your store</b>
		</font></td>
		</tr>
		</table>
		<br>
	~;

	foreach $requested_page (sort { $count_first_hit_pages{$b} <=> $count_first_hit_pages{$a} } keys %count_first_hit_pages)
	{
		if ($count_first_hit_pages{$requested_page} > 1)
		{
			print qq~
				$count_first_hit_pages{$requested_page} first visits to <a href=$requested_page>$requested_page</a><br>
			~;
		}
	}

	print qq~
		<br>
		<table border="0" cellpadding="3" cellspacing="0" width="100%" bgcolor="$table_color">
		<tr>
		<td width="100%"><font color="#FFFFFF" face="Arial">
		<b>I.P. Addresses of the visitors to your store.</b>
		</font></td>
		</tr>
		</table>
		<br>
	~;

	foreach $ip_address (sort { $count_ip{$b} <=> $count_ip{$a} } keys %count_ip)
	{
		if ($count_ip{$ip_address} > 1)
		{
			print qq~
				$count_ip{$ip_address} visitors from I.P. address <a href=http://$ip_address>$ip_address</a>.<br>
			~;
		}
	}

	print qq~
		<br>
		<table border="0" cellpadding="3" cellspacing="0" width="100%" bgcolor="$table_color">
		<tr>
		<td width="100%"><font color="#FFFFFF" face="Arial">
		<b>Web browsers your visitors are using.</b>
		</font></td>
		</tr>
		</table>
		<br>
	~;

	foreach $browser_type (sort { $count_browser{$b} <=> $count_browser{$a} } keys %count_browser)
	{
		if ($count_browser{$browser_type} > 1)
		{
			print qq~
				$count_browser{$browser_type} visitors use $browser_type as a web browser.<br>
			~;
		}
	}

	print qq~
		<BR>
		</FONT>
		</TD>
		</TR>
		</TABLE>
		</CENTER>
		<form method="POST">
		<input type=hidden name=action value=clear_access_log>
		<p align="center"><input type="submit" value="     Clear Access Log     "></p>
		</form>
	~;
}

#############################################################################################

sub clear_access_log
{
   open (ALOG, ">$access_log_file") || print "Error clearing access log!";
   close (ALOG);
	&tracking_screen;
}

#############################################################################################

1;