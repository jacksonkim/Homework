#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action2 = ('Add Product',          'add_product');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub action_add_product
{
	local ($sku, $category, $price, $short_description, $image, $long_description);
	local ($shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree);
	local ($userDefinedFour, $userDefinedFive, $options);

	open (CHECKSKU, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has readable permissions");

	while(<CHECKSKU>)
	{
		($sku, $category, $price, $short_description, $image, $long_description, $shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree, $userDefinedFour, $userDefinedFive, $options) = split(/\|/,$_);
		chop($options);
		foreach ($sku)
		{
			if ($sku eq $form_data{'sku'})
			{
				#print "sku already exists!";
				$add_product_status="no";
				&add_product($add_product_status);
				exit;
			}

		# End of foreach
		}
	# End of while CHECKSKU
	}
	close (CHECKSKU);

	$formatted_description = $form_data{'description'};
	$formatted_description =~ s/\r/ /g;
	$formatted_description =~ s/\t/ /g;
	$formatted_description =~ s/\n/ /g;
	$formatted_description =~ s/\"/\&quot\;/g;

	$form_data{'category'} =~ s/\"/\&quot\;/g;
	$form_data{'name'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedOne'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedTwo'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedThree'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedFour'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedFive'} =~ s/\"/\&quot\;/g;

	##
	if ($form_data{'image'} ne "")
	{
		$formatted_image = $form_data{'image'};
	} else {
		$formatted_image = "notavailable.gif";
	}

	##
	if ($form_data{'option_file'} ne "")
	{
		if (-e "$Path1/options/" . $form_data{'option_file'})
		{
			$formatted_option_file = "\%\%OPTION\%\%" . $form_data{'option_file'};
		} else {
			$formatted_option_file = "\%\%OPTION\%\%blank.html";
		}
	} else {
		$formatted_option_file = "\%\%OPTION\%\%blank.html";
	}
	##

	open (NEW, "+>> $datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
	print (NEW  $form_data{'sku'} . "|" . $form_data{'category'} . "|" . $form_data{'price'} . "|" . $form_data{'name'} . "|$formatted_image|$formatted_description|" . $form_data{'shipping_price'} . "|" . $form_data{'userDefinedOne'} . "|" . $form_data{'userDefinedTwo'} . "|" . $form_data{'userDefinedThree'} . "|" . $form_data{'userDefinedFour'} . "|" . $form_data{'userDefinedFive'} . "|$formatted_option_file\n");
	close(NEW);

	$add_product_status="yes";
	&add_product($add_product_status);

}

#######################################################################################
sub add_product
{
	local($add_product_success) = @_;
	local ($sku, $category, $price, $short_description, $image);
	local ($long_description, $shipping_price, $userDefinedOne);
	local ($userDefinedTwo, $userDefinedThree, $userDefinedFour);
	local ($userDefinedFive, $options);

	open (NEWSKU, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
		while(<NEWSKU>)
		{
			($sku, $category, $price, $short_description, $image, $long_description, $options) = split(/\|/,$_);
			chop($options);
			if ($sku > $new_sku)
			{
				$new_sku = $sku;
			}
		}
	close(NEWSKU);

	$new_sku++;

   $unixpath = "$Path1/options";
   opendir(CURDIR,"$unixpath") || &errorcode(__FILE__, __LINE__, "$unixpath", "$!", "die", "DIRECTORY OPEN ERROR", "Unable to open the directory listed. Make sure that it exists and that it has read permissions");
   @names=readdir(CURDIR);
   for $name(@names)
   {
      ($iname, $ext, $inc) = split(/\./,$name);
      if (($ext eq "html")||($ext eq "htm"))
      {
         if ($inc ne "inc")
         {
            $options .= "<option>$name</option>\n";
         }
      }
   }

	##

	print qq~
		<CENTER>
		<TABLE WIDTH=90%>
		<TR>
		<TD>
	    <FONT FACE=ARIAL>
		This is the Add-A-Product screen of the <b>Commerce.cgi</b> product manager. Just follow the directions and add products to your store right through your web browser.</TD>
		</TR>
		</TABLE>
		</CENTER>
		<CENTER>
		<HR WIDTH=90% noshade size="1" color="#000000">
		</CENTER>
	~;

	if($add_product_success eq "yes")
	{
		$category = $form_data{'category'};
		$sku = $form_data{'sku'};

		print qq~
			<CENTER>
			<TABLE>
			<TR>
			<TD>
			<FONT FACE=ARIAL SIZE=2 COLOR=RED>Product number <a href=../commerce.cgi?product=$category>$sku</a> has been added to the catalog.</FONT>
			</TD>
			</TR>
			</TABLE>
			</CENTER>
		~;

	} elsif($add_product_success eq "no") {
		print qq~
			<CENTER>
			<TABLE>
			<TR>
			<TD>
			<FONT FACE=ARIAL SIZE=2 COLOR=RED>Reference # already exists in datafile! Unable to add product, please choose a new Reference # number.</FONT>
			</TD>
			</TR>
			</TABLE>
			</CENTER>
		~;
	}

	open(CATFILE, "$catfile") || &errorcode(__FILE__, __LINE__, "$catfile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
	while (<CATFILE>)
	{
		$catdata .= "<option>$_</option>\n";
	}
	close (CATFILE);

	print qq~

		<FORM METHOD="POST">
		<div align="center">
		<center>
		<table border="0" cellpadding="0" cellspacing="0" width="90%">
		<tr>
      <td width="100%">
		<div align="center">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tr>
		<td width="100%" colspan="4" bgcolor="$table_color">
		<p><b><font face="Arial" color="#FFFFFF">&nbsp;Product&nbsp; #$new_sku</font></b></p>
		</td>
		</tr>
		<CENTER>
		<tr>
		<td colspan="4" bgcolor="$table_color"></td>
		</tr>
		<tr>
		<td colspan="3" bgcolor="$table_color"><font color="#FFFFFF">&nbsp;</font></td>
		<td width="100%" bgcolor="$table_color"> <FONT face=ARIAL SIZE=2 color="#FFFFFF"><br>
		Select category for product
		</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="3">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Category:&nbsp;</font></b> </p>
		</td>
		<CENTER>
		<td>
		<select size="1" name="category">
	   $catdata
		</select>
		</td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td bgcolor="$table_color">&nbsp;</td>
		<td colspan="3" bgcolor="$table_color"> <FONT face=ARIAL SIZE=2 color="#FFFFFF"> 3 or 4 words</font></td>
		</tr>

		</CENTER>
		<tr>
		<td>
		<p align="right"><b><FONT face=ARIAL SIZE=2>Product Name:&nbsp;</font></b> </p>
		</td>
		<CENTER>
		<td colspan="3"><font face="Arial"><INPUT NAME="name" TYPE="TEXT" SIZE=45></font></td>
		</tr>
		<tr>
		<td colspan="4"><font face="Arial" size="2">&nbsp;</font></td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="2" bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF">No \$ sign needed</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2">
		<p align="right"><font face="Arial" size="2"><b>Price:&nbsp;</b> </font></td>
		<CENTER>
		<td colspan="2"><font face="Arial"><INPUT NAME="price" TYPE="TEXT" SIZE=14></font></td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="2" bgcolor="$table_color"> <FONT face=ARIAL SIZE=2 color="#FFFFFF">Enter the HTML for your product description here. </font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2" valign="top">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Description:&nbsp;
		</font></b> </p>
		</td>
		<CENTER>
		<td colspan="2"><font face="Arial"><TEXTAREA NAME="description" ROWS=6 COLS=51 wrap=soft></TEXTAREA></font></td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="3" bgcolor="$table_color">&nbsp;</td>
		<td bgcolor="$table_color"> <FONT face=ARIAL SIZE=2 color="#FFFFFF"> filename.gif</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="3">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Image File:&nbsp;</font></b> </p>
		</td>
		<CENTER>
		<td><font face="Arial"><INPUT NAME="image" TYPE="TEXT" SIZE=35></font></td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="2" bgcolor="$table_color"><FONT face=ARIAL SIZE=2 color="#FFFFFF">filename.html</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Option File</font></b><FONT face=ARIAL SIZE=2><b>:&nbsp;</b> </font></td>
		<CENTER>
		<td colspan="2"><font face="Arial">

		<select size="1" name="option_file">
		<option></option>
		$options
		</select>

		</font></td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="2" bgcolor="$table_color">
		<font size="2" face="Arial" color="#FFFFFF">$shipping_title_desc.</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2">
		<p align="right"><b><FONT face=ARIAL SIZE=2>$shipping_title_name:&nbsp;</font></b></p>
		</td>
		<CENTER>
		<td colspan="2"><font face="Arial"><INPUT NAME="shipping_price" TYPE="TEXT" SIZE=11 VALUE="0.00"></font></td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="4">
		<hr noshade size="1" color="#000000">
		</td>
		</tr>
		<tr>
		<td colspan="4" bgcolor="$table_color">
		<p align="center"><font face="Arial" color="#FFFFFF"><b>Additional Information</b></font>
		<blockquote>
		<p align="left"><font face="Arial" size="2" color="#FFFFFF">By default these fields
		are not used for anything by the shopping cart. These are just extra
		fields that have been added to the products.txt file to allow for expansion of
		the script, or for use in custom modifications that someone may want
		to make.</font></p>
		</blockquote>
		</td>
		</tr>
		<tr>
		<td colspan="4">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$userone_title:&nbsp;</font></td>
		<td colspan="2"><font face="Arial"><INPUT NAME="userDefinedOne" TYPE="TEXT" SIZE=35></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$usertwo_title:&nbsp;</font></td>
		<td colspan="2"><font face="Arial"><INPUT NAME="userDefinedTwo" TYPE="TEXT" SIZE=35></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right" nowrap><FONT face=ARIAL SIZE=2 COLOR="RED">$userthree_title:&nbsp;</font></td>
		<td colspan="2"><font face="Arial"><INPUT NAME="userDefinedThree" TYPE="TEXT" SIZE=35></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$userfour_title:&nbsp;</font></td>
		<td colspan="2"><font face="Arial"><INPUT NAME="userDefinedFour" TYPE="TEXT" SIZE=35></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$userfive_title:&nbsp;</font></td>
		<td colspan="2"><font face="Arial"><INPUT NAME="userDefinedFive" TYPE="TEXT" SIZE=35></font></td>
		</tr>
		<tr>
		<td colspan="4">
		<hr noshade size="1" color="#000000">
		</td>
		</tr>
		<tr>
		<td colspan="2"></td>
		<td colspan="2">&nbsp;</td>
		</tr>
		</table>
		</div>
		<table border="0" cellpadding="0" cellspacing="0" width="90%">
		<tr>
		<td width="100%">
		<p align="center"><font face="Arial">
		<INPUT TYPE=HIDDEN NAME=sku VALUE="$new_sku">
		<INPUT TYPE=HIDDEN NAME=action VALUE="action_add_product">
		<INPUT TYPE=SUBMIT NAME=AddProduct VALUE="     Add Product     ">
		</font></p>
		</td>
		</tr>
		</table>
		<p><font face="Arial">&nbsp;</font></p>

		</CENTER>
      </td>
		</tr>
		</table>
		</center>
		</div>
		<CENTER>
		<p>&nbsp;</p>

		</CENTER>
		</FORM>
	~;
}

#############################################################################################

1;