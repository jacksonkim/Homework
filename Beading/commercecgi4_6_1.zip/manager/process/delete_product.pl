#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action2 = ('Delete Product',          'delete_categories');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub delete_categories
{
	local ($category, $bgcolor);
	open(DATAFILE, "$datafile");
	while (<DATAFILE>)
	{
		@db_row = split(/\|/,$_);
		$category_list{$db_row[1]}++;
	}
	close (DATAFILE);

	print qq~
		<!-- Start Categories -->
		<p align="center"><font face="Arial">Select the category that contains the
		product you want to <b>DELETE</b>!</font></p>
		<div align="center">
		<center>
		<table border="0" cellpadding="3" cellspacing="0" width="90%">
		<tr>
		<td bgcolor="$table_color"><font face="Arial" color="#FFFFFF"><b>Category</b></font></td>
		<td bgcolor="$table_color"><font face="Arial" color="#FFFFFF"><b>Count</b></font></td>
		</tr>
	~;

	foreach $category (sort(keys(%category_list)))
	{
		$display_cat = $category;
		$display_cat =~ s/_/ /g;
		if ($bgcolor eq "#FFFFFF")
		{
			$bgcolor = "#EBEBEB";
		} else {
			$bgcolor = "#FFFFFF";
		}

		print qq~
			<tr>
	      <td bgcolor="$bgcolor">
	      <a href="index.cgi?action=delete_product_screen&category=$category">
	      <font face="Arial">$display_cat</font></a></td>
	      <td bgcolor="$bgcolor">
	      <font face="Arial">$category_list{$category}</font></td>
	      </tr>
		~;
	}

	print qq~
		</table>
		</center>
		</div>
		<!-- End Categories -->
	~;
}

#######################################################################################

sub delete_product_screen
{
	print qq~
		<p align="center"><font face="Arial"><font size="4"><b>
		<FONT COLOR=RED>
		WARNING!</FONT>
		</b>&nbsp;<br>
		</font>Clicking <b>'Delete'</b> will <b> IMMEDIATELY</b> remove that product from your catalog.</font></p>
	~;

	if ($form_data{'DeleteWhichProduct'} ne "")
	{
		$DeleteWhichProduct = $form_data{'DeleteWhichProduct'};
		print qq~
			<p align="center"><FONT FACE=ARIAL SIZE=2 COLOR=RED><b>Reference \# $DeleteWhichProduct successfully deleted!</b></FONT></p>
		~;
	}

	print qq~
		<CENTER>
        <div align="center">
          <center>
		<TABLE WIDTH=90% BORDER=0 cellspacing="0" cellpadding="3">
		<TR WIDTH=550>
		<TD bgcolor="$table_color">
		<b><FONT color=#FFFFFF face="Arial">Delete</FONT></b>
		</TD>
		<TD bgcolor="$table_color">
		<B><font face="Arial" color="#FFFFFF">Ref. #</font></B>
		</TD>
		<TD bgcolor="$table_color">
		<B><font face="Arial" color="#FFFFFF">Category</font></B>
		</TD>
		<TD bgcolor="$table_color">
        <b><font face="Arial" color="#FFFFFF">Name</font></b>
		</TD>
		<TD bgcolor="$table_color">
		<B><font face="Arial" color="#FFFFFF">Price</font></B>
		</TD>
		</TR>
	~;

	open (DATABASE, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
	while(<DATABASE>)
	{
		($sku, $category, $price, $short_description, $image, $long_description, $options) = split(/\|/,$_);
		chop($options);

		if ($category eq $form_data{'category'})
		{

			if ($bgcolor eq "#FFFFFF")
			{
				$bgcolor = "#EBEBEB";
			} else {
				$bgcolor = "#FFFFFF";
			}

			print qq~
					<TR>
					<TD bgcolor="$bgcolor">
					<font face="Arial"><a href="index.cgi?DeleteWhichProduct=$sku&action=action_delete_product&category=$form_data{'category'}">DELETE</a></font>
					</TD>
					<TD bgcolor="$bgcolor">
               <font face="Arial">$sku</font>
					</TD>
					<TD bgcolor="$bgcolor">
               <font face="Arial">$category</font>
					</TD>
					<TD bgcolor="$bgcolor">
               <font face="Arial">$short_description</font>
					</TD>
					<TD bgcolor="$bgcolor" align="right">
               <font face="Arial">$price</font>
					</TD>
					</TR>
			~;
		}
	}

	print qq~
		</TABLE>
		</center>
		</div>
		</CENTER>
	~;
}
#############################################################################################


sub action_delete_product
{
	local($sku, $category, $price, $short_description, $image, $long_description, $shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree, $userDefinedFour, $userDefinedFive, $options);

	open(OLDFILE, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
		@lines = <OLDFILE>;
	close (OLDFILE);

	open(NEWFILE,">$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
		foreach $line (@lines)
		{
			($sku, $category, $price, $short_description, $image, $long_description, $shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree, $userDefinedFour, $userDefinedFive, $options) = split(/\|/,$line);

			if ($sku == $form_data{'DeleteWhichProduct'})
			{
				$line = "";
			} else {
				print NEWFILE $line;
			}
		}
	close (NEWFILE);

	&delete_product_screen;
}


1;