#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action2 = ('Edit Category',          'edit_cat');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub edit_cat
{
	local ($catdata);

	open(CATFILE, "$catfile") || print "LINE " . __LINE__ . ": Can't open $catfile $!";
	while (<CATFILE>)
	{
		$catdata .= $_;
	}
	close (CATFILE);

	print qq~
      <p align="center"><font face="Arial">If entering more then one word for the category name then put an underscore
      (_)
      between the words and do not use spaces.</font></p>
      <form method="POST">
      <p align="center">
      <textarea rows="11" name="catdata" cols="21">$catdata</textarea></p>
      <INPUT TYPE=HIDDEN NAME=action VALUE="update_cat">
      <p align="center"><input type="submit" value="     Update     "></p>
      </form>
	~;

}

##########################################################

sub update_cat
{
	my ($category, @lines);

   $form_data{'catdata'} =~ s/\r//g;

	# @lines = split(/\n/, $form_data{'catdata'});

	open(CATFILE, "> $catfile") || &errorcode(__FILE__, __LINE__, "$catfile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
# 	foreach $linedata (@lines)
# 	{
# 	   chomp $linedata;
# 		print CATFILE "$linedata\n";
# 	}

   print CATFILE $form_data{'catdata'};
	close (CATFILE);

	&edit_cat;

}




1;