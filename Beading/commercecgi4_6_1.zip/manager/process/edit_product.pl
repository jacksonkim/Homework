#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

# $URL_of_images_directory = "http://www.commerce-cgi.com/commerce401/images";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action2 = ('Edit Product',          'edit_categories');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub edit_categories
{
	local ($category, $bgcolor);
	open(DATAFILE, "$datafile");
	while (<DATAFILE>)
	{
		@db_row = split(/\|/,$_);
		$category_list{$db_row[1]}++;
	}
	close (DATAFILE);

	print qq~
		<!-- Start Categories -->
		<p align="center"><font face="Arial">Select the category that contains the
		product you want to <b>EDIT</b>!</font></p>
		<div align="center">
		<center>
		<table border="0" cellpadding="3" cellspacing="0" width="90%">
		<tr>
		<td bgcolor="$table_color"><font face="Arial" color="#FFFFFF"><b>Category</b></font></td>
		<td bgcolor="$table_color"><font face="Arial" color="#FFFFFF"><b>Count</b></font></td>
		</tr>
	~;

	foreach $category (sort(keys(%category_list)))
	{
		$display_cat = $category;
		$display_cat =~ s/_/ /g;
		if ($bgcolor eq "#FFFFFF")
		{
			$bgcolor = "#EBEBEB";
		} else {
			$bgcolor = "#FFFFFF";
		}

		print qq~
			<tr>
	      <td bgcolor="$bgcolor">
	      <a href="index.cgi?action=edit_product_screen&category=$category">
	      <font face="Arial">$display_cat</font></a></td>
	      <td bgcolor="$bgcolor">
	      <font face="Arial">$category_list{$category}</font></td>
	      </tr>
		~;
	}

	print qq~
		</table>
		</center>
		</div>
		<!-- End Categories -->
	~;
}

#############################################################################################

sub action_submit_edit_product
{
   local($sku, $category, $price, $short_description, $image, $long_description, $shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree, $userDefinedFour, $userDefinedFive, $options);

   $formatted_description = $form_data{'description'};
   $formatted_description =~ s/\r/ /g;
   $formatted_description =~ s/\t/ /g;
   $formatted_description =~ s/\n/ /g;
	$formatted_description =~ s/\"/\&quot\;/g;

	$form_data{'category'} =~ s/\"/\&quot\;/g;
	$form_data{'name'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedOne'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedTwo'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedThree'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedFour'} =~ s/\"/\&quot\;/g;
	$form_data{'userDefinedFive'} =~ s/\"/\&quot\;/g;

   if ($form_data{'image'} ne "")
   {
      $formatted_image = $form_data{'image'};
   } else {
      $formatted_image = "notavailable.gif";
   }

	if ($form_data{'option_file'} ne "")
 	{
		$formatted_option_file = "\%\%OPTION\%\%$form_data{'option_file'}";
	} else {
		$formatted_option_file = "\%\%OPTION\%\%blank.html";
	}

   open(OLDFILE, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   @lines = <OLDFILE>;
   close (OLDFILE);

   open(NEWFILE,">$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   foreach $line (@lines)
   {
      ($sku, $category, $price, $short_description, $image, $long_description, $shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree, $userDefinedFour, $userDefinedFive, $options) = split(/\|/,$line);

      if ($sku == $form_data{'ProductEditSku'})
      {
         print (NEWFILE  $form_data{'ProductEditSku'} . "|" . $form_data{'category'} . "|" . $form_data{'price'} . "|" . $form_data{'name'} . "|$formatted_image|$formatted_description|" . $form_data{'shipping_price'} . "|" . $form_data{'userDefinedOne'} . "|" . $form_data{'userDefinedTwo'} . "|" . $form_data{'userDefinedThree'} . "|" . $form_data{'userDefinedFour'} . "|" . $form_data{'userDefinedFive'} . "|$formatted_option_file\n");
      } else {
         print NEWFILE $line;
      }
   }
   close (NEWFILE);

   &display_perform_edit_screen;

}

#############################################################################################

sub edit_product_screen
{
	local ($bgcolor);
   print qq~
      <CENTER>
      <TABLE WIDTH=90%>
      <TR>
      <TD>
      <FONT FACE=ARIAL>
      This is the Edit-A-Product screen of the <b>Commerce.cgi</b> product manager. Click the <b>'Edit'</b> to make changes to products in your catalog.</TR>
      </TABLE>
      </CENTER>
      <CENTER>
      <HR WIDTH=90%>
      </CENTER>
      <CENTER>

		<div align="center">
		<center>
		<table border="0" cellpadding="0" cellspacing="0" width="90%">
		<tr>
		<td width="100%">
		<div align="center">
		<table border="0" cellpadding="3" cellspacing="0" width="100%">
		<CENTER>
		<tr>
		<td bgcolor="$table_color">
		<B><font color="#FFFFFF" face="Arial">Ref. #</font></B>
		</td>
		<td bgcolor="$table_color">
		<B><font color="#FFFFFF" face="Arial">Category</font></B>
		</td>
		<td bgcolor="$table_color">
		<B><font color="#FFFFFF" face="Arial">Description</font></B>
		</td>
		<td bgcolor="$table_color">
		<B><font color="#FFFFFF" face="Arial" align="right">Price</font></B>
		</td>
		</tr>
   ~;

   open (DATABASE, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");

   while(<DATABASE>)
   {
      ($sku, $category, $price, $short_description, $image, $long_description, $options) = split(/\|/,$_);
      chop($options);
#      foreach ($sku)}

		if ($category eq $form_data{'category'})
      {

   		if ($bgcolor eq "#FFFFFF")
   		{
   			$bgcolor = "#EBEBEB";
   		} else {
   			$bgcolor = "#FFFFFF";
   		}

         print qq~
            <tr>
            <TD WIDTH=100 bgcolor="$bgcolor">
            <a href="index.cgi?EditWhichProduct=$sku&amp;action=display_perform_edit_screen"><font face="Arial">$sku</font></a>

            </TD>
            <TD WIDTH=75 bgcolor="$bgcolor">
            <font face="Arial">$category</font>
            </TD>
            <TD bgcolor="$bgcolor">
            <font face="Arial">$short_description</font>
            </TD>
            <TD WIDTH=75 bgcolor="$bgcolor" align="right">
            <font face="Arial">$price</font>
            </TD>
            </TR>
            </CENTER>
         ~;
      }
   }

   print qq~
		</table>
		</div>
		<p><font face="Arial">&nbsp;</font></p>
		</td>
		</tr>
		</table>
		</center>
		</div>
   ~;

}

#############################################################################################
sub display_perform_edit_screen
{

	open (CHECKSKU, "$datafile") || &errorcode(__FILE__, __LINE__, "$datafile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
	while(<CHECKSKU>)
	{
		($sku, $category, $price, $short_description, $image, $long_description, $shipping_price, $userDefinedOne, $userDefinedTwo, $userDefinedThree, $userDefinedFour, $userDefinedFive, $option) = split(/\|/,$_);
		if ($sku eq $form_data{'EditWhichProduct'})
		{
			$option =~ s/%%OPTION%%//g;
			last;
		}
	}
	close (CHECKSKU);

   $unixpath = "$Path1/options";
   opendir(CURDIR,"$unixpath") || &errorcode(__FILE__, __LINE__, "$unixpath", "$!", "die", "DIRECTORY OPEN ERROR", "Unable to open the directory listed. Make sure that it exists and that it has read permissions");
   @names=readdir(CURDIR);
   for $name(@names)
   {
      ($iname, $ext, $inc) = split(/\./,$name);
      if (($ext eq "html")||($ext eq "htm"))
      {
         if ($inc ne "inc")
         {
            $options .= "<option>$name</option>\n";
         }
      }
   }

	open(CATFILE, "$catfile") || &errorcode(__FILE__, __LINE__, "$catfile", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
	while (<CATFILE>)
	{
		$catdata .= "<option>$_</option>\n";
	}
	close (CATFILE);

	print qq~
		<FORM METHOD="POST">
		<div align="center">
		<center>
		<table border="0" cellpadding="0" cellspacing="0" width="90%">
		<tr>
      <td width="100%">
		<div align="center">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		<tr>
		<td width="100%" colspan="5" bgcolor="$table_color">
		<p><b><font face="Arial" color="#FFFFFF">&nbsp;Product&nbsp; #$sku</font></b></p>
		</td>
		</tr>
		<CENTER>
		<tr>
		<td colspan="5" bgcolor="$table_color"></td>
		</tr>
		<tr>
		<td colspan="3" bgcolor="$table_color"><font color="#FFFFFF">&nbsp;</font></td>
		<td width="100%" bgcolor="$table_color" colspan="2"> <FONT face=ARIAL SIZE=2 color="#FFFFFF"><br>
		Select category for product
		</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="3">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Category:&nbsp;</font></b> </p>
		</td>
		<CENTER>
		<td colspan="2"><font face="Arial">

		<select size="1" name="category">
		<option>$category</option>
		$catdata
		</select>

		</font></td>
		</tr>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td bgcolor="$table_color">&nbsp;</td>
		<td colspan="4" bgcolor="$table_color"> <FONT face=ARIAL SIZE=2 color="#FFFFFF"> 3 or 4 words</font></td>
		</tr>

		</CENTER>
		<tr>
		<td>
		<p align="right"><b><FONT face=ARIAL SIZE=2>Product Name:&nbsp;</font></b> </p>
		</td>
		<CENTER>
		<td colspan="4"><font face="Arial"><INPUT NAME="name" SIZE=45 value="$short_description"></font></td>
		</tr>
		<tr>
		<td colspan="5"><font face="Arial" size="2">&nbsp;</font></td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="3" bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF">No \$ sign needed</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2">
		<p align="right"><font face="Arial" size="2"><b>Price:&nbsp;</b> </font></td>
		<CENTER>
		<td colspan="3"><font face="Arial"><INPUT NAME="price" SIZE=14 value="$price"></font></td>
		</tr>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="3" bgcolor="$table_color"> <FONT face=ARIAL SIZE=2 color="#FFFFFF">Enter the HTML for your product description here. </font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2" valign="top">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Description:&nbsp;
		</font></b> </p>
		</td>
		<CENTER>
		<td colspan="3"><font face="Arial"><TEXTAREA NAME="description" ROWS=6 COLS=51 wrap=soft>$long_description</TEXTAREA></font></td>
		</tr>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="3" bgcolor="$table_color">&nbsp;</td>
		<td bgcolor="$table_color" colspan="2"> <FONT face=ARIAL SIZE=2 color="#FFFFFF"> filename.gif</font></td>
		</tr>
		<tr>
		<td colspan="3" valign="top">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Image File:&nbsp;</font></b> </p>
		</td>
		<CENTER>
		<td valign="top"><font face="Arial"><INPUT NAME="image" SIZE=35 value="$image"></font></td>
  		</center>
		<td>
       <p align="center"><img border="0" src="$URL_of_images_directory/product/small/$image"></td>
		</tr>
		<center>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="3" bgcolor="$table_color"><FONT face=ARIAL SIZE=2 color="#FFFFFF">filename.html</font></td>
		</tr>
		<tr>
		<td colspan="2">
		<p align="right"><b><FONT face=ARIAL SIZE=2>Option File</font></b><FONT face=ARIAL SIZE=2><b>:&nbsp;</b> </font></td>
		<CENTER>
		<td colspan="3"><font face="Arial">

		<select size="1" name="option_file">
		<option>$option</option>
		$options
		</select>

		</font></td>
		</tr>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" bgcolor="$table_color">&nbsp;</td>
		<td colspan="3" bgcolor="$table_color">
		<font size="2" face="Arial" color="#FFFFFF">$shipping_title_desc.</font></td>
		</tr>

		</CENTER>
		<tr>
		<td colspan="2">
		<p align="right"><b><FONT face=ARIAL SIZE=2>$shipping_title_name:&nbsp;</font></b></p>
		</td>
		<CENTER>
		<td colspan="3"><font face="Arial"><INPUT NAME="shipping_price" SIZE=11 VALUE="$shipping_price"></font></td>
		</tr>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="5">
		<hr noshade size="1" color="#000000">
		</td>
		</tr>
		<tr>
		<td colspan="5" bgcolor="$table_color">
		<p align="center"><font face="Arial" color="#FFFFFF"><b>Additional Information</b></font>
		<blockquote>
		<p align="left"><font face="Arial" size="2" color="#FFFFFF">By default these fields
		are not used for anything by the shopping cart. These are just extra
		fields that have been added to the products.txt to allow for expansion of
		the script, or for use in custom modifications that someone may want
		to make.</font></p>
		</blockquote>
		</td>
		</tr>
		<tr>
		<td colspan="5">&nbsp;</td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$userone_title:&nbsp;</font></td>
		<td colspan="3"><font face="Arial"><INPUT NAME="userDefinedOne" SIZE=35 value="$userDefinedOne"></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$usertwo_title:&nbsp;</font></td>
		<td colspan="3"><font face="Arial"><INPUT NAME="userDefinedTwo" SIZE=35 value="$userDefinedTwo"></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right" nowrap><FONT face=ARIAL SIZE=2 COLOR="RED">$userthree_title:&nbsp;</font></td>
		<td colspan="3"><font face="Arial"><INPUT NAME="userDefinedThree" SIZE=35 value="$userDefinedThree"></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$userfour_title:&nbsp;</font></td>
		<td colspan="3"><font face="Arial"><INPUT NAME="userDefinedFour" SIZE=35 value="$userDefinedFour"></font></td>
		</tr>
		<tr>
		<td colspan="2" align="right"><FONT face=ARIAL SIZE=2 COLOR="RED">$userfive_title:&nbsp;</font></td>
		<td colspan="3"><font face="Arial"><INPUT NAME="userDefinedFive" SIZE=35 value="$userDefinedFive"></font></td>
		</tr>
		<tr>
		<td colspan="5">
		<hr noshade size="1" color="#000000">
		</td>
		</tr>
		<tr>
		<td colspan="2"></td>
		<td colspan="3">&nbsp;</td>
		</tr>
		</table>
		</div>
		<table border="0" cellpadding="0" cellspacing="0" width="90%">
		<tr>
		<td width="100%">
		<p align="center"><font face="Arial">
		<INPUT TYPE=HIDDEN NAME=EditWhichProduct VALUE="$sku">
		<INPUT TYPE=HIDDEN NAME=ProductEditSku VALUE="$sku">
		<INPUT TYPE=HIDDEN NAME=action VALUE="action_submit_edit_product">
		<INPUT TYPE=SUBMIT NAME=EditProduct VALUE="     Edit Product     ">
		</font></p>
		</td>
		</tr>
		</table>
		<p><font face="Arial">&nbsp;</font></p>

		</CENTER>
       </td>
       </tr>
       </table>
       </center>
       </div>
		<CENTER>
		<p>&nbsp;</p>

		</CENTER>
		</FORM>
   ~;
}

1;