#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$error_log_file = "$Path1/data_files/error.log";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Error Log',          'error_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub error_screen
{
	print qq~
		<CENTER>
		<TABLE WIDTH=90%>
		<TR>
		<TD>
		<FONT FACE=ARIAL>
		Here are the errors that have been logged for your store.
		</FONT>
		</TD>
		</TR>
		</TABLE>
		<CENTER>

		<TABLE WIDTH=90%>
		<TR>
		<TD>
		<table border="0" cellpadding="3" cellspacing="0" width="100%" bgcolor="$table_color">
		<tr>
		<td width="100%"><font color="#FFFFFF" face="Arial">
		<b>Errors</b>
		</font></td>
		</tr>
		</table>
		<br>
	~;

	open (DATABASE, "$error_log_file") || &errorcode(__FILE__, __LINE__, "$error_log_file", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");

	while(<DATABASE>)
	{
		print "$_<br>";
	}
	close DATABASE;

	print qq~
		<BR>
		</FONT>
		</TD>
		</TR>
		</TABLE>
		</CENTER>
		<form method="POST">
		<input type=hidden name=action value=clear_error_log>
		<p align="center"><input type="submit" value="     Clear Error Log     "></p>
		</form>
	~;
}

#############################################################################################

sub clear_error_log
{
   open (ELOG, ">$error_log_file") || print "Error clearing error log!";
   close (ELOG);
	&error_screen;
}

#############################################################################################


1;