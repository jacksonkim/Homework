#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$gateway_settings = "$Path1/configuration/$form_data{'gateway_name'}-user_lib.pl";
$gateway_lib		= "$Path1/gateway/$form_data{'gateway_name'}-order_lib.pl";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Gateway Settings',          'gateway_settings');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub gateway_settings
{
	opendir (GATEWAY, "$Path1/gateway") || &errorcode(__FILE__, __LINE__, "$Path1/gateway", "$!", "die", "DIRECTORY OPEN ERROR", "Unable to open the directory listed. Make sure that it exists and that it has read permissions");
	@extra_libs = readdir(GATEWAY);
	for $extra_lib(@extra_libs)
	{
		($gateway_name, $rest) = split(/-/,$extra_lib);
		if ($rest eq "order_lib.pl")
		{
			$gateway_options .= "<OPTION>$gateway_name</OPTION>\n";
		}
	}
	closedir (GATEWAY);

   print qq~
      <form method="POST">
      <div align="center">
      <p align="left"><font face="Arial" size="3"><b>Gateway Settings Manager:</b></font>
      </div>
      <div align="center">
      <p align="left"><font face="Arial" size="3">Select&nbsp;the gateway that
      you would like to change the settings for.</font>
      </div>
      <div align="center">
      &nbsp;
      </div>
      <div align="center">
      <center>
      <SELECT NAME="gateway_name">
      $gateway_options
      </SELECT>
      <INPUT type="hidden" name="action" value="gateway_settings_screen">
      <INPUT NAME="GatewaySettings" TYPE="SUBMIT" VALUE="Edit">
      </center>
      </div>
      </form>
   ~;
}

#############################################################################################

sub gateway_complete
{
	print qq~
		<CENTER>
		<TABLE>
		<TR>
		<TD>
		<FONT FACE=ARIAL SIZE=2 COLOR=RED>Gateway settings have been successfully updated</FONT>
		</TD>
		</TR>
		</TABLE>
		</CENTER>
	~;
}

#############################################################################################

sub action_gateway_settings
{
	require "$gateway_lib" || &errorcode(__FILE__, __LINE__, "$gateway_lib", "$!", "die", "REQUIRE FILE ERROR", "Unable to require the file listed. Make sure that it exists and that it has read/write permissions");
	open (GATEWAY, "> $gateway_settings") || &errorcode(__FILE__, __LINE__, "$gateway_settings", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   foreach $var_field (keys(%sc_gateway_settings))
   {
   	$form_data{$var_field} =~ s/\@/\\@/;
		print GATEWAY  "\$$var_field = \"" . $form_data{$var_field} . "\";\n";
	}
	print GATEWAY  "\$sc_gateway_user_lib_was_loaded \= \"yes\"\;\n";
	print GATEWAY  "1\;\n";
	close(GATEWAY);
	&gateway_complete;
}

#############################################################################################
sub gateway_settings_screen
{
#	require "$Path1/configuration/commerce_user_lib.pl" || &errorcode(__FILE__, __LINE__, "$Path1/configuration/commerce_user_lib.pl", "$!", "die", "REQUIRE FILE ERROR", "Unable to require the file listed. Make sure that it exists and that it has read/write permissions");
	if (-e $gateway_settings)
	{
		require "$gateway_settings" || &errorcode(__FILE__, __LINE__, "$gateway_settings", "$!", "die", "REQUIRE FILE ERROR", "Unable to require the file listed. Make sure that it exists and that it has read/write permissions");
	}

	if ($form_data{'gateway_name'})
	{
	   require "$gateway_lib" || &errorcode(__FILE__, __LINE__, "$gateway_lib", "$!", "die", "REQUIRE FILE ERROR", "Unable to require the file listed. Make sure that it exists and that it has read/write permissions");
   }

	print qq~
		<FORM METHOD="POST">
		<div align="center">
		<center>
		<TABLE WIDTH=90% cellspacing="0" cellpadding="3" border="0">
		<tr>
		<TD>
		<FONT FACE=ARIAL>
		$form_data{'gateway_name'} Processing
		</FONT>
		</TD>
		</TR>
	~;

   foreach $var_field (keys(%sc_gateway_settings))
   {
   	print qq~
    	   <tr>
    		<TD bgcolor="$table_color">
 			<FONT FACE=ARIAL SIZE=2 color="#FFFFFF">
 			$sc_gateway_settings{$var_field}
 			</font>
 			</TD>
 			</TR>
			<tr>
			<TD>
			<FONT FACE=ARIAL SIZE=2>
			<INPUT NAME="$var_field" TYPE="TEXT" SIZE=70 VALUE="${$var_field}">
			</TD>
			</TR>
		~;
	}

	print qq~
		<tr>
		<TD>
		&nbsp;
		</TD>
		</TR>
		<tr>
		<TD>
		<FONT FACE=ARIAL SIZE=2>
		<p align="center">
		<INPUT type="hidden" name="action" value="action_gateway_settings">
		<INPUT type="hidden" name="gateway_name" value="$form_data{'gateway_name'}">
		<INPUT NAME="GatewaySettings" TYPE="SUBMIT" VALUE="     Update Gateway Settings     "></p>
		<p>&nbsp;
		</TD>
		</TR>
		</TABLE>
		</center>
		</div>
		<FONT FACE=ARIAL SIZE=2>
		</FORM>
	~;
}

1;