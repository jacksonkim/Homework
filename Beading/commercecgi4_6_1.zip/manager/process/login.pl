#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action = ();

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

#######################################################################################
sub process_login
{
   if (-s "$Path2/.htpasswd")
   {
      &page("frontpage.html");
   } else {
   	if($form_data{'username'} eq "$username" && $form_data{'password'} eq "$password")
   	{
   		open(FILE, ">$ip_file") || &errorcode(__FILE__, __LINE__, "$ip_file", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   		print(FILE "\$ok_ip=\"$ENV{'REMOTE_ADDR'}\";\n1\;\n");
   		close(FILE);
   		&page("frontpage.html");
   	} else {
   		&display_login;
   	}
	}
}
#######################################################################################

#######################################################################################

sub display_login
{
	print qq~
		<FORM METHOD="POST">
		<CENTER>
		<TABLE WIDTH=500 BORDER=0 CELLPADDING=2>
		<tr>
		<TD COLSPAN=2>
		<HR WIDTH=550>
		</TD>
		</TR>
	~;

	if (! -e ".htaccess")
	{
		print qq~
			<tr>
			<TD COLSPAN=2>
			<FONT FACE=ARIAL>
			<STRONG>
			<blink><FONT COLOR="#FF0000">WARNING</FONT></blink> No .htaccess file found. YOU STILL NEED TO PASSWORD PROTECT THE /manager DIRECTORY<BR>
			</STRONG>
			</FONT>
			</TD>
			</TR>
		~;
	}

	print qq~
		<tr>
		<TD COLSPAN=2><P>&nbsp;</P></TD>
		</TR>
		<tr>
		<TD COLSPAN=2><font face="Arial">Username:&nbsp;</font><INPUT TYPE=text NAME=username></TD>
		</TR>
		<TR>
		<TD COLSPAN=2><font face="Arial">Password:&nbsp;</font><INPUT TYPE=password NAME=password></TD>
		</TR>
		<tr>
		<TD>&nbsp;</TD>
		</TR>
		<tr>
		<TD COLSPAN=2>
		<CENTER>
		<INPUT TYPE=HIDDEN NAME="action" VALUE="process_login">
		<INPUT TYPE=submit VALUE="     Login     ">
		</CENTER>
		</TD>
		</TR>
		</TABLE>
		</CENTER>
		</FORM>
	~;

}



1;