#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$sc_old_order_directory_path         = "$Path2/old_orders";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('Orders',          'orders_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

############################################################
# New Orders
############################################################

sub orders_screen
{
   print qq~
      <blockquote>
      <p><font face="Arial"><b>Pending Orders:</b></font></p>
      </blockquote>
      <div align="center">
      <center>
      <table border="0" cellpadding="3" cellspacing="0" width="92%">
      <tr>
      <td bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Date</b></font></td>
      <td bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Invoice</b></font></td>
      <td bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Name</b></font></td>
      <td align="right" bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Total</b></font></td>
      <td bgcolor="$table_color" align="right"><font face="Arial" size="2" color="#FFFFFF"><b>&nbsp;</b></font></td>
      </tr>
   ~;

	opendir (ORDERS, "$sc_order_directory_path") || &errorcode(__FILE__, __LINE__, "$sc_order_directory_path", "$!", "die", "DIRECTORY OPEN ERROR", "Unable to open the directory listed. Make sure that it exists and that it has read permissions");
	@orders = readdir(ORDERS);
	for $orders (@orders)
	{
		($inv_number, $rest) = split(/\./,$orders);
		if ($inv_number && $inv_number != "index")
		{
		   $inv_name  = "";
		   $inv_total = "";

		   open (ORDER, "< $sc_order_directory_path\/$orders") || &errorcode(__FILE__, __LINE__, "$sc_order_directory_path\/$orders", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
		   while (<ORDER>)
		   {
		      if ($_ =~ /NAME\:/i && $inv_name eq "")
		      {
		         $inv_name = $_;
		         $inv_name =~ s/NAME\://g;
		      }
		      if ($_ =~ /TOTAL\:/i)
		      {
		         $inv_total = $_;
		         $inv_total =~ s/TOTAL\://g;
		      }
   		}
		   close (ORDER);

         $inv_date = &inv_date($inv_number);

         print qq~
            <tr>
            <td><font size="2" face="Arial">$inv_date</font></td>
            <td><font size="2" face="Arial">$inv_number</font></td>
            <td><font size="2" face="Arial">$inv_name</font></td>
            <td align="right"><font size="2" face="Arial">$inv_total</font></td>
            <td align="right"><font size="2" face="Arial"><a href="index.cgi?action=view_invoice&inv_number=$inv_number">VIEW</a>
            | <a href="index.cgi?action=process_invoice_screen&inv_number=$inv_number">PROCESS</a></font></td>
            </tr>
         ~;
		}
	}
	closedir (ORDERS);

   print qq~
      </table>
      </center>
      </div>
      <blockquote>
      <p><font face="Arial"><a href="index.cgi?action=old_invoice_screen">OLD
      INVOICE SEARCH</a></font></p>
      </blockquote>
   ~;
}

############################################################
# Old Invoice Screen
############################################################

sub old_invoice_screen
{
   print qq~
      <blockquote>
      <p><font face="Arial"><b>Old Orders Search:</b></font></p>
      </blockquote>
      <div align="center">
      <center>
      <table border="0" cellpadding="4" cellspacing="0" width="92%">
      <tr>
      <td valign="top" nowrap colspan="2" align="right">
      <hr>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap align="right"><b><font size="2" face="Arial">By
        Invoice:</font></b> </td>
      <td width="100%">
      <form method="POST">
      <input type="hidden" name="action" value="old_invoice_search">
      <p><input type="text" name="by_invoice" size="20"><input type="submit" value="Search"></p>
      </form>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap colspan="2" align="right">
      <hr>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap align="right"><b><font size="2" face="Arial">By
      Date:</font></b> <font size="2" face="Arial"><b><br>
      </b></font><font face="Arial" size="1">(Format MM/DD/YYYY)</font></td>
      <td width="100%">
      <form method="POST">
      <input type="hidden" name="action" value="old_invoice_search">
      <p><input type="text" name="by_date" size="20"><input type="submit" value="Search"></p>
      </form>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap colspan="2" align="right">
      <hr>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap align="right"><font size="2" face="Arial"><b>By
      Date Range:<br>
      </b></font><font face="Arial" size="1">(Format MM/DD/YYYY)</font></td>
      <td>
      <form method="POST">
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td><font size="2" face="Arial">After:<br>
        <input type="hidden" name="action" value="old_invoice_search">
          </font><input type="text" name="after_date" size="20"></td>
      </tr>
      <tr>
        <td width="100%"><font size="2" face="Arial">Before:<br>
          </font><input type="text" name="before_date" size="20"><input type="submit" value="Search"></td>
      </tr>
      </table>
      </form>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap colspan="2" align="right">
      <hr>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap align="right"><b><font size="2" face="Arial">By
      Name:</font></b></td>
      <td>
      <form method="POST">
      <input type="hidden" name="action" value="old_invoice_search">
      <p><input type="text" name="by_name" size="39"><input type="submit" value="Search"></p>
      </form>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap colspan="2" align="right">
      <hr>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap align="right"><b><font size="2" face="Arial">By
      Tracking Number:</font></b></td>
      <td>
      <form method="POST">
      <input type="hidden" name="action" value="old_invoice_search">
      <p><input type="text" name="by_tracking" size="39"><input type="submit" value="Search"></p>
      </form>
      </td>
      </tr>
      <tr>
      <td valign="top" nowrap colspan="2" align="right">
      <hr>
      </td>
      </tr>
      </table>
      </center>
      </div>
      <p>&nbsp;</p>
   ~;
}

############################################################
# Old Invoice Search
############################################################

sub old_invoice_search
{
   if (-f "$sc_old_order_directory_path\/order.log")
   {
      open (ORDER, "< $sc_old_order_directory_path\/order.log") || &errorcode(__FILE__, __LINE__, "$sc_old_order_directory_path\/order.log", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
      while (<ORDER>)
      {
         ($inv_number, $inv_name, $tracking_number) = split(/\|/, $_);
         $inv_date = &inv_date($inv_number);
         $this_one = "no";

         if ($form_data{'by_invoice'})
         {
            if ($inv_number =~ /$form_data{'by_invoice'}/i)
            {
               $this_one = "yes";
            }
         } elsif ($form_data{'by_date'}) {
            ($month, $day, $year) = split(/\//, $form_data{'by_date'});

            use Time::Local;

            $month   = $month-1;
            $year = $year -1900;

            $sdate = timelocal(0,0,0,$day,$month,$year);
            $edate = timelocal(0,0,24,$day,$month,$year);

            if ($inv_number >= $sdate && $inv_number <= $edate)
            {
               $this_one = "yes";
            }
         } elsif ($form_data{'after_date'} || $form_data{'before_date'}) {
            use Time::Local;

            if ($form_data{'after_date'})
            {
               ($month, $day, $year) = split(/\//, $form_data{'after_date'});
               $month   = $month-1;
               $year = $year -1900;
               $sdate = timelocal(0,0,0,$day,$month,$year);
            }

            if ($form_data{'before_date'})
            {
               ($month, $day, $year) = split(/\//, $form_data{'before_date'});
               $month   = $month-1;
               $year = $year -1900;
               $edate = timelocal(59,59,23,$day,$month,$year);
            }

            if ($form_data{'after_date'} && $form_data{'before_date'})
            {
               if ($inv_number >= $sdate && $inv_number <= $edate)
               {
                  $this_one = "yes";
               }
            } elsif ($form_data{'after_date'}) {
               if ($inv_number >= $sdate)
               {
                  $this_one = "yes";
               }
            } elsif ($form_data{'before_date'}) {
               if ($inv_number <= $edate)
               {
                  $this_one = "yes";
               }
            }
         } elsif ($form_data{'by_name'}) {
            if ($inv_name =~ /$form_data{'by_name'}/i)
            {
               $this_one = "yes";
            }
         } elsif ($form_data{'by_tracking'}) {
            if ($tracking_number =~ /$form_data{'by_tracking'}/i)
            {
               $this_one = "yes";
            }
         }

         if ($this_one eq "yes")
         {
            $old_invoice_found++;
            $old_order_data .= qq~
               <tr>
               <td><font size="2" face="Arial">$inv_date</font></td>
               <td><font size="2" face="Arial">$inv_number</font></td>
               <td><font size="2" face="Arial">$inv_name</font></td>
               <td align="right"><font size="2" face="Arial"><a href="index.cgi?action=view_old_invoice&inv_number=$inv_number">VIEW</a>
               </font></td>
               </tr>
            ~;
         }
      }
      close (ORDER);
   }

   if ($old_invoice_found)
   {
      print qq~
         <blockquote>
         <p><font face="Arial"><b>Old Orders:</b></font></p>
         </blockquote>
         <div align="center">
         <center>
         <table border="0" cellpadding="3" cellspacing="0" width="92%">
         <tr>
         <td bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Date</b></font></td>
         <td bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Invoice</b></font></td>
         <td bgcolor="$table_color"><font face="Arial" size="2" color="#FFFFFF"><b>Name</b></font></td>
         <td bgcolor="$table_color" align="right"><font face="Arial" size="2" color="#FFFFFF"><b>&nbsp;</b></font></td>
         </tr>
      ~;

      print $old_order_data;

      print qq~
         </table>
         </center>
         </div>
         <blockquote>
         <p><font face="Arial"><a href="index.cgi?action=old_invoice_screen">OLD
         INVOICE SEARCH</a></font></p>
         </blockquote>
      ~;
   } else {
      print qq~
         <p align="center">&nbsp;</p>
         <p align="center"><font size="4" face="Arial" color="#FF0000">No orders found!</font></p>
         <p align="center">&nbsp;</p>
         <form>
         <p align="center">
         <input type="button" value="     << Back     " onclick="javascript:history.go(-1)">
         </form>
      ~;
   }
}

############################################################
# View Invoice
############################################################

sub view_invoice
{
   local ($data);

   open (ORDER, "< $sc_order_directory_path\/$form_data{'inv_number'}") || &errorcode(__FILE__, __LINE__, "$sc_order_directory_path\/$form_data{'inv_number'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   while (<ORDER>)
   {
      $data .= $_;
	}
   close (ORDER);

   print qq~
      <script language="javascript1.1">
      function printText(elem)
      {
         popup = window.open('','popup','toolbar=no,menubar=no,width=200,height=150');
         popup.document.open();
         popup.document.write("<html>Invoice Number: $form_data{'inv_number'}<head></head><body onload='print()'>");
         popup.document.write("<pre>");
         popup.document.write(elem);
         popup.document.write("</pre>");
         popup.document.write("</body></html>");
         popup.document.close();
      }
      </script>

      <form method="POST" name="order">
      <p align="center">
      <font size="4" face="Arial"><b>Invoice Number: $form_data{'inv_number'}</b></font></p>
<p align="center"><textarea rows="24" name="order_data" cols="60">
$data
</textarea></p>
      <input type="hidden" name="action" value="update_invoice">
      <input type="hidden" name="inv_number" value="$form_data{'inv_number'}">
      <p align="center">
      <input type="button" value="     << Back     " onclick="javascript:history.go(-1)">
      <input type="button" value="     Print     " onclick="printText(document.order.order_data.value)">
      <input type="submit" value="     Update     ">
      </p>
      </form>
   ~;
}

############################################################
# View Old Invoice
############################################################

sub view_old_invoice
{
   local ($data);

   open (ORDER, "< $sc_old_order_directory_path\/$form_data{'inv_number'}") || &errorcode(__FILE__, __LINE__, "$sc_old_order_directory_path\/$form_data{'inv_number'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   while (<ORDER>)
   {
      $data .= $_;
	}
   close (ORDER);

   print qq~
      <script language="javascript1.1">
      function printText(elem)
      {
         popup = window.open('','popup','toolbar=no,menubar=no,width=200,height=150');
         popup.document.open();
         popup.document.write("<html>Old Invoice Number: $form_data{'inv_number'}<head></head><body onload='print()'>");
         popup.document.write("<pre>");
         popup.document.write(elem);
         popup.document.write("</pre>");
         popup.document.write("</body></html>");
         popup.document.close();
      }
      </script>

      <form name="order">
      <p align="center">
      <font size="4" face="Arial"><b>Old Invoice Number: $form_data{'inv_number'}</b></font></p>
<p align="center"><textarea rows="24" name="order_data" cols="60">
$data
</textarea></p>
      <input type="hidden" name="action" value="update_invoice">
      <input type="hidden" name="inv_number" value="$form_data{'inv_number'}">
      <p align="center">
      <input type="button" value="     << Back     " onclick="javascript:history.go(-1)">
      <input type="button" value="     Print     " onclick="printText(document.order.order_data.value)">
      </p>
      </form>
   ~;
}

############################################################
# Update Invoice
############################################################

sub update_invoice
{
   chomp $form_data{'order_data'};
   open (ORDER, "> $sc_order_directory_path\/$form_data{'inv_number'}") || &errorcode(__FILE__, __LINE__, "$sc_order_directory_path\/$form_data{'inv_number'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   print ORDER $form_data{'order_data'};
   close (ORDER);
   &orders_screen;
}

############################################################
# Process Invoice Screen
############################################################

sub process_invoice_screen
{
   if (-f "$Path2/files/customer_message.pl")
   {
      require "$Path2/files/customer_message.pl";
   }

   open (ORDER, "< $sc_order_directory_path\/$form_data{'inv_number'}") || &errorcode(__FILE__, __LINE__, "$sc_order_directory_path\/$form_data{'inv_number'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   while (<ORDER>)
   {
      if ($_ =~ /NAME\:/i && $inv_name eq "")
      {
         $inv_name = $_;
         $inv_name =~ s/NAME\://g;
         $inv_name =~ s/^\s+//;
         chomp $inv_name;
      }
      if ($_ =~ /EMAIL\:/i)
      {
         $inv_email = $_;
         $inv_email =~ s/EMAIL\://g;
         $inv_email =~ s/^\s+//;
         chomp $inv_email;
      }
	}
   close (ORDER);

   $inv_date = &inv_date(time);

   print qq~
      <p align="center">
      <font size="4" face="Arial"><b>Process Invoice Number: $form_data{'inv_number'}</b></font></p>
      <form method="POST">
      <div align="center">
      <center>
      <table border="0" cellpadding="3" cellspacing="0" width="90%">
      <tr>
      <td align="right"><b><font face="Arial" size="2">Invoice:</font></b></td>
      <td><input type="text" name="inv_number" size="20" value="$form_data{'inv_number'}"></td>
      </tr>
      <tr>
      <td align="right"><b><font face="Arial" size="2">Name:</font></b></td>
      <td><input type="text" name="inv_name" size="36" value="$inv_name"></td>
      </tr>
      <tr>
      <td align="right"><font size="2" face="Arial"><b>From Email:</b></font></td>
      <td><input type="text" name="from_email" size="36" value="$sc_admin_email"></td>
      </tr>
      <tr>
      <td align="right"><font size="2" face="Arial"><b>To Email:</b></font></td>
      <td><input type="text" name="inv_email" size="36" value="$inv_email"></td>
      </tr>
      <tr>
      <td align="right"><b><font face="Arial" size="2">Ship Date:</font></b></td>
      <td><input type="text" name="inv_date" size="36" value="$inv_date"></td>
      </tr>
      <tr>
      <td align="right"><b><font size="2" face="Arial">Tracking Number:</font></b></td>
      <td><input type="text" name="tracking_number" size="36"></td>
      </tr>
      <tr>
      <td align="right"><font size="2" face="Arial"><b>Subject:</b></font></td>
      <td><input type="text" name="inv_subject" size="65" value="$inv_subject"></td>
      </tr>
      <tr>
      <td valign="top" align="right"><b><font face="Arial" size="2">Message:</font></b></td>
      <td><textarea rows="9" name="inv_message" cols="56">$inv_message</textarea></td>
      </tr>
      <tr>
      <td align="right"><b><font face="Arial" size="2">Email Customer:</font></b></td>
      <td><input type="checkbox" name="send_mail" value="yes"></td>
      </tr>
      </table>
      </center>
      </div>
      <p align="center">
      <input type="hidden" name="action" value="process_invoice">
      <input type="button" value="     << Back     " onclick="javascript:history.go(-1)">
      <input type="submit" value="     Process Invoice     "></p>
      <p align="center">
      &nbsp;</p>
      <p align="center">
      &nbsp;</p>
      </form>
   ~;
}

############################################################
# Process Invoice
############################################################

sub process_invoice
{
   if ($form_data{'send_mail'} eq "yes")
   {
      $form_data{'inv_subject'} =~ s/\{INVOICE\}/$form_data{'inv_number'}/g;
      $form_data{'inv_message'} =~ s/\{INVOICE\}/$form_data{'inv_number'}/g;

      $form_data{'inv_subject'} =~ s/\{NAME\}/$form_data{'inv_name'}/g;
      $form_data{'inv_message'} =~ s/\{NAME\}/$form_data{'inv_name'}/g;

      $form_data{'inv_subject'} =~ s/\{DATE\}/$form_data{'inv_date'}/g;
      $form_data{'inv_message'} =~ s/\{DATE\}/$form_data{'inv_date'}/g;

      $form_data{'inv_subject'} =~ s/\{TRACKING\}/$form_data{'tracking_number'}/g;
      $form_data{'inv_message'} =~ s/\{TRACKING\}/$form_data{'tracking_number'}/g;

      if (!($sc_mail_lib_was_loaded =~ /yes/i))
      {
         require "$sc_mail_lib_path" || &errorcode(__FILE__, __LINE__, "$sc_mail_lib_path", "$!", "die", "FILE REQUIRE ERROR", "Unable to require file!");
      }

      &send_mail($form_data{'from_email'}, $form_data{'inv_email'}, $form_data{'inv_subject'}, $form_data{'inv_message'});
   }

   $data = "Ship Date: $form_data{'inv_date'}\n";
   $data .= "Tracking Number: $form_data{'tracking_number'}\n\n";

   open (ORDER, "< $sc_order_directory_path\/$form_data{'inv_number'}") || &errorcode(__FILE__, __LINE__, "$sc_order_directory_path\/$form_data{'inv_number'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   while (<ORDER>)
   {
      $data .= $_;
	}
   close (ORDER);

   open (ORDER, "+> $sc_old_order_directory_path\/$form_data{'inv_number'}") || &errorcode(__FILE__, __LINE__, "$sc_old_order_directory_path\/$form_data{'inv_number'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   print ORDER $data;
   close (ORDER);

   open (ORDER, "+>> $sc_old_order_directory_path\/order.log") || &errorcode(__FILE__, __LINE__, "$sc_old_order_directory_path\/order.log", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read permissions");
   print ORDER "$form_data{'inv_number'}\|$form_data{'inv_name'}\|$form_data{'tracking_number'}\n";
   close (ORDER);

   unlink "$sc_order_directory_path\/$form_data{'inv_number'}";

   &orders_screen;
}

############################################################
# Date
############################################################

sub inv_date
{
   local ($time) = @_;
   local ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst,$date);
   local (@days, @months);

   @days = ('Sunday','Monday','Tuesday','Wednesday','Thursday', 'Friday', 'Saturday');

   @months = ('January','February','March','April','May','June','July','August','September','October','November','December');

   ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);

   if ($hour < 10){ $hour = "0$hour"; }
   if ($min < 10){ $min = "0$min"; }
   if ($sec < 10){ $sec = "0$sec"; }

   $year += 1900;
   $date = "$months[$mon] $mday, $year";

   return $date;
}




1;