#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$page_dir = "$Path1/pages";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Pages', 'pages');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub pages
{
   $pages .= qq~
       <table border="0" cellpadding="4" cellspacing="0" width="100%">
   ~;

   $header_color = "#FFFFFF";

   opendir (PAGES, "$page_dir") || &errorcode(__FILE__, __LINE__, "$page_dir", "$!", "die", "DIRECTORY OPEN ERROR", "Unable to open the directory listed. Make sure that it exists and that it has read permissions");
	@my_pages = readdir(PAGES);
	for $my_page (@my_pages)
	{
	   if ($my_page =~ /.htm$/)
	   {
         if ($header_color eq "#FFFFFF")
         {
            $header_color = $td_color;
         } else {
            $header_color = "#FFFFFF";
         }

         $pages .= qq~
             <tr>
               <td width="100%" bgcolor="$header_color"><font face="Arial" size="2">$my_page</font></td>
               <td bgcolor="$header_color"><font face="Arial" size="2"><a href="index.cgi?edit=$my_page&action=form">Edit</a></font></td>
               <td bgcolor="$header_color"><font face="Arial" size="2"><a href="index.cgi?action=confirm_page_delete&page=$my_page">Delete</a></font></td>
               <td bgcolor="$header_color"><font face="Arial" size="2"><a href="$sc_store_url?page=$my_page" target="_blank">View</a></font></td>
             </tr>
         ~;
      }
	}
   closedir (PAGES);

   $pages .= qq~</table>~;

   print qq~
      <form method="POST">
      <p align="center"><b><font size="5" face="Arial">HTML PAGE EDITOR</font></b></p>

      <div align="center">
      <center>
      <table border="0" cellpadding="4" cellspacing="0" width="100%">
      <tr>
      <td width="100%" bgcolor="$table_color"><font face="Arial" color="#FFFFFF"><b>Edit an existing page:</b></font></td>
      </tr>
      <tr>
      <td width="100%"><br>
      <font face="Arial" size="2">If you want to edit one of the page
      already on your server then select it from the list below.<br><br></font>
$pages
      </td>
      </tr>
      <tr>
      <td width="100%">&nbsp;</td>
      </tr>
      <tr>
      <td width="100%" bgcolor="$table_color"><font face="Arial" color="#FFFFFF"><b>Page Name:</b></font></td>
      </tr>
      <tr>
      <td width="100%"><font face="Arial"><br>
      <font size="2">If you want to add a new page then enter the page name
      here. Do not enter the file extension! Just the file name as you want it
      to appear in the navigation bar.</font></font>
      <p><font face="Arial"><input type="text" name="name" size="53"></font></p>
      </td>
      </tr>
      <tr>
      <td width="100%">&nbsp;</td>
      </tr>
      </table>
      </center>
      </div>
      <p align="center">
      <input type="hidden" name="action" value="form">
      <input type="submit" value="     Continue >     "></p>
      </form>
   ~;
}

sub form
{
   if ($form_data{'edit'} eq "" && $form_data{'name'} eq "")
   {
      &pages;
   } else {

      if ($form_data{'edit'})
      {
         open (PAGE, "$page_dir\/$form_data{'edit'}") || &errorcode(__FILE__, __LINE__, "$page_dir\/$form_data{'edit'}", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
         while (<PAGE>)
         {
            $page .= $_;
         }
         close (PAGE);
      }

      $page =~ s/\"//g;

      if ($form_data{'name'})
      {
         $name = $form_data{'name'};
         $name =~ s/ /\_/g;
         $name .= "\.htm";
      }

      print qq~
      <!-- http://sniptools.com/dhtml_editor.php -->
     <SCRIPT language="JavaScript">

   function findObj(n, d)
   {
   	var p,i,x;
   	if(!d) d=document;
   	if((p=n.indexOf("?"))>0&&parent.frames.length)
   	{
   	    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);
   	}
   	if(!(x=d[n])&&d.all) x=d.all[n];
   	for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
     	for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=findObj(n,d.layers[i].document); return x;
   }

   function showHideLayers()
   {
   	var i,p,v,obj,args=showHideLayers.arguments;
     	for (i=0; i<(args.length-2); i+=3) if ((obj=findObj(args[i]))!=null)
   	{
   		v=args[i+2];
       	if (obj.style)
   		{
   			obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v;
   		}
       	obj.visibility=v;
   	}
   }

   function doCopyValue()
   {
       document.theform.HTMLPreviewTextArea.value = "" + myEditor.document.body.innerHTML + "";
   }

   function trimIt(trimStr)
   {
   	var i = trimStr.length;
   	while (trimStr.charAt(0) == " ")
               {
   		trimStr = trimStr.substring(1,i)
   		i = i-1;
   	}
   	while (trimStr.charAt(trimStr.length-1) == " ")
   	{
   		trimStr = trimStr.substring( 0,trimStr.length-1)
   	}
   	return trimStr;

   }

   function doMakeBold()
   {
       // Get a text range for the selection
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Bold")
       tr.select()
       doCopyValue();

   }

   function doInsertImage()
   {
      var tr = frames.myEditor.document.selection.createRange()
      tr.execCommand("InsertImage", true);
      doCopyValue();
   }

   function doCopy()
   {
       // Get a text range for the selection
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Copy", false)
       doCopyValue();
   }

   function doPaste()
   {
       // Get a text range for the selection
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Paste", false)
       doCopyValue();
   }

   function doInsertUL()
   {
       // Get a text range for the selection
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("InsertUnorderedList", false)
       doCopyValue();
   }

   function doIndent()
   {
       // Get a text range for the selection
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Indent", false)
       doCopyValue();
   }

   function doUnIndent()
   {
       // Get a text range for the selection
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Outdent", false)
       doCopyValue();
   }

   function doMakeItalic()
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Italic")
       tr.select()
       doCopyValue();
   }

   function doMakeUnderline()
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("Underline")
       tr.select()
       doCopyValue();
   }

   function doInsertLink()
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("CreateLink")
       tr.select()
       doCopyValue();
   }

   function doUnLink()
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("UnLink")
       tr.select()
       doCopyValue();
   }

   function getActiveText(e)
   {
   	text = (frames.myEditor.document.all) ? frames.myEditor.document.selection.createRange().text : frames.myEditor.document.getSelection();
       return text;
   }

   function getPos(el,which)
   {
       var iPos=0
       while (el.offsetParent!=null)
       {
         iPos+=el["offset"+which]
         el = el.offsetParent
         el.onfocus = new Function("displayToolbar(null,false)")
       }
       return iPos
   }

   function displayToolbar(ed, how)
   {
       var eb = document.all.editbar
       if (how)
         eb.style.display = "block"
       else
         eb.style.display = "none"
       if (ed!=null) {
         eb.style.pixelTop = getPos(ed,"Top") + ed.offsetHeight + 1
         eb.style.pixelLeft = getPos(ed,"Left")
         eb._editor = window.frames[ed.id]
         eb._editor.setFocus()
       }
   }


   function doInsertComment(comment, highlightText, fullText)
   {
       tempOne = eval("'" + highlightText + "'");
     	originalStr = new RegExp(tempOne);
       replaceStr  = "<a href=# title='" + comment + "'>" + highlightText + "</a>";
       fullText = fullText.replace(originalStr, replaceStr);
       alert(fullText);
       return(fullText);
   }

   function getComment()
   {
   	var theText    = getActiveText();
       if (theText == "")
       {
           // Nothing is highlighted!
           alert("Please select some text to comment.");
       }
       else
       {
       	if (theComment = prompt("Please enter your comment:", ""))
           {
           	if (trimIt(theComment) != "")
               {
                   oldMainSpace = document.theform.HTMLPreviewTextArea.value;
                   document.theform.HTMLPreviewTextArea.value = doInsertComment(theComment, theText, oldMainSpace);
               }
           }
       }
       doRenderHTML();
       //doCopyValue();
   }


   function doFontName(what)
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("FontName", false, what)
       tr.select()
       doCopyValue();
   }

   function doFontSize(what)
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("FontSize", false, what)
       tr.select()
       doCopyValue();
   }

   function doCreateAnchor()
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("CreateBookmark")
       tr.select()
       doCopyValue();
   }

   function doFontColor(what)
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("ForeColor", false, what)
       tr.select()
       doCopyValue();
   }

   function doSelectAll()
   {
       var tr = frames.myEditor.document
       tr.execCommand("SelectAll", false, null)
   }

   function doPrint()
   {
       frames.myEditor.print();
   }

   function doJustify(where)
   {
       var tr = frames.myEditor.document.selection.createRange()
       if (where == 'Left') tr.execCommand("JustifyLeft")
       else if (where == 'Right') tr.execCommand("JustifyRight")
       else if (where == 'Center') tr.execCommand("JustifyCenter")
       tr.select()
       doCopyValue();
   }

   function doSwapMode(b)
   {
       var eb = document.all.myEditor
       eb.swapModes()
       b.value = eb.format + " Mode"
   }

   function doSave()
   {
       var tr = frames.myEditor.document
       tr.execCommand("SaveAs", true)
   }

   function doRenderHTML()
   {
   	myEditor.document.body.innerHTML=document.theform.HTMLPreviewTextArea.value;
   }

   function doSelectColor(val)
   {
       var tr = frames.myEditor.document.selection.createRange()
       tr.execCommand("ForeColor", false, val)
       tr.select()
       doCopyValue();
   }


   </SCRIPT>
   <body onload="doRenderHTML()">
   <p align="center"><b><font size="5" face="Arial">HTML PAGE EDITOR</font></b></p>

   <form name="theform" method="post">
     <input type="hidden" name="HTMLPreviewTextArea" value="$page">


     <table width="100%">
       <tr>
         <td align="left" valign="top">
           <p align="center">
           <select name="FontName" onClick="doFontName(this.value)">
             <option selected>Font...</option>
             <option value="Arial">Arial</option>
             <option value="Verdana">Verdana</option>
             <option value="Times New Roman">Times New Roman</option>
             <option value="Courier New">Courier New</option>
           </select><select name="FontSize"  onClick="doFontSize(this.value)">
             <option selected>Size...</option>
             <option value="1">1</option>
             <option value="2">2</option>
             <option value="3">3</option>
             <option value="4">4</option>
             <option value="5">5</option>
             <option value="6">6</option>
             <option value="7">7</option>
           </select>
           </p>
   <p align="center">
           <img src="$URL_of_images_directory/manager/icons_bold.gif" onClick="doMakeBold()" alt="Embold a selection" width="24" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_italic.gif" onClick="doMakeItalic()" alt="Italicise a  selection" width="23" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_underline.gif" onClick="doMakeUnderline()" alt="Underline a selection" width="23" height="20" border="1">&nbsp;&nbsp;
           <img src="$URL_of_images_directory/manager/icons_left.gif" onClick="doJustify('Left')" alt="Left align" width="23" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_center.gif" onClick="doJustify('Center')" alt="Center align" width="23" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_right.gif" onClick="doJustify('Right')" alt="Right align" width="23" height="20" border="1">
           &nbsp; <img src="$URL_of_images_directory/manager/icons_link.gif" onClick="doInsertLink()" alt="Insert a link for the selection" width="23" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_unlink.gif" onClick="doUnLink()" alt="Remove a link from a selection" width="23" height="20" border="1">&nbsp;&nbsp;
<!--           <IMG src="$URL_of_images_directory/manager/icons_image.gif" onclick=doInsertImage() height=20 alt="Insert Image" width=23 border="1">&nbsp;&nbsp; -->
           <img src="$URL_of_images_directory/manager/icons_selectall.gif" onClick="doSelectAll()" alt="Select All" width="23" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_copy.gif" onClick="doCopy()" alt="Copy selection" width="23" height="20" border="1">
           <img src="$URL_of_images_directory/manager/icons_paste.gif" onClick="doPaste()" alt="Paste selection" width="23" height="20" border="1">&nbsp;&nbsp;
           <img src="$URL_of_images_directory/manager/icons_ul.gif" onClick="doInsertUL()" alt="Insert a bulleted list" width="23" height="20" border="1">
   		<img src="$URL_of_images_directory/manager/icons_indent.gif" onClick="doIndent()" alt="Increase indentation" width="23" height="20" border="1">
   		<img src="$URL_of_images_directory/manager/icons_unindent.gif" onClick="doUnIndent()" alt="Decrease indentation" width="23" height="20" border="1">&nbsp;&nbsp;

<a href="javascript:void(0)" onclick="window.open ('index.cgi?action=image_list&noheader=yes', 'window', 'width=170,height=450,left=0,top=0,screenX=0,screenY=0,scrollbars=yes,toolbar=no,location=no,resizable=yes')">
<img src="$URL_of_images_directory/manager/icons_image.gif" alt="Insert Image" width="23" height="20" border="1">
</a>

           </p>
           <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> <a><map name="colmap">
                     <area shape="rect" coords="1,1,7,10" href="javascript:doSelectColor('#00FF00')">
                     <area shape="rect" coords="9,1,15,10" href="javascript:doSelectColor('#00FF33')">
                     <area shape="rect" coords="17,1,23,10" href="javascript:doSelectColor('#00FF66')">
                     <area shape="rect" coords="25,1,31,10" href="javascript:doSelectColor('#00FF99')">
                     <area shape="rect" coords="33,1,39,10" href="javascript:doSelectColor('#00FFCC')">
                     <area shape="rect" coords="41,1,47,10" href="javascript:doSelectColor('#00FFFF')">
                     <area shape="rect" coords="49,1,55,10" href="javascript:doSelectColor('#33FF00')">
                     <area shape="rect" coords="57,1,63,10" href="javascript:doSelectColor('#33FF33')">
                     <area shape="rect" coords="65,1,71,10" href="javascript:doSelectColor('#33FF66')">
                     <area shape="rect" coords="73,1,79,10" href="javascript:doSelectColor('#33FF99')">
                     <area shape="rect" coords="81,1,87,10" href="javascript:doSelectColor('#33FFCC')">
                     <area shape="rect" coords="89,1,95,10" href="javascript:doSelectColor('#33FFFF')">
                     <area shape="rect" coords="97,1,103,10" href="javascript:doSelectColor('#66FF00')">
                     <area shape="rect" coords="105,1,111,10" href="javascript:doSelectColor('#66FF33')">
                     <area shape="rect" coords="113,1,119,10" href="javascript:doSelectColor('#66FF66')">
                     <area shape="rect" coords="121,1,127,10" href="javascript:doSelectColor('#66FF99')">
                     <area shape="rect" coords="129,1,135,10" href="javascript:doSelectColor('#66FFCC')">
                     <area shape="rect" coords="137,1,143,10" href="javascript:doSelectColor('#66FFFF')">
                     <area shape="rect" coords="145,1,151,10" href="javascript:doSelectColor('#99FF00')">
                     <area shape="rect" coords="153,1,159,10" href="javascript:doSelectColor('#99FF33')">
                     <area shape="rect" coords="161,1,167,10" href="javascript:doSelectColor('#99FF66')">
                     <area shape="rect" coords="169,1,175,10" href="javascript:doSelectColor('#99FF99')">
                     <area shape="rect" coords="177,1,183,10" href="javascript:doSelectColor('#99FFCC')">
                     <area shape="rect" coords="185,1,191,10" href="javascript:doSelectColor('#99FFFF')">
                     <area shape="rect" coords="193,1,199,10" href="javascript:doSelectColor('#CCFF00')">
                     <area shape="rect" coords="201,1,207,10" href="javascript:doSelectColor('#CCFF33')">
                     <area shape="rect" coords="209,1,215,10" href="javascript:doSelectColor('#CCFF66')">
                     <area shape="rect" coords="217,1,223,10" href="javascript:doSelectColor('#CCFF99')">
                     <area shape="rect" coords="225,1,231,10" href="javascript:doSelectColor('#CCFFCC')">
                     <area shape="rect" coords="233,1,239,10" href="javascript:doSelectColor('#CCFFFF')">
                     <area shape="rect" coords="241,1,247,10" href="javascript:doSelectColor('#FFFF00')">
                     <area shape="rect" coords="249,1,255,10" href="javascript:doSelectColor('#FFFF33')">
                     <area shape="rect" coords="257,1,263,10" href="javascript:doSelectColor('#FFFF66')">
                     <area shape="rect" coords="265,1,271,10" href="javascript:doSelectColor('#FFFF99')">
                     <area shape="rect" coords="273,1,279,10" href="javascript:doSelectColor('#FFFFCC')">
                     <area shape="rect" coords="281,1,287,10" href="javascript:doSelectColor('#FFFFFF')">
                     <area shape="rect" coords="1,12,7,21" href="javascript:doSelectColor('#00CC00')">
                     <area shape="rect" coords="9,12,15,21" href="javascript:doSelectColor('#00CC33')">
                     <area shape="rect" coords="17,12,23,21" href="javascript:doSelectColor('#00CC66')">
                     <area shape="rect" coords="25,12,31,21" href="javascript:doSelectColor('#00CC99')">
                     <area shape="rect" coords="33,12,39,21" href="javascript:doSelectColor('#00CCCC')">
                     <area shape="rect" coords="41,12,47,21" href="javascript:doSelectColor('#00CCFF')">
                     <area shape="rect" coords="49,12,55,21" href="javascript:doSelectColor('#33CC00')">
                     <area shape="rect" coords="57,12,63,21" href="javascript:doSelectColor('#33CC33')">
                     <area shape="rect" coords="72,12,78,21" href="javascript:doSelectColor('#33CC66')">
                     <area shape="rect" coords="73,12,79,21" href="javascript:doSelectColor('#33CC99')">
                     <area shape="rect" coords="81,12,87,21" href="javascript:doSelectColor('#33CCCC')">
                     <area shape="rect" coords="89,12,95,21" href="javascript:doSelectColor('#33CCFF')">
                     <area shape="rect" coords="97,12,103,21" href="javascript:doSelectColor('#66CC00')">
                     <area shape="rect" coords="105,12,111,21" href="javascript:doSelectColor('#66CC33')">
                     <area shape="rect" coords="113,12,119,21" href="javascript:doSelectColor('#66CC66')">
                     <area shape="rect" coords="121,12,127,21" href="javascript:doSelectColor('#66CC99')">
                     <area shape="rect" coords="129,12,135,21" href="javascript:doSelectColor('#66CCCC')">
                     <area shape="rect" coords="137,12,143,21" href="javascript:doSelectColor('#66CCFF')">
                     <area shape="rect" coords="145,12,151,21" href="javascript:doSelectColor('#99CC00')">
                     <area shape="rect" coords="153,12,159,21" href="javascript:doSelectColor('#99CC33')">
                     <area shape="rect" coords="161,12,167,21" href="javascript:doSelectColor('#99CC66')">
                     <area shape="rect" coords="169,12,175,21" href="javascript:doSelectColor('#99CC99')">
                     <area shape="rect" coords="177,12,183,21" href="javascript:doSelectColor('#99CCCC')">
                     <area shape="rect" coords="185,12,191,21" href="javascript:doSelectColor('#99CCFF')">
                     <area shape="rect" coords="193,12,199,21" href="javascript:doSelectColor('#CCCC00')">
                     <area shape="rect" coords="201,12,207,21" href="javascript:doSelectColor('#CCCC33')">
                     <area shape="rect" coords="209,12,215,21" href="javascript:doSelectColor('#CCCC66')">
                     <area shape="rect" coords="217,12,223,21" href="javascript:doSelectColor('#CCCC99')">
                     <area shape="rect" coords="225,12,231,21" href="javascript:doSelectColor('#CCCCCC')">
                     <area shape="rect" coords="233,12,239,21" href="javascript:doSelectColor('#CCCCFF')">
                     <area shape="rect" coords="241,12,247,21" href="javascript:doSelectColor('#FFCC00')">
                     <area shape="rect" coords="249,12,255,21" href="javascript:doSelectColor('#FFCC33')">
                     <area shape="rect" coords="257,12,263,21" href="javascript:doSelectColor('#FFCC66')">
                     <area shape="rect" coords="265,12,271,21" href="javascript:doSelectColor('#FFCC99')">
                     <area shape="rect" coords="273,12,279,21" href="javascript:doSelectColor('#FFCCCC')">
                     <area shape="rect" coords="281,12,287,21" href="javascript:doSelectColor('#FFCCFF')">
                     <area shape="rect" coords="1,23,7,32" href="javascript:doSelectColor('#009900')">
                     <area shape="rect" coords="9,23,15,32" href="javascript:doSelectColor('#009933')">
                     <area shape="rect" coords="17,23,23,32" href="javascript:doSelectColor('#009966')">
                     <area shape="rect" coords="25,23,31,32" href="javascript:doSelectColor('#009999')">
                     <area shape="rect" coords="33,23,39,32" href="javascript:doSelectColor('#0099CC')">
                     <area shape="rect" coords="41,23,47,32" href="javascript:doSelectColor('#0099FF')">
                     <area shape="rect" coords="49,23,55,32" href="javascript:doSelectColor('#339900')">
                     <area shape="rect" coords="57,23,63,32" href="javascript:doSelectColor('#339933')">
                     <area shape="rect" coords="65,23,71,32" href="javascript:doSelectColor('#339966')">
                     <area shape="rect" coords="73,23,79,32" href="javascript:doSelectColor('#339999')">
                     <area shape="rect" coords="81,23,87,32" href="javascript:doSelectColor('#3399CC')">
                     <area shape="rect" coords="89,23,95,32" href="javascript:doSelectColor('#3399FF')">
                     <area shape="rect" coords="97,23,103,32" href="javascript:doSelectColor('#669900')">
                     <area shape="rect" coords="105,23,111,32" href="javascript:doSelectColor('#669933')">
                     <area shape="rect" coords="113,23,119,32" href="javascript:doSelectColor('#669966')">
                     <area shape="rect" coords="121,23,127,32" href="javascript:doSelectColor('#669999')">
                     <area shape="rect" coords="129,23,135,32" href="javascript:doSelectColor('#6699CC')">
                     <area shape="rect" coords="137,23,143,32" href="javascript:doSelectColor('#6699FF')">
                     <area shape="rect" coords="145,23,151,32" href="javascript:doSelectColor('#999900')">
                     <area shape="rect" coords="153,23,159,32" href="javascript:doSelectColor('#999933')">
                     <area shape="rect" coords="161,23,167,32" href="javascript:doSelectColor('#999966')">
                     <area shape="rect" coords="169,23,175,32" href="javascript:doSelectColor('#999999')">
                     <area shape="rect" coords="177,23,183,32" href="javascript:doSelectColor('#9999CC')">
                     <area shape="rect" coords="185,23,191,32" href="javascript:doSelectColor('#9999FF')">
                     <area shape="rect" coords="193,23,199,32" href="javascript:doSelectColor('#CC9900')">
                     <area shape="rect" coords="201,23,207,32" href="javascript:doSelectColor('#CC9933')">
                     <area shape="rect" coords="209,23,215,32" href="javascript:doSelectColor('#CC9966')">
                     <area shape="rect" coords="217,23,223,32" href="javascript:doSelectColor('#CC9999')">
                     <area shape="rect" coords="225,23,231,32" href="javascript:doSelectColor('#CC99CC')">
                     <area shape="rect" coords="234,23,240,32" href="javascript:doSelectColor('#CC99FF')">
                     <area shape="rect" coords="241,23,247,32" href="javascript:doSelectColor('#FF9900')">
                     <area shape="rect" coords="249,23,255,32" href="javascript:doSelectColor('#FF9933')">
                     <area shape="rect" coords="257,23,263,32" href="javascript:doSelectColor('#FF9966')">
                     <area shape="rect" coords="265,23,271,32" href="javascript:doSelectColor('#FF9999')">
                     <area shape="rect" coords="273,23,279,32" href="javascript:doSelectColor('#FF99CC')">
                     <area shape="rect" coords="281,23,287,32" href="javascript:doSelectColor('#FF99FF')">
                     <area shape="rect" coords="1,34,7,43" href="javascript:doSelectColor('#006600')">
                     <area shape="rect" coords="9,34,15,43" href="javascript:doSelectColor('#006633')">
                     <area shape="rect" coords="17,34,23,43" href="javascript:doSelectColor('#006666')">
                     <area shape="rect" coords="25,34,31,43" href="javascript:doSelectColor('#006699')">
                     <area shape="rect" coords="33,34,39,43" href="javascript:doSelectColor('#0066CC')">
                     <area shape="rect" coords="41,34,47,43" href="javascript:doSelectColor('#0066FF')">
                     <area shape="rect" coords="49,34,55,43" href="javascript:doSelectColor('#336600')">
                     <area shape="rect" coords="57,34,63,43" href="javascript:doSelectColor('#336633')">
                     <area shape="rect" coords="65,34,71,43" href="javascript:doSelectColor('#336666')">
                     <area shape="rect" coords="73,34,79,43" href="javascript:doSelectColor('#336699')">
                     <area shape="rect" coords="81,34,87,43" href="javascript:doSelectColor('#3366CC')">
                     <area shape="rect" coords="89,34,95,43" href="javascript:doSelectColor('#3366FF')">
                     <area shape="rect" coords="97,34,103,43" href="javascript:doSelectColor('#666600')">
                     <area shape="rect" coords="105,34,111,43" href="javascript:doSelectColor('#666633')">
                     <area shape="rect" coords="113,34,119,43" href="javascript:doSelectColor('#666666')">
                     <area shape="rect" coords="121,34,127,43" href="javascript:doSelectColor('#666699')">
                     <area shape="rect" coords="129,34,135,43" href="javascript:doSelectColor('#6666CC')">
                     <area shape="rect" coords="137,34,143,43" href="javascript:doSelectColor('#6666FF')">
                     <area shape="rect" coords="145,34,151,43" href="javascript:doSelectColor('#996600')">
                     <area shape="rect" coords="153,34,159,43" href="javascript:doSelectColor('#996633')">
                     <area shape="rect" coords="161,34,167,43" href="javascript:doSelectColor('#996666')">
                     <area shape="rect" coords="169,34,175,43" href="javascript:doSelectColor('#996699')">
                     <area shape="rect" coords="177,34,183,43" href="javascript:doSelectColor('#9966CC')">
                     <area shape="rect" coords="185,34,191,43" href="javascript:doSelectColor('#9966FF')">
                     <area shape="rect" coords="193,34,199,43" href="javascript:doSelectColor('#CC6600')">
                     <area shape="rect" coords="201,34,207,43" href="javascript:doSelectColor('#CC6633')">
                     <area shape="rect" coords="209,34,215,43" href="javascript:doSelectColor('#CC6666')">
                     <area shape="rect" coords="217,34,223,43" href="javascript:doSelectColor('#CC6699')">
                     <area shape="rect" coords="225,34,231,43" href="javascript:doSelectColor('#CC66CC')">
                     <area shape="rect" coords="233,34,239,43" href="javascript:doSelectColor('#CC66FF')">
                     <area shape="rect" coords="241,34,247,43" href="javascript:doSelectColor('#FF6600')">
                     <area shape="rect" coords="249,34,255,43" href="javascript:doSelectColor('#FF6633')">
                     <area shape="rect" coords="257,34,263,43" href="javascript:doSelectColor('#FF6666')">
                     <area shape="rect" coords="265,34,271,43" href="javascript:doSelectColor('#FF6699')">
                     <area shape="rect" coords="273,34,279,43" href="javascript:doSelectColor('#FF66CC')">
                     <area shape="rect" coords="281,34,287,43" href="javascript:doSelectColor('#FF66FF')">
                     <area shape="rect" coords="1,45,7,54" href="javascript:doSelectColor('#003300')">
                     <area shape="rect" coords="9,45,15,54" href="javascript:doSelectColor('#003333')">
                     <area shape="rect" coords="17,45,23,54" href="javascript:doSelectColor('#003366')">
                     <area shape="rect" coords="25,45,31,54" href="javascript:doSelectColor('#003399')">
                     <area shape="rect" coords="33,45,39,54" href="javascript:doSelectColor('#0033CC')">
                     <area shape="rect" coords="41,45,47,54" href="javascript:doSelectColor('#0033FF')">
                     <area shape="rect" coords="49,45,55,54" href="javascript:doSelectColor('#333300')">
                     <area shape="rect" coords="57,45,63,54" href="javascript:doSelectColor('#333333')">
                     <area shape="rect" coords="65,45,71,54" href="javascript:doSelectColor('#333366')">
                     <area shape="rect" coords="73,45,79,54" href="javascript:doSelectColor('#333399')">
                     <area shape="rect" coords="81,45,87,54" href="javascript:doSelectColor('#3333CC')">
                     <area shape="rect" coords="89,45,95,54" href="javascript:doSelectColor('#3333FF')">
                     <area shape="rect" coords="97,45,103,54" href="javascript:doSelectColor('#663300')">
                     <area shape="rect" coords="105,45,111,54" href="javascript:doSelectColor('#663333')">
                     <area shape="rect" coords="113,45,119,54" href="javascript:doSelectColor('#663366')">
                     <area shape="rect" coords="121,45,127,54" href="javascript:doSelectColor('#663399')">
                     <area shape="rect" coords="129,45,135,54" href="javascript:doSelectColor('#6633CC')">
                     <area shape="rect" coords="137,45,143,54" href="javascript:doSelectColor('#6633FF')">
                     <area shape="rect" coords="145,45,151,54" href="javascript:doSelectColor('#993300')">
                     <area shape="rect" coords="153,45,159,54" href="javascript:doSelectColor('#993333')">
                     <area shape="rect" coords="161,45,167,54" href="javascript:doSelectColor('#993366')">
                     <area shape="rect" coords="169,45,175,54" href="javascript:doSelectColor('#993399')">
                     <area shape="rect" coords="177,45,183,54" href="javascript:doSelectColor('#9933CC')">
                     <area shape="rect" coords="185,45,191,54" href="javascript:doSelectColor('#9933FF')">
                     <area shape="rect" coords="193,45,199,54" href="javascript:doSelectColor('#CC3300')">
                     <area shape="rect" coords="201,45,207,54" href="javascript:doSelectColor('#CC3333')">
                     <area shape="rect" coords="209,45,215,54" href="javascript:doSelectColor('#CC3366')">
                     <area shape="rect" coords="217,45,223,54" href="javascript:doSelectColor('#CC3399')">
                     <area shape="rect" coords="225,45,231,54" href="javascript:doSelectColor('#CC33CC')">
                     <area shape="rect" coords="233,45,239,54" href="javascript:doSelectColor('#CC33FF')">
                     <area shape="rect" coords="241,45,247,54" href="javascript:doSelectColor('#FF3300')">
                     <area shape="rect" coords="249,45,255,54" href="javascript:doSelectColor('#FF3333')">
                     <area shape="rect" coords="257,45,263,54" href="javascript:doSelectColor('#FF3366')">
                     <area shape="rect" coords="265,45,271,54" href="javascript:doSelectColor('#FF3399')">
                     <area shape="rect" coords="273,45,279,54" href="javascript:doSelectColor('#FF33CC')">
                     <area shape="rect" coords="281,45,287,54" href="javascript:doSelectColor('#FF33FF')">
                     <area shape="rect" coords="1,56,7,65" href="javascript:doSelectColor('#000000')">
                     <area shape="rect" coords="9,56,15,65" href="javascript:doSelectColor('#000033')">
                     <area shape="rect" coords="17,56,23,65" href="javascript:doSelectColor('#000066')">
                     <area shape="rect" coords="25,56,31,65" href="javascript:doSelectColor('#000099')">
                     <area shape="rect" coords="33,56,39,65" href="javascript:doSelectColor('#0000CC')">
                     <area shape="rect" coords="41,56,47,65" href="javascript:doSelectColor('#0000FF')">
                     <area shape="rect" coords="49,56,55,65" href="javascript:doSelectColor('#330000')">
                     <area shape="rect" coords="57,56,63,65" href="javascript:doSelectColor('#330033')">
                     <area shape="rect" coords="65,56,71,65" href="javascript:doSelectColor('#330066')">
                     <area shape="rect" coords="73,56,79,65" href="javascript:doSelectColor('#330099')">
                     <area shape="rect" coords="81,56,87,65" href="javascript:doSelectColor('#3300CC')">
                     <area shape="rect" coords="89,56,95,65" href="javascript:doSelectColor('#3300FF')">
                     <area shape="rect" coords="97,56,103,65" href="javascript:doSelectColor('#660000')">
                     <area shape="rect" coords="105,56,111,65" href="javascript:doSelectColor('#660033')">
                     <area shape="rect" coords="113,56,119,65" href="javascript:doSelectColor('#660066')">
                     <area shape="rect" coords="121,56,127,65" href="javascript:doSelectColor('#660099')">
                     <area shape="rect" coords="129,56,135,65" href="javascript:doSelectColor('#6600CC')">
                     <area shape="rect" coords="137,56,143,65" href="javascript:doSelectColor('#6600FF')">
                     <area shape="rect" coords="145,56,151,65" href="javascript:doSelectColor('#990000')">
                     <area shape="rect" coords="153,56,159,65" href="javascript:doSelectColor('#990033')">
                     <area shape="rect" coords="161,56,167,65" href="javascript:doSelectColor('#990066')">
                     <area shape="rect" coords="169,56,175,65" href="javascript:doSelectColor('#990099')">
                     <area shape="rect" coords="177,56,183,65" href="javascript:doSelectColor('#9900CC')">
                     <area shape="rect" coords="185,56,191,65" href="javascript:doSelectColor('#9900FF')">
                     <area shape="rect" coords="193,56,199,65" href="javascript:doSelectColor('#CC0000')">
                     <area shape="rect" coords="201,56,207,65" href="javascript:doSelectColor('#CC0033')">
                     <area shape="rect" coords="209,56,215,65" href="javascript:doSelectColor('#CC0066')">
                     <area shape="rect" coords="217,56,223,65" href="javascript:doSelectColor('#CC0099')">
                     <area shape="rect" coords="225,56,231,65" href="javascript:doSelectColor('#CC00CC')">
                     <area shape="rect" coords="233,56,239,65" href="javascript:doSelectColor('#CC00FF')">
                     <area shape="rect" coords="241,56,247,65" href="javascript:doSelectColor('#FF0000')">
                     <area shape="rect" coords="249,56,255,65" href="javascript:doSelectColor('#FF0033')">
                     <area shape="rect" coords="257,56,263,65" href="javascript:doSelectColor('#FF0066')">
                     <area shape="rect" coords="265,56,271,65" href="javascript:doSelectColor('#FF0099')">
                     <area shape="rect" coords="273,56,279,65" href="javascript:doSelectColor('#FF00CC')">
                     <area shape="rect" coords="281,56,287,65" href="javascript:doSelectColor('#FF00FF')">
                   </map><img usemap="#colmap" src="$URL_of_images_directory/manager/colortable.gif" border=0 width=289 height=67></a>
                   </font>
           </p>
         </td>
       </tr>
     </table>

     <table width="100%">
       <tr>
         <td align="left" valign="top">
           <p align="center"> <br>
    <!--iframe width=400 height=190 id=myEditor  ONBLUR="displayToolbar(null,false)" ONFOCUS="displayToolbar(this,true)"  onChange="doCopyValue();" onKeyUp="doCopyValue();" onKeyDown="doCopyValue();"-->
    <iframe width=600 height=200 id=myEditor onChange="doCopyValue();" onKeyUp="doCopyValue();" onKeyDown="doCopyValue();" onBlur="doCopyValue();">
    </iframe>
   <script language="JavaScript">
   frames.myEditor.document.designMode = "On";
   function toggleFrameStatus()
   {
       frames.myEditor.browseMode = TRUE;
   }
   </script>
   </p>
   </td>
   </tr>
   </table>
   <input type="hidden" name="edit" value="$form_data{'edit'}">
   <input type="hidden" name="name" value="$name">
   <input type="hidden" name="action" value="create">

     <p align="center"><input type="submit" value="     Add / Update Page     " name="update"></p>
   </form>
      ~;
   }
}

sub create
{
   if ($form_data{'edit'})
   {
      $page = $form_data{'edit'};
   } else {
      $page = $form_data{'name'};
   }

   open (PAGE, ">$page_dir\/$page") || &errorcode(__FILE__, __LINE__, "$page_dir\/$page", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   print PAGE $form_data{'HTMLPreviewTextArea'};
   close (PAGE);
   &pages;
}

sub confirm_page_delete
{
   print qq~
      <p align="center">&nbsp;</p>
      <p align="center"><font face="Arial" size="4">Are you sure you want to delete: <font color="#FF0000">$form_data{'page'}</font>
      ?</font></p>
      <p align="center">&nbsp;</p>
      <p align="center"><font face="Arial"><b><a href="index.cgi?action=delete&page=$form_data{'page'}">YES,
      Delete This Page!</a></b></font></p>
   ~;
}

sub delete
{
   unlink "$page_dir\/$form_data{'page'}";
   &pages;
}

sub image_list
{

   print qq~
      <p><font size="2" face="Arial">Drag and Drop your desired image.</font></p>
   ~;

   opendir (TIMAGES, "$manager_image_path\/pages") || &errorcode(__FILE__, __LINE__, "$manager_image_path/pages", "$!", "print", "OPENDIR ERROR", "3");
   @extra_image = readdir(TIMAGES);
   for $extra_image(@extra_image)
   {
      if ((!($extra_image eq '.')) && (!($extra_image eq '..')))
      {
         print qq~
            <img border="0" src="$URL_of_images_directory/pages/$extra_image"><BR><BR>
         ~;
      }
   }
   closedir (TIMAGES);
}


1;