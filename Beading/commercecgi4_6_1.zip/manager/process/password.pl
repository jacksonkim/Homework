#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################


#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Set Password', 'password_html');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub password_html
{
   print qq~
      <p align="center"><b><font size="4" face="Arial">Password Manager</font></b></p>
      <p align="center"><font face="Arial">Use this option to update the default
      username and password that is used by the manager.</font></p>
      <form method="POST">
        <p align="center"><font face="Arial">Username: <input type="text" name="username" size="20"><br>
        Password: <input type="text" name="password1" size="20"><br>
        Password: <input type="text" name="password2" size="20"><br>
        <input type="hidden" name="action" value="form_pswd">
        <input type="submit" value="Update Password"></font></p>
      </form>

      <p align="center"><font face="Arial">User this to set/update the .htaccess
      passwording of the manager folder. <br>
      Note once this is set you will not need to use the above option.</font></p>
      <form method="POST">
        <p align="center"><font face="Arial">Username: <input type="text" name="username" size="20"><br>
        Password: <input type="text" name="password1" size="20"><br>
        Password: <input type="text" name="password2" size="20"><br>
        <input type="hidden" name="action" value="htaccess_pswd">
        <input type="submit" value="Update Password"></font></p>
      </form>

   ~;
}


sub htaccess_pswd
{
   local ($password);

   if ($form_data{'username'} && $form_data{'password1'})
   {
      if ($form_data{'password1'} eq $form_data{'password2'})
      {
         my $letters = &random_letters(2);
         $password = crypt($form_data{'password1'}, $letters);

         open (PASSFILE, ">./.htpasswd");
         print PASSFILE "$form_data{'username'}\:";
         print PASSFILE "$password\n";
         close(PASSFILE);

         if (!(-s "./.htaccess"))
         {
            $path = $ENV{'SCRIPT_FILENAME'};
            $path =~ s/index.cgi/.htpasswd/g;
            open (ACCESSFILE, ">./.htaccess");
            print ACCESSFILE "Options All\n";
            print ACCESSFILE "AuthType \"Basic\"\n";
            print ACCESSFILE "AuthName \"Protected Access\"\n";
            print ACCESSFILE "AuthUserFile $path\n";
            # print ACCESSFILE "<Limit GET POST>\n";
            print ACCESSFILE "require valid-user\n";
            # print ACCESSFILE "</Limit>\n";
         }
         print qq~
            <center>
            <p><font face="Arial" size="2">Your username <b> $form_data{'username'}</b> and&nbsp;<br>
            password <b> $form_data{'password1'}</b> ($password) has been set.</font></p>
            </center>
         ~;
      } else {
         print qq~
            <center>
            <p><font face="Arial">Your password entries did not match!</font></p>
            </center>
         ~;
      }
   } else {
      print qq~
         <center>
         <p><font face="Arial">Must enter a username and password!</font></p>
         </center>
      ~;
   }
}

#########################################################################
# Password Form
#########################################################################

sub form_pswd
{
   if ($form_data{'username'} && $form_data{'password1'})
   {
      if ($form_data{'password1'} eq $form_data{'password2'})
      {
         open (PASSFILE, ">./files/password.pl");
         print PASSFILE qq~
            \$username="$form_data{'username'}";
            \$password="$form_data{'password1'}";
            1;
         ~;
         close(PASSFILE);

         print qq~
            <center>
            <p><font face="Arial">Your username <b> $form_data{'username'}</b> and&nbsp;<br>
            password <b> $form_data{'password1'} </b> has been set.</p>
            </center>
         ~;
      } else {
         print qq~
            <center>
            <p><font face="Arial">Your password entries did not match!</font></p>
            </center>
         ~;
      }
   } else {
      print qq~
         <center>
         <p><font face="Arial">Must enter a username and password!</font></p>
         </center>
      ~;
   }
}

#########################################################################
# Random Letters
#########################################################################

sub random_letters
{
   my ($len) = @_;
   my $rdm;
   my $_rand;
   my @chars = split(" ", "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z");

   srand;

   for (my $i=0; $i <= $len ;$i++)
   {
      $_rand = int(rand 25);
      $rdm .= $chars[$_rand];
   }

   return($rdm);
}

1;