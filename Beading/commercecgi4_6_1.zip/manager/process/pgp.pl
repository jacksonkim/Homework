#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$pgp_user_lib = "$Path1/configuration/pgp_user_lib.pl";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('PGP/GnuPG',          'pgp_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub change_pgp_settings
{
   local($admin_email, $order_email, $cookieDomain, $cookiePath);

   open (SETTINGS, "> $pgp_user_lib") || &errorcode(__FILE__, __LINE__, "$pgp_user_lib", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   print SETTINGS  "\$sc_use_pgp =              \'" . $form_data{'sc_use_pgp'}             . "\';\n";
   print SETTINGS  "\$pgp_public_key_user_id =  \'" . $form_data{'pgp_public_key_user_id'} . "\';\n";
   print SETTINGS  "\$pgp_or_gpg =              \'" . $form_data{'pgp_or_gpg'}             . "\';\n";
   print SETTINGS  "\$pgp_config_files =        \'" . $form_data{'pgp_config_files'}       . "\';\n";
   print SETTINGS  "\$pgp_server_path =         \'" . $form_data{'pgp_server_path'}        . "\';\n";
   print SETTINGS  "\$pgp_temp_folder =         \'" . $form_data{'pgp_temp_folder'}        . "\';\n";
   print SETTINGS  "1\;\n";
   close(SETTINGS);

   &pgp_screen;
}

#############################################################################################

sub pgp_screen
{
   require "$pgp_user_lib" || &errorcode(__FILE__, __LINE__, "$pgp_user_lib", "$!", "die", "REQUIRE FILE ERROR", "Unable to require the file listed. Make sure that it exists and that it has read/write permissions");

   print qq~
      <FORM METHOD="POST" name="form">
      <p align="left"><font face="Arial"><b>PGP/GnuPG Settings:</b></font></p>
      <p align="left"><font face="Arial">If you have either PGP or GnuPG available on
      your server then you can configure it here. This is an advanced feature of the
      cart and can be complex to set up if you are not experienced with it. But the
      advantage to using it is increased security, and you will receive emails of your
      orders encrypted with the entire credit card number.</font></p>
      <CENTER>
      <div align="center">
      <TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 WIDTH=90% BORDER=0>

      <TR>
      <TD bgcolor="#5A8399">
      <b><font face="Arial" color="#FFFFFF">Settings</font></b>
      </TD>
      </TR>
      <TR>
      <TD>
      <font size="2" face="Arial">Turn it on or off here:</font>
      <p>
      <FONT face=ARIAL size=2>
      <SELECT NAME=sc_use_pgp size="1">
      <OPTION>$sc_use_pgp</OPTION>
      <OPTION>yes</OPTION>
      <OPTION>no</OPTION>
      </SELECT></font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">Method to use?</font>
      <p>
      <FONT face=ARIAL size=2>
      <SELECT NAME=pgp_or_gpg size="1">
      <OPTION>$pgp_or_gpg</OPTION>
      <OPTION>PGP</OPTION>
      <OPTION>GnuPG</OPTION>
      </SELECT></font>
      </TD>
      </TR>

      <TR>
      <TD>
      <font size="2" face="Arial">Public key user id: (email address used to
      generate key)</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="pgp_public_key_user_id" SIZE=40 MAXLENGTH="128" VALUE="$pgp_public_key_user_id">
      </font>
      </p>
      </TD>
      </TR>


      <TR>
      <TD>
      <font size="2" face="Arial">Server location to configuration files:</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="pgp_config_files" SIZE=40 VALUE="$pgp_config_files">
      </font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">Server path to executable:</font>
      <p>
      <font face="Arial">
      <input type="text" name="pgp_server_path" size="40" value="$pgp_server_path"></font></p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">Temp file folder:</font>
      <p><font face="Arial"><input type="text" name="pgp_temp_folder" size="52" value="$pgp_temp_folder"></font>
      </TD>
      </TR>

      <TR>
      <TD></TD>
      </TR>

      <TR>
      <TD>
      <p align="center">
      <FONT face=ARIAL size=2 color="#FFFFFF">
      <INPUT TYPE="HIDDEN" NAME="action" VALUE="change_pgp_settings">
      <INPUT NAME="ChangeSettings" TYPE="SUBMIT" VALUE="     Submit Changes     "></font>
      </p>
      </TD>
      </TR>
      </TABLE>
        </div>
      </CENTER>
      </FORM>
   ~;
}

1;
