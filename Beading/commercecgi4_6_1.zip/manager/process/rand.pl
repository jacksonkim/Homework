#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

@rand_key = ("B","C","D","F","G","H","J","K","L","M","N","P","Q","R","S","T","V","W","X","Y","Z");
$rand_file = "$Path1/configuration/rand_key.pl";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#
# %menu_action = ('Add Product',          'add_product');
#
#########################################################

%menu_action1 = ('Rand Key', 'rand_key_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub rand_key_screen
{
   print qq~
      <blockquote>
        <font face="Arial"><b>Random Key Generator:</b></font>
        <p><font face="Arial">This should only need to be done once when you first set
        up the store. After that the only time you would need to do it again is if
        someone where to hack the key, and this is not very likely to happen.</font></p>
        <p><font face="Arial">This key is used to generate the image letters that show
        up on the order form to prevent someone from trying to design an automated
        system that could submit orders through your site for the purpose of
        validating stolen credit cards, or made up numbers.</font></p>
        <p align="center"><font face="Arial"><a href="index.cgi?action=gen_rand_key">GENERATE
        NEW KEY!</a></font></p>
      </blockquote>
   ~;
}

sub gen_rand_key
{
   my ($letter_index, $secret_letter, $rand_key, $upd_record);

   for $i (1..1000)
   {
      $letter_index = int(rand 21);
      $secret_letter = $rand_key[$letter_index];
      push (@upd_fields, "\"$secret_letter\"");
   }

   $upd_record   = join(",", @upd_fields);

   open (RANDER, "> $rand_file");
   print RANDER qq~
   \@rand_key = ($upd_record)\;

   1\;
   ~;
   close (RANDER);

   print qq~
      <center>
      <p><font face="Arial">A new random key has been generated!</font></p>
      </center>
   ~;
}


1;