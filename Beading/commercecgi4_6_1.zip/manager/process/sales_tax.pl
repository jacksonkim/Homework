#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$sales_tax_log_file = "$Path1/data_files/sales_tax.txt";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('Sales Tax',          'sales_tax_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub sales_tax_screen
{
   local ($counter);

	open(SHIPPINGFILE, "$sales_tax_log_file") || &errorcode(__FILE__, __LINE__, "$sales_tax_log_file", "$!", "print", "FILE OPEN ERROR", "1");
	while (<SHIPPINGFILE>)
	{
	   $counter++;
	   @tax_options    = split(/\|/, $_);
      $tax_field{$counter}    = $tax_options[0];
      $tax_value{$counter}    = $tax_options[1];
      $tax_percent{$counter}  = $tax_options[2];
      chomp $ship_sub{$counter};
	}
	close (SHIPPINGFILE);

	print qq~
      <form method="POST">
      <p><font face="Arial"><b>Sales Tax Settings:</b></font></p>
      <p><font face="Arial">Use this form to set up your sales tax options!</font></p>
      <div align="center">
      <center>
      <table border="0" cellpadding="5" cellspacing="0" width="90%">
      <tr>
      <td bgcolor="#5A8399" nowrap><b><font face="Arial" size="2" color="#FFFFFF">Sales
      Tax State:</font></b></td>
      <td bgcolor="#5A8399"><b><font face="Arial" size="2" color="#FFFFFF">Sales
      Tax Percentage:</font></b></td>
      </tr>
      <tr>
      <td><font face="Arial"><input type="text" name="tax_value1" size="10" value="$tax_value{1}"></font></td>
      <td width="100%"><font face="Arial"><input type="text" name="tax_percent1" size="10" value="$tax_percent{1}"></font></td>
      </tr>
      </table>
      </center>
      </div>
      <ul>
      <li><font face="Arial" size="2"><b>Sales Tax State:</b> Enter the shipping
      state abbreviation value for which you want tax charged.</font></li>
      <li><font face="Arial" size="2"><b>Sales Tax Percentage:</b>  Enter the tax
      percentage that you want charged for sales tax.</font></li>
      </ul>
      <input type="hidden" name="action" value="update_sales_tax">
      <input type="hidden" name="tax_field1" value="$tax_field{1}">
      <p align="center"><input type="submit" value="     Update Tax     "></p>
      </form>
	~;
}

#############################################################################################

sub update_sales_tax
{
	open(SHIPPINGFILE, ">$sales_tax_log_file") || &errorcode(__FILE__, __LINE__, "$sales_tax_log_file", "$!", "print", "FILE OPEN ERROR", "1");
	print SHIPPINGFILE "$form_data{'tax_field1'}\|$form_data{'tax_value1'}\|$form_data{'tax_percent1'}\n";
	close (SHIPPINGFILE);

	&tax_updated;
}

#############################################################################################

sub tax_updated
{
   print qq~
      <p align="center"><font face="Arial" size="2" color="#FF0000">Tax Settings Updated!</font></p>
   ~;
}

1;