#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$user_settings = "$Path1/configuration/commerce_user_lib.pl";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('Program Settings',          'change_settings_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub settings_updated
{
   print qq~
      <CENTER>
      <TABLE>
      <TR>
      <TD>
      <FONT FACE=ARIAL SIZE=2 COLOR=RED>System settings have been successfully updated.</FONT>
      </TD>
      </TR>
      </TABLE>
      </CENTER>
   ~;
}

#############################################################################################

sub action_change_settings
{
   local($admin_email, $order_email, $cookieDomain, $cookiePath);

   $cookieDomain = $form_data{'sc_store_url'};
   $cookiePath = $form_data{'sc_store_url'};

   $cookieDomain =~ s/http.*:\/\///g;
   $cookieDomain =~ s/\/.*//g;
   $cookieDomain =~ s/\/commerce.cgi//g;

   $cookiePath =~ s/http.*:\/\/$cookieDomain//g;
   $cookiePath =~ s/commerce.cgi//g;
   chop $cookiePath;

   $form_data{'site_name'} =~ s/\'/\\\'/g;

   open (SETTINGS, "> $user_settings") || &errorcode(__FILE__, __LINE__, "$user_settings", "$!", "die", "FILE OPEN ERROR", "Unable to open the file listed. Make sure that it exists and that it has read/write permissions");
   print SETTINGS  "## This file contains the user specific variables\n";
   print SETTINGS  "## necessary for Commerce.cgi\n";
   print SETTINGS  "\n";
   print SETTINGS  "\$sc_send_order_to_email =            \'" . $form_data{'email_orders_yes_no'}            . "\';\n";
   print SETTINGS  "\$sc_order_email =                    \'" . $form_data{'email_address_for_orders'}       . "\';\n";
   print SETTINGS  "\$sc_store_url =                      \'" . $form_data{'sc_store_url'}                   . "\';\n";
   print SETTINGS  "\$sc_order_script_url =               \'" . $form_data{'sc_order_script_url'}            . "\';\n";
   print SETTINGS  "\$sc_admin_email =                    \'" . $form_data{'admin_email'}                    . "\';\n";
   print SETTINGS  "\$sc_domain_name_for_cookie =         \'" . $cookieDomain                                . "\';\n";
   print SETTINGS  "\$sc_path_for_cookie =                \'" . $cookiePath                                  . "\';\n";
   print SETTINGS  "\$URL_of_images_directory =           \'" . $form_data{'URL_of_images_directory'}        . "\';\n";
   print SETTINGS  "\$manager_image_path =                \'" . $form_data{'manager_image_path'}             . "\';\n";
   print SETTINGS  "\$na_image_if_not_found =             \'" . $form_data{'na_image_if_not_found'}          . "\';\n";
   print SETTINGS  "\$URL_of_secure_images_directory =    \'" . $form_data{'URL_of_secure_images_directory'} . "\';\n";
   print SETTINGS  "\$images_path =                       \'" . $form_data{'images_path'}                    . "\';\n";
   print SETTINGS  "\$items_per_page =                    \'" . $form_data{'items_per_page'}                 . "\';\n";
   print SETTINGS  "\$site_name =                         \'" . $form_data{'site_name'}                      . "\';\n";
   print SETTINGS  "\$highlightcolor =                    \'" . $form_data{'highlightcolor'}                 . "\';\n";
   print SETTINGS  "\$highlightfontcolor =                \'" . $form_data{'highlightfontcolor'}             . "\';\n";
   print SETTINGS  "\$ppage =                             \'" . $form_data{'ppage'}                          . "\';\n";
   print SETTINGS  "\$template =                          \'" . $form_data{'template'}                       . "\';\n";
   print SETTINGS  "\$sc_money_symbol =                   \'" . $form_data{'sc_money_symbol'}                . "\';\n";
   print SETTINGS  "\$sc_money_symbol_placement =         \'" . $form_data{'sc_money_symbol_placement'}      . "\';\n";
   print SETTINGS  "\$sc_shall_i_email_if_error =         \'" . $form_data{'sc_shall_i_email_if_error'}      . "\';\n";
   print SETTINGS  "\$sc_shall_i_log_errors =             \'" . $form_data{'sc_shall_i_log_errors'}          . "\';\n";
   print SETTINGS  "\$sc_shall_i_log_accesses =           \'" . $form_data{'sc_shall_i_log_accesses'}        . "\';\n";
   print SETTINGS  "\$encrypt_key =                       \'" . $form_data{'encrypt_key'}                    . "\';\n";
   print SETTINGS  "\$display_cart =                      \'" . $form_data{'display_cart'}                   . "\';\n";
   print SETTINGS  "\$time_dif =                          \'" . $form_data{'time_dif'}                       . "\';\n";
   print SETTINGS  "\$new_cart_permissions =                " . $form_data{'set_cart_permissions'}           . ";\n";
   print SETTINGS  "\$set_cart_permissions =              \'" . $form_data{'set_cart_permissions'}           . "\';\n";
   print SETTINGS  "1\;\n";

   close(SETTINGS);

   &settings_updated;
}

#############################################################################################

sub change_settings_screen
{
   require "$user_settings" || &errorcode(__FILE__, __LINE__, "$user_settings", "$!", "die", "REQUIRE FILE ERROR", "Unable to require the file listed. Make sure that it exists and that it has read/write permissions");

	local ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst,$date,@days, @months);

	@days = ('Sunday','Monday','Tuesday','Wednesday','Thursday', 'Friday','Saturday');
	@months = ('January','February','March','April','May','June','July', 'August','September','October','November','December');

	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

   $hour = sprintf("%02d", $hour);
   $min  = sprintf("%02d", $min);
   $sec  = sprintf("%02d", $sec);

	$AM_PM = "AM";
	if ($hour > 11){ $AM_PM = "PM"; }
	if ($hour > 12){ $hour -= 12; }

	$year += 1900;
	$server_time = "$days[$wday], $months[$mon] $mday, $year at $hour\:$min\:$sec $AM_PM";

	$sc_money_symbol =~ s/\\//g;

   print qq~
      <FORM METHOD="POST" name="form">
      <CENTER>
      <div align="center">
      <TABLE WIDTH=90% cellpadding="10" cellspacing="0">
      <TR>
      <TD>
      <font face="Arial">Welcome to the <b>Commerce.cgi</b> System Manager. Here you will set the data variables specific to your store.
      Each value is defined and described, so you should have no problem getting through this part.</font>
      </TD>
      </TR>
      </TABLE>
      </div>
      <div align="center">
      <TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 WIDTH=90% BORDER=0>

      <TR>
      <TD bgcolor="#5A8399">
      <b><font face="Arial" color="#FFFFFF">Shopping Cart URL's:</font></b>
      </TD>
      </TR>
      <TR>
      <TD>
      <font size="2" face="Arial">
      1) Please enter the full URL of your store here<BR>
      (ex: <b>http://www.commerce-cgi.com/cgi-bin/store/commerce.cgi</b>)</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="sc_store_url" TYPE="TEXT" SIZE=70 MAXLENGTH="128" VALUE="$sc_store_url">
      </font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font size="2" face="Arial">
      2) Please enter the SECURE URL of your store here<BR>
      (ex: <b>https://www.commerce-cgi.com/cgi-bin/store/commerce.cgi</b>)<br>
      If using a gateway that does not require security then just enter the non
      secure URL.</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="sc_order_script_url" SIZE=70 MAXLENGTH="128" VALUE="$sc_order_script_url">
      </font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font size="2" face="Arial">
      3) Please enter the full URL of your /images directory. For example:<br>
      <b>http://www.commerce-cgi.com/cgi-bin/store/images</b><br>
      DO NOT include the trailing slash!!! <b>/</b>
      </font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="URL_of_images_directory" TYPE="TEXT" SIZE=70 VALUE="$URL_of_images_directory">
      </font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font size="2" face="Arial">
      4) Please enter the full SECURE URL of your /images directory. For example:<br>
      <b>https://www.commerce-cgi.com/cgi-bin/store/images</b><br>
      DO NOT include the trailing slash!!! <b>/</b>
      </font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="URL_of_secure_images_directory" TYPE="TEXT" SIZE=70 VALUE="$URL_of_secure_images_directory">
      </font>
      </p>
      </TD>
      </TR>
      <tr>
      <TD bgcolor="#5A8399">
      <font face="Arial" color="#FFFFFF"><b>Image Paths: </b></font><font face="Arial" size="2" color="#FFFFFF">(If you have had to move
      your images folder then you will need to change these.)</font></TD>
      </tr>
      <TR>
      <TD>
      <font size="2" face="Arial">
      5) Display not found image when an image does not exist?
      </font>
      <p>
      <FONT face=ARIAL size=2>
      <select NAME=na_image_if_not_found>
      <OPTION>$na_image_if_not_found</OPTION>
      <OPTION>yes</OPTION>
      <OPTION>no</OPTION>
      </SELECT>
      </font>
      </p>
      </TD>
      </TR>
      <tr>
      <TD>
      <font face="Arial" size="2">
      6) Server path to images folder related to the location of commerce.cgi.</font>
      <p><font face="Arial"><input type="text" name="images_path" size="27" value="$images_path"></font>
      </TD>
      </tr>


      <TR>
      <TD>
      <font face="ARIAL" size="2">
      7) This is the server path to the images folder referenced from the manager folder.</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="manager_image_path" SIZE=42 VALUE="$manager_image_path"></font>
      </TD>
      </TR>
      <TR>
      <TD bgcolor="#5A8399">
      <font face="Arial" color="#FFFFFF"><b>
      Error/Access Logging:</b></font></TD>
      </TR>


      <TR>
      <TD>
      <FONT face=ARIAL size=2>
      8) Shall we email error messages?</font>
      <p>
      <FONT face=ARIAL size=2>
      <SELECT NAME=sc_shall_i_email_if_error>
      <OPTION>$sc_shall_i_email_if_error</OPTION>
      <OPTION>yes</OPTION>
      <OPTION>no</OPTION>
      </SELECT>
      </font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <FONT face=ARIAL size=2>
      9) Shall we log error messages?</font>
      <p>
      <FONT face=ARIAL size=2>
      <SELECT NAME=sc_shall_i_log_errors>
      <OPTION>$sc_shall_i_log_errors</OPTION>
      <OPTION>yes</OPTION>
      <OPTION>no</OPTION>
      </SELECT>
      </font>
      </p>
      </TD>
      </TR>

      <TR>
      <TD>
      <FONT face=ARIAL size=2>
      10) Shall we log accesses?</font>
      <p>
      <FONT face=ARIAL size=2>
      <SELECT NAME=sc_shall_i_log_accesses>
      <OPTION>$sc_shall_i_log_accesses</OPTION>
      <OPTION>yes</OPTION>
      <OPTION>no</OPTION>
      </SELECT>
      </font>
      </p>
      </TD>
      </TR>

      <tr>
      <TD bgcolor="#5A8399"><font face="Arial" color="#FFFFFF"><b>Security:</b></font></TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">11) Secret Encryption Key.</font>
      <p>
      <font face="Arial">
      <input type="text" name="encrypt_key" size="11" value="$encrypt_key"></font></p>
      </TD>
      </TR>

      <TR>
      <TD bgcolor="#5A8399">
      <font face="Arial" color="#FFFFFF"><b>
      Orders:</b></font></TD>
      </TR>
      <TR>
      <TD>
      <FONT face=ARIAL size=2>
      12) Do you wish to have orders e-mailed to you?</font>
      <p>
      <FONT face=ARIAL size=2>
      <SELECT NAME="email_orders_yes_no">
      <OPTION>$sc_send_order_to_email</OPTION>
      <OPTION>yes</OPTION>
      <OPTION>no</OPTION>
      </SELECT>
      </font>
      </p>
      </TD>
      </TR>
      <TR>
      <TD>
      <font size="2" face="Arial">
      13) Enter the e-mail address where you'd like the orders sent</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="email_address_for_orders" TYPE="TEXT" VALUE="$sc_order_email" SIZE="55">
      </font>
      </p>
      </TD>
      </TR>
      <TR>
      <TD>
      <font size="2" face="Arial">
      14) Enter the e-mail address of your webmaster or administrator here</font>
      <p>
      <FONT face=ARIAL size=2>
      <INPUT NAME="admin_email" TYPE="TEXT" VALUE="$sc_admin_email" SIZE="55">
      </font>
      </p>
      </TD>
      </TR>
      <TR>
      <TD bgcolor="#5A8399">
      <font face="Arial" color="#FFFFFF"><b>
      Display:</b></font></TD>
      </TR>
      <tr>
      <TD valign="middle">
      <font face="Arial" size="2">15) Site Name:</font>
      <p><FONT face=ARIAL size=2><input type="text" name="site_name" size="41" value="$site_name"></font></p>
        </TD>
      </tr>
      <TR>
      <TD>
      <FONT face="ARIAL" size="2">
      16) How many products do you wish to display on each product page?</font>
      <p>
      <FONT face="ARIAL" size="2">
      <input type="text" name="items_per_page" value="$items_per_page" size="7">
      </font>
      </p>
      </TD>
      </TR>
      <TR>
      <TD>
      <font face="ARIAL" size="2">17) Choose/Enter the highlight color:</font>
        <p><font face="Arial"><SCRIPT LANGUAGE="JavaScript">
      <!--
      // Copyright (c) 1996-1997 Tomer Shiran (yehuda\@geocities.com). All rights reserved.
      // Courtesy of SimplytheBest.net (http://simplythebest.net/info/dhtml_scripts.html)
      // create 6-element array
      var hex = new Array(6)
      // assign non-dithered descriptors
      hex[0] = "FF"
      hex[1] = "CC"
      hex[2] = "99"
      hex[3] = "66"
      hex[4] = "33"
      hex[5] = "00"
      function display(triplet) {
              form.highlightcolor.value = '#' + triplet
      }
      function drawCell(red, green, blue) {
        document.write('<TD BGCOLOR="#' + red + green + blue + '">')
        document.write('<A HREF="javascript:display(\\'' + (red + green + blue) + '\\')">')
        document.write('<IMG SRC="$URL_of_images_directory/manager/line.gif" BORDER=0 HEIGHT=12 WIDTH=12>')
        document.write('</A>')
        document.write('</TD>')
      }
      function drawRow(red, blue) {
              document.write('<TR>')
              for (var i = 0; i < 6; ++i) {
                      drawCell(red, hex[i], blue)
              }
              document.write('</TR>')
      }
      function drawTable(blue) {
              document.write('<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>')
              for (var i = 0; i < 6; ++i) {
                      drawRow(hex[i], blue)
              }
              document.write('</TABLE>')
      }
      function drawCube() {
              document.write('<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1 BORDERCOLOR="#CCCCFF"><TR>')
              for (var i = 0; i < 6; ++i) {
                      document.write('<TD BGCOLOR="#FFFFFF">')
                      drawTable(hex[i])
                      document.write('</TD>')
              }
              document.write('</TR></TABLE>')
      }
      drawCube()
      // -->
      </SCRIPT>

      <input type="text" name="highlightcolor" size="20" value="$highlightcolor"></font></p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font size="2" face="Arial">18) Choose/Enter the
        highlight font color:</font>
      <p>
      <font face="Arial">
      <SCRIPT LANGUAGE="JavaScript">
      <!--
      // Copyright (c) 1996-1997 Tomer Shiran (yehuda\@geocities.com). All rights reserved.
      // Courtesy of SimplytheBest.net (http://simplythebest.net/info/dhtml_scripts.html)
      // create 6-element array
      var hex = new Array(6)
      // assign non-dithered descriptors
      hex[0] = "FF"
      hex[1] = "CC"
      hex[2] = "99"
      hex[3] = "66"
      hex[4] = "33"
      hex[5] = "00"
      function display1(triplet) {
              form.highlightfontcolor.value = '#' + triplet
      }
      function drawCell(red, green, blue) {
              document.write('<TD BGCOLOR="#' + red + green + blue + '">')
              document.write('<A HREF="javascript:display1(\\'' + (red + green + blue) + '\\')">')
              document.write('<IMG SRC="$URL_of_images_directory/manager/line.gif" BORDER=0 HEIGHT=12 WIDTH=12>')
              document.write('</A>')
              document.write('</TD>')
      }
      function drawRow(red, blue) {
              document.write('<TR>')
              for (var i = 0; i < 6; ++i) {
                      drawCell(red, hex[i], blue)
              }
              document.write('</TR>')
      }
      function drawTable(blue) {
              document.write('<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0>')
              for (var i = 0; i < 6; ++i) {
                      drawRow(hex[i], blue)
              }
              document.write('</TABLE>')
      }
      function drawCube() {
              document.write('<TABLE CELLPADDING=5 CELLSPACING=0 BORDER=1 BORDERCOLOR="#CCCCFF"><TR>')
              for (var i = 0; i < 6; ++i) {
                      document.write('<TD BGCOLOR="#FFFFFF">')
                      drawTable(hex[i])
                      document.write('</TD>')
              }
              document.write('</TR></TABLE>')
      }
      drawCube()
      // -->
      </SCRIPT>
      <input type="text" name="highlightfontcolor" size="20" value="$highlightfontcolor"></font></p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">19) Enter money
        symbol, and if it should appear before or after the amount.</font>
      <p>
      <font face="Arial">
      <input type="text" name="sc_money_symbol" size="11" value="$sc_money_symbol">&nbsp;
        <select size="1" name="sc_money_symbol_placement">
          <option>$sc_money_symbol_placement</option>
          <option>front</option>
          <option>back</option>
        </select></font></p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">20) Product page
        template.</font>
      <p>
      <font face="Arial">
      <input type="text" name="ppage" size="11" value="$ppage"></font></p>
      </TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">21) Site design
        template.</font>
      <p>
      <font face="Arial">
      <input type="text" name="template" size="11" value="$template"></font></p>
      </TD>
      </TR>

      <tr>
      <TD>
      <font face="Arial" size="2">22) Would you like to
      display the shopping cart after an item has been added to the cart?</font>
      <p>
      <font face="Arial">
      <select size="1" name="display_cart">
          <option>$display_cart</option>
          <option>yes</option>
          <option>no</option>
        </select></font></p>
        </TD>
      </tr>

      <TR>
      <TD bgcolor="#5A8399"><font face="Arial" color="#FFFFFF"><b>Misc.:</b></font></TD>
      </TR>

      <TR>
      <TD>
      <font face="Arial" size="2">23) Time difference in
      hours between your local time and the time on your server<BR>Server time:
      $server_time</font>
      <p>
      <font face="Arial">
      <input type="text" name="time_dif" size="11" value="$time_dif"></font></p>
      </TD>
      </TR>

      <TR>
      <TD><font face="Arial" size="2">24) New cart permissions. This will depend a
        lot on your server configuration. 0766 should work the best. If 0777 is
        required then you should change server because this is a security risk!.</font>
        <p><font face="Arial">
      <input type="text" name="set_cart_permissions" size="11" value="$set_cart_permissions"></font></TD>
      </TR>

      <TR>
      <TD></TD>
      </TR>

      <TR>
      <TD>
      <p align="center">
      <FONT face=ARIAL size=2 color="#FFFFFF">
      <INPUT TYPE="HIDDEN" NAME="action" VALUE="action_change_settings">
      <INPUT NAME="ChangeSettings" TYPE="SUBMIT" VALUE="     Submit Changes     "></font>
      </p>
      </TD>
      </TR>
      </TABLE>
        </div>
      </CENTER>
      </FORM>
   ~;
}

1;
