#########################################################
# Manager process file
#
# The manager is designed to be very expandable and all
# You need to do is download new process files and add
# them to your /manager/process/ folder.
#########################################################

#########################################################
# Configuration Section
#
# If there are any variables that need to be set by the
# user then add those here.
#########################################################

$shipping_log_file = "$Path1/data_files/shipping.txt";

#########################################################
# Menu Items
#
# Items to appear on the menu, and the sub that will
# run when clicked.
#########################################################

%menu_action1 = ('Shipping',          'shipping_screen');

#########################################################
# Main Code Section
#
# All subs should include an 'action' vaiable that tells it
# which sub should be executed next.
#########################################################

sub shipping_screen
{
   local ($counter);

	open(SHIPPINGFILE, "$shipping_log_file") || &errorcode(__FILE__, __LINE__, "$shipping_log_file", "$!", "print", "FILE OPEN ERROR", "1");
	while (<SHIPPINGFILE>)
	{
	   $counter++;
	   @ship_options    = split(/\|/, $_);
      $ship_abbv{$counter}    = $ship_options[0];
      $ship_name{$counter}    = $ship_options[1];
      $ship_price{$counter}   = $ship_options[2];
      $ship_percent{$counter} = $ship_options[3];
      $ship_prd{$counter}     = $ship_options[4];
      $ship_sub{$counter}     = $ship_options[5];
      chomp $ship_sub{$counter};
	}
	close (SHIPPINGFILE);

	print qq~
      $ship_done_message

      <form method="POST">

      <div class="default_bold">Shipping Settings:</div><br>
      <div class="default_text">Use this form to set up your shipping options!</div><br>
      <div align="center">
      <center>
      <table border="0" cellpadding="2" cellspacing="0" width="90%">
      <tr>
      <td class="colored_cell_header">Abbreviation:</b></td>
      <td class="colored_cell_header">Ship Name:</b></td>
      <td class="colored_cell_header">Price:</b></td>
      <td class="colored_cell_header">Percentage:</b></td>
      <td class="colored_cell_header">Product:</b></td>
      <td class="colored_cell_header">Special Sub Routine:</b></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv1" size="10" value="$ship_abbv{1}"></td>
      <td><input type="text" name="ship_name1" size="29" value="$ship_name{1}"></td>
      <td><input type="text" name="ship_price1" size="10" value="$ship_price{1}"></td>
      <td><input type="text" name="ship_percent1" size="10" value="$ship_percent{1}"></td>
      <td><select size="1" name="ship_prd1">
      <option>$ship_prd{1}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub1" size="19" value="$ship_sub{1}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv2" size="10" value="$ship_abbv{2}"></td>
      <td><input type="text" name="ship_name2" size="29" value="$ship_name{2}"></td>
      <td><input type="text" name="ship_price2" size="10" value="$ship_price{2}"></td>
      <td><input type="text" name="ship_percent2" size="10" value="$ship_percent{2}"></td>
      <td><select size="1" name="ship_prd2">
      <option>$ship_prd{2}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub2" size="19" value="$ship_sub{2}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv3" size="10" value="$ship_abbv{3}"></td>
      <td><input type="text" name="ship_name3" size="29" value="$ship_name{3}"></td>
      <td><input type="text" name="ship_price3" size="10" value="$ship_price{3}"></td>
      <td><input type="text" name="ship_percent3" size="10" value="$ship_percent{3}"></td>
      <td><select size="1" name="ship_prd3">
      <option>$ship_prd{3}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub3" size="19" value="$ship_sub{3}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv4" size="10" value="$ship_abbv{4}"></td>
      <td><input type="text" name="ship_name4" size="29" value="$ship_name{4}"></td>
      <td><input type="text" name="ship_price4" size="10" value="$ship_price{4}"></td>
      <td><input type="text" name="ship_percent4" size="10" value="$ship_percent{4}"></td>
      <td><select size="1" name="ship_prd4">
      <option>$ship_prd{4}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub4" size="19" value="$ship_sub{4}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv5" size="10" value="$ship_abbv{5}"></td>
      <td><input type="text" name="ship_name5" size="29" value="$ship_name{5}"></td>
      <td><input type="text" name="ship_price5" size="10" value="$ship_price{5}"></td>
      <td><input type="text" name="ship_percent5" size="10" value="$ship_percent{5}"></td>
      <td><select size="1" name="ship_prd5">
      <option>$ship_prd{5}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub5" size="19" value="$ship_sub{5}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv6" size="10" value="$ship_abbv{6}"></td>
      <td><input type="text" name="ship_name6" size="29" value="$ship_name{6}"></td>
      <td><input type="text" name="ship_price6" size="10" value="$ship_price{6}"></td>
      <td><input type="text" name="ship_percent6" size="10" value="$ship_percent{6}"></td>
      <td><select size="1" name="ship_prd6">
      <option>$ship_prd{6}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub6" size="19" value="$ship_sub{6}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv7" size="10" value="$ship_abbv{7}"></td>
      <td><input type="text" name="ship_name7" size="29" value="$ship_name{7}"></td>
      <td><input type="text" name="ship_price7" size="10" value="$ship_price{7}"></td>
      <td><input type="text" name="ship_percent7" size="10" value="$ship_percent{7}"></td>
      <td><select size="1" name="ship_prd7">
      <option>$ship_prd{7}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub7" size="19" value="$ship_sub{7}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv8" size="10" value="$ship_abbv{8}"></td>
      <td><input type="text" name="ship_name8" size="29" value="$ship_name{8}"></td>
      <td><input type="text" name="ship_price8" size="10" value="$ship_price{8}"></td>
      <td><input type="text" name="ship_percent8" size="10" value="$ship_percent{8}"></td>
      <td><select size="1" name="ship_prd8">
      <option>$ship_prd{8}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub8" size="19" value="$ship_sub{8}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv9" size="10" value="$ship_abbv{9}"></td>
      <td><input type="text" name="ship_name9" size="29" value="$ship_name{9}"></td>
      <td><input type="text" name="ship_price9" size="10" value="$ship_price{9}"></td>
      <td><input type="text" name="ship_percent9" size="10" value="$ship_percent{9}"></td>
      <td><select size="1" name="ship_prd9">
      <option>$ship_prd{9}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub9" size="19" value="$ship_sub{9}"></td>
      </tr>
      <tr>
      <td><input type="text" name="ship_abbv10" size="10" value="$ship_abbv{10}"></td>
      <td><input type="text" name="ship_name10" size="29" value="$ship_name{10}"></td>
      <td><input type="text" name="ship_price10" size="10" value="$ship_price{10}"></td>
      <td><input type="text" name="ship_percent10" size="10" value="$ship_percent{10}"></td>
      <td><select size="1" name="ship_prd10">
      <option>$ship_prd{10}</option>
      <option>yes</option>
      <option>no</option>
      </select></td>
      <td><input type="text" name="ship_sub10" size="19" value="$ship_sub{10}"></td>
      </tr>
      </table>
      </center>
      </div>
      <ul class="default_text">
      <li><b>Abbreviate:</b> This is a unique abbreviation of the shipping method such as UPS, FEDEX, UPR, PICKUP.</li>
      <li><b>Ship Name:</b> This is the descriptive name that will show up on the order form, and the order.</li>
      <li><b>Price:</b> This is a flat price that will be added to the shipping amount for this method.</li>
      <li><b>Percentage:</b> This is a percentage of the subtotal that will be added to the shipping amount.</li>
      <li><b>Product:</b> When adding products you can specify a shipping amount for each item that is multiplied by the quantity. This determines whether or not this is used.</li>
      <li><b>Special Sub Routine:</b> This is for more advanced shipping options. Here you would enter the name of a special sub routine that you have written or downloaded that will calculate the shipping. There are many custom shipping logics that we have written that are in the commerce.cgi members area for download.</li>
      </ul>

      <input type=hidden name=action value=update_shipping>
      <div class="centered"><input type="submit" value="     Update Shipping     "></div>
      </form>
	~;
}

#############################################################################################

sub update_shipping
{
	open(SHIPPINGFILE, "> $shipping_log_file") || &errorcode(__FILE__, __LINE__, "$shipping_log_file", "$!", "print", "FILE OPEN ERROR", "1");
	if ($form_data{'ship_abbv1'} && $form_data{'ship_name1'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv1'}\|$form_data{'ship_name1'}\|$form_data{'ship_price1'}\|$form_data{'ship_percent1'}\|$form_data{'ship_prd1'}\|$form_data{'ship_sub1'}\n";
	}
	if ($form_data{'ship_abbv2'} && $form_data{'ship_name2'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv2'}\|$form_data{'ship_name2'}\|$form_data{'ship_price2'}\|$form_data{'ship_percent2'}\|$form_data{'ship_prd2'}\|$form_data{'ship_sub2'}\n";
	}
	if ($form_data{'ship_abbv3'} && $form_data{'ship_name3'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv3'}\|$form_data{'ship_name3'}\|$form_data{'ship_price3'}\|$form_data{'ship_percent3'}\|$form_data{'ship_prd3'}\|$form_data{'ship_sub3'}\n";
	}
	if ($form_data{'ship_abbv4'} && $form_data{'ship_name4'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv4'}\|$form_data{'ship_name4'}\|$form_data{'ship_price4'}\|$form_data{'ship_percent4'}\|$form_data{'ship_prd4'}\|$form_data{'ship_sub4'}\n";
	}
	if ($form_data{'ship_abbv5'} && $form_data{'ship_name5'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv5'}\|$form_data{'ship_name5'}\|$form_data{'ship_price5'}\|$form_data{'ship_percent5'}\|$form_data{'ship_prd5'}\|$form_data{'ship_sub5'}\n";
	}
	if ($form_data{'ship_abbv6'} && $form_data{'ship_name6'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv6'}\|$form_data{'ship_name6'}\|$form_data{'ship_price6'}\|$form_data{'ship_percent6'}\|$form_data{'ship_prd6'}\|$form_data{'ship_sub6'}\n";
	}
	if ($form_data{'ship_abbv7'} && $form_data{'ship_name7'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv7'}\|$form_data{'ship_name7'}\|$form_data{'ship_price7'}\|$form_data{'ship_percent7'}\|$form_data{'ship_prd7'}\|$form_data{'ship_sub7'}\n";
	}
	if ($form_data{'ship_abbv8'} && $form_data{'ship_name8'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv8'}\|$form_data{'ship_name8'}\|$form_data{'ship_price8'}\|$form_data{'ship_percent8'}\|$form_data{'ship_prd8'}\|$form_data{'ship_sub8'}\n";
	}
	if ($form_data{'ship_abbv9'} && $form_data{'ship_name9'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv9'}\|$form_data{'ship_name9'}\|$form_data{'ship_price9'}\|$form_data{'ship_percent9'}\|$form_data{'ship_prd9'}\|$form_data{'ship_sub9'}\n";
	}
	if ($form_data{'ship_abbv10'} && $form_data{'ship_name10'})
	{
	   print SHIPPINGFILE "$form_data{'ship_abbv10'}\|$form_data{'ship_name10'}\|$form_data{'ship_price10'}\|$form_data{'ship_percent10'}\|$form_data{'ship_prd10'}\|$form_data{'ship_sub10'}\n";
	}
	close (SHIPPINGFILE);

	&shipping_complete;
}

#####################################################################################

sub shipping_complete
{
   print qq~
      <CENTER>
      <TABLE>
      <TR>
      <TD>
      <FONT FACE=ARIAL SIZE=2 COLOR=RED>Shipping settings
      have been successfully updated.</FONT>
      </TD>
      </TR>
      </TABLE>
      </CENTER>
   ~;
}

1;