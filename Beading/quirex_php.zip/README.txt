#######################################################################
#                             Quirex PHP                              #
#              By Thomas Tsoi <cgi@cgihk.com> 2001-09-17              #
#        Copyright 2001 (c) CGIHK.com.  All rights reserved.          #
#######################################################################
#                                                                     #
# CGIHK.com:                                                          #
#   http://www.cgihk.com/                                             #
# Support:                                                            #
#   http://www.cgihk.com/forum/                                       #
# ThomasTsoi.com                                                      #
#   http://www.ThomasTsoi.com/                                        #
# Winapi.com                                                          #
#   http://www.winapi.com/                                            #
# Astronomy.org.hk                                                    #
#   http://www.astronomy.org.hk/                                      #
#                                                                     #
# ################################################################### #
#                                                                     #
#        This is a commercial product and CANNOT be distributed       #
#                  without the author's authorization.                #
#                                                                     #
#######################################################################


TABLE OF CONTENTS
    1. Welcome
        1.1 About the script
        1.2 A bit history
    2. Uploading Files
    3. Installation
    4. Customization
    5. Using Quirex
    6. Customizing Quirex' language set
    7. Embedding Quirex in your web page
    8. Backup/Restore Quirex
    9. Enquiries
    
=======================================================================

1. Welcome

1.1 About the script
-------------------------------------------------
Quirex is a quiz system suitable for many uses. Whether you are a 
teacher who wishes to let your students take the quizzes, and have the
reports emailed to you, or a web site developer who wants to have a
quiz installed on your web site to give some fun to your visitors, 
Quirex is for you.

1.2 A bit history
-------------------------------------------------
Date back to the July of 1999 when I was working on my astronomy 
web site at http://www.astronomy.org.hk, I was hoping to set up an
interactive quiz. I wanted to find a script to display questions from a
database randomly, but I was out of luck. So I decided to write one
myself. Feedbacks were quite positive when the script was released to 
the public, so I wrote an admin script to make it easier to manage. The
development stopped at version 1.3 due to my heavy workload. Finally,
version 2.0 was launched 1.5 years later. A lot of users emailed me with
thank you for Quirex 2.x. Therefore, 5 months later, Quiex PHP
was out, fixed a lot of bugs, added a lot of functions, and gave users
more control over the script. Since this was a big project and spent me
a lot of time, a nominal fee was charged, I hope you all can understand
my points.

2. Uploading Files
-------------------------------------------------
Here is a list of files that came with Quirex.

    Directory  File                       Desc           chmod

    <./>                               
             admin.cgi           Admin script             ---
             index.cgi           Main script              ---
             config.pl           Config parameters        ---
             install.pl          Installation script      ---
             language.php        English                  ---
             language_chin.php   Traditional Chinese      ---
             sample_ques.php     For embedding ques       ---
             test.php          	 Sample using sample_ques ---
             pic1.gif                                     ---
             pic2.gif                                     ---
             pic3.gif                                     ---
             pic4.gif                                     ---
             README.txt          This file                ---

    <./images>
                 panel_01.gif                             ---
                 panel_02.gif                             ---
                 panel_03.gif                             ---
                 panel_04.gif                             ---
                 panel_05.gif                             ---
                 panel_06.gif                             ---
                 quirex.gif                               ---

    <./data>                                              777

Upload all these files to a directory on your server and set the 
directory "data" writeable (777) to all.

3. Installation
-------------------------------------------------
Open config.php with your favourite text editor, enter your MySQL
hostname (leave it as "localhost" in most cases), username, password
and database name.
After that, run install.php, follow the steps indicated by the script.
After the installation, delete install.php for security reasons.

4. Customization
-------------------------------------------------
Access admin.php, enter the password you have set in the installation.

5. Using Quirex
-------------------------------------------------
Access admin.php for administration of Quirex.
When adding Multiple Choice and Multiple Answer questions, you can use
images as the options/choices. Simply enter 
[img=http://www.url.to/image.gif]      (no quotes "")
in the choice fields.

Access index.php for the quiz.

If you do not need multiple quizzes, and wish to access one particular
quiz, you get do so with the HTML

  http://my.host.com/cgi-bin/quirex/index.cgi?quiz=[quiz_id]
   -or-
  http://my.host.com/cgi-bin/quirex/index.cgi?quiz=[quiz_id]&number=[number]

where [quiz_id] is the quiz_id of the quiz. You can find the quiz_id of a
quiz in the "View a Quiz" section of the Administration Panel.
[number] is the number of questions to display in the quiz. Omitting 
number=[number] will make the quiz display 10 questions only.

6. Customizing Quirex' language set
-------------------------------------------------
Edit language.php to customize Quirex' text, or change it to your language.

7. Embedding Quirex in your web page
-------------------------------------------------
This is a new feature of Quirex. You can embed a question into your PHP
web page, let a visitor answer that question, and he will be sent to the
actual Quirex script, and continue with the rest of the quiz.

To use this feature, write the following in your PHP page:
<?
require("sample_ques.php"); 
show_question(quiz_id, question_no [, quirex_script_url]);
?>

where [quiz_id] is the quiz_id of the quiz. You can find the quiz_id of a
quiz in the "View a Quiz" section of the Administration Panel.
[question_no] is the number of question the actual quiz should display,
set it to a number or set it to "All" to display all questions.
[quirex_script_url] is the url to index.php, not necessary if you have not
changed its name. i.e. if you have changed index.php to quirex.php, for 
example, you'll need to write show_question(1, "All", "quirex.php");

Check out test.php, which is a sample of this function.

8. Backup/Restore Quirex
-------------------------------------------------
To Backup or restore Quirex, the "data" directory must be chmod to 777.
Then, access the Administration Panel, go to the section "Backup/Restore
Quirex". This is a useful feature, but use it with caution to prevent
unintended restoration.

9. Enquiries
-------------------------------------------------
If you have any problems during the setup, please visit the support
forum of our website at:

    http://www.cgihk.com/forum/

Good Luck!

Thomas Tsoi