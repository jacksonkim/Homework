<?
#######################################################################
#                             Quirex PHP                              #
#              By Thomas Tsoi <cgi@cgihk.com> 2001-09-17              #
#        Copyright 2001 (c) CGIHK.com.  All rights reserved.          #
#######################################################################
#                                                                     #
# CGIHK.com:                                                          #
#   http://www.cgihk.com/                                             #
# Support:                                                            #
#   http://www.cgihk.com/forum/                                       #
# ThomasTsoi.com                                                      #
#   http://www.ThomasTsoi.com/                                        #
# Winapi.com                                                          #
#   http://www.winapi.com/                                            #
# Astronomy.org.hk                                                    #
#   http://www.astronomy.org.hk/                                      #
#                                                                     #
# ################################################################### #
#                                                                     #
#        This is a commercial product and CANNOT be distributed       #
#                  without the author's authorization.                #
#                                                                     #
#######################################################################


require("config.php");

if (! mysql_connect($host, $username, $password)) {
	print "MySQL Error: " . mysql_error();
	exit;
	}
mysql_select_db($database);
$result = mysql_query(
"SELECT anticheat, require_info, show_record, show_answer, show_copyright, " . 
"use_table, randomize_ans, allow_empty_ans, " . 
"admin_password, admin_email, email_admin, email_taker, header, footer, ".
"url_site, url_tick, url_cross, font_face, font_color, table_border_color, ".
"table_color_1, table_color_2, level_name_1, level_name_2, level_name_3, ".
"no_options, no_recent, no_top FROM quirex_config");
if ($result) {
	list($anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top) = mysql_fetch_row($result);
	}
else {
	print "MySQL Error: " . mysql_error();
	exit;
	}
$script = "admin.php";

session_start();
if ($action == 'login') {
	if ($pass == $admin_password) {
		$my_pass = $pass;
		session_register("my_pass");
		}
	}
elseif ($action == 'config' && $do == 'password' && $do2 == 'password') {
	if ($old_admin_password == $admin_password && $new_admin_password == $new_admin_password2) {
		mysql_query("UPDATE quirex_config SET admin_password = '$new_admin_password'");
		$my_pass = $new_admin_password;
		session_register("my_pass");
		$admin_password = $new_admin_password;
		}
	}
else {
	$my_pass = $HTTP_SESSION_VARS["my_pass"];
	if ($action == 'logout') {
		$arrSessions=$HTTP_SESSION_VARS; 
		session_destroy(); 
		foreach ($arrSessions as $session_name => $session_value) { 
			unset($$session_name); 
			} 
		unset($arrSessions);
		}
	}

if 	($action == 'view_ques') 	{
	if ($my_pass != $admin_password) {login();}
	else {
		view_ques();
		exit;
		}	
	}

printheader();

if ($action == 'login') {
	if ($pass == $admin_password) {show_panel();}
	else {print "<p align=center>ERROR: Password Incorrect!</p>";}
	}
elseif ($action == 'logout') {logout();}
else {
	if ($my_pass != $admin_password) {login();}
	else {
		if 			($action == 'add') 		{add();}
		elseif 	($action == 'view') 	{view();}
		elseif 	($action == 'edit') 	{edit();}
		elseif 	($action == 'remove') {remove();}
		elseif 	($action == 'config') {config();}
		elseif 	($action == 'backup') {backup();}
		else 		{show_panel();}
		}
	}
printfooter();



function printheader() {
	print "<html>\n";
	print "<head>\n";
	print "<title>Quirex Administration Panel</title>\n";
	print "</head>\n";
	print "<style>\n";
	print "<!--\n";
	print "a {text-decoration : none}\n";
	print "a:hover {text-decoration : underline; color: ddddff}\n";
	print "// -->\n";
	print "</style>\n";
	print "<body bgcolor=\"#587AB1\" text=\"#ffffff\" link=\"#ffffff\" vlink=\"ffdddd\">\n";
	print "<table width=\"550\" height=400 border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=center>\n";
	print "<tr><td colspan=\"3\" width=\"550\" height=\"60\"><img src=\"images/panel_01.gif\" width=\"550\" height=\"60\"></td></tr>\n";
	print "<tr>\n";
	print "	<td width=20 height=\"289\" background=\"images/panel_02.gif\"><img src=\"images/panel_02.gif\" width=\"20\" height=\"100%\"></td>\n";
	print "	<td width=510 height=\"289\">\n";
	print "	<table width=510 border=0 cellspacing=0 cellpadding=0><tr><td>\n";
	print "<font color=\"#ffffff\" face=Arial size=2>\n";
	}

function printfooter() {
	print "</font>\n";
	print "		</td></tr></table>\n";
	print "		</td>\n";
	print "		<td width=20 height=\"289\" background=\"images/panel_04.gif\"><img src=\"images/panel_04.gif\" width=\"20\" height=\"100%\"></td>\n";
	print "	</tr>\n";
	print "	<tr><td colspan=\"3\" width=\"550\" height=\"26\"><img src=\"images/panel_05.gif\" width=\"550\" height=\"26\"></td></tr>\n";
	print "	<tr><td colspan=\"3\" width=\"550\" height=\"25\"><a href=\"http://www.cgihk.com\"><img src=\"images/panel_06.gif\" width=\"550\" height=\"25\" border=\"0\"></a></td></tr>\n";
	print "	</table>\n";
	print "	</body>\n";
	print "	</html>\n";
	}

function login() {
	global $script;
	print "<p align=center><img src=\"images/quirex.gif\"></p>";
	print "<p align=center><b><big>Quirex Administration Panel</big></b></p>\n";
	print "<form action=\"$script\" method=post>\n";
	print "<p align=center>\n";
	print "<b>Password:</b> <input type=password name=pass size=12> <input type=submit value=\"Login\" style=\"font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1\">\n";
	print "<input type=hidden name=action value=login>\n";
	print "</p>\n";
	print "</form>\n";
	}

function logout() {
	global $script;
	print "<p align=center><img src=\"images/quirex.gif\"></p>";
	print "<p align=center>You have successfully logged out.</p>\n";
	print "<form action=\"$script\" method=post>\n";
	print "<p align=center>\n";
	print "<b>Password:</b> <input type=password name=pass size=12> <input type=submit value=\"Login\" style=\"font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1\">\n";
	print "<input type=hidden name=action value=login>\n";
	print "</p>\n";
	print "</form>\n";
	}

function options() {
	global $script;
	print "<form action=\"$script\" name=\"option\" method=post>";
	print "<select name=action style=\"font-family: Arial; font-size: 8pt\" onChange=\"GoOption(this.value);\">";
	print "<option value=home>Home";
	print "<option>=====================";
	print "<option value=add>Add a Quiz";
	print "<option value=view>View a Quiz";
	print "<option value=edit>Edit a Quiz";
	print "<option value=remove>Remove a Quiz";
	print "<option value=config>Edit Quirex Configurations";
	print "<option value=backup>Backup / Restore Quirex";
	print "<option>=====================";
	print "<option value=logout>Logout";
	print "</select></form>";
	}

function show_panel() {
	global $script;
	
	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";
	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr><td colspan=2 valign=middle align=center>\n";

	print "<form action=\"$script\" method=\"post\">\n";
	print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
	print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
	print "<tr><td bgcolor=#587AB1 rowspan=6><img src=images/quirex.gif></td><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Add a Quiz</b></font></td><td bgcolor=#587AB1 align=right><input type=radio name=action value=add></td></tr>\n";
	print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>View a Quiz</b></font></td><td bgcolor=#587AB1 align=right><input type=radio name=action value=view></td></tr>\n";
	print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Edit a Quiz</b></font></td><td bgcolor=#587AB1 align=right><input type=radio name=action value=edit></td></tr>\n";
	print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Remove a Quiz</b></font></td><td bgcolor=#587AB1 align=right><input type=radio name=action value=remove></td></tr>\n";
	print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Edit Quirex Configurations</b></font></td><td bgcolor=#587AB1 align=right><input type=radio name=action value=config></td></tr>\n";
	print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Backup / Restore Quirex</b></font></td><td bgcolor=#587AB1 align=right><input type=radio name=action value=backup></td></tr>\n";
	print "<tr><td bgcolor=#9FBEDE colspan=3 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
	print "</table>\n";
	print "</td></tr></table>\n";
	print "</form>\n";

	print "	</td></tr>\n";
	print "</table>\n";
	}

function add() {
	global $script, $level_name_1, $level_name_2, $level_name_3, $do, $name, $desc, $level;
	
	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";
	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr height=20><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr height=269><td colspan=2 valign=middle align=center>\n";

	print "<p align=center><font face=Arial size=3><b>Add a Quiz</b></font></p>\n";

	if ($do == 'add_quiz') {
		if ($name == '') {
			print "ERROR: Quiz name missing.<br>\n";
			}
		else {
			$result = mysql_query("INSERT INTO quirex_list SET quiz_name = '".addslashes($name)."', quiz_desc = '".addslashes($desc)."', quiz_level = '$level'");
			if ($result) {
				print "Quiz \"<font face=\"Courier New\">$name</font>\" was created successfully.<br>\n";
				}
			else {
				print "Quiz \"<font face=\"Courier New\">$name</font>\" was NOT created successfully.<br>\n";
				}
			}
		}
	else {
		print "<form action=\"$script\" method=\"post\">\n";
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name:</b> <input type=text name=name size=20></font></td></tr>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Description:</b> <input type=text name=desc size=50></font></td></tr>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Level:</b> <select name=level><option value=0><option value=1>$level_name_1<option value=2>$level_name_2<option value=3>$level_name_3</select></font></td></tr>\n";
		print "<tr><td bgcolor=#9FBEDE align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		print "<input type=hidden name=action value=\"add\">\n";
		print "<input type=hidden name=do value=\"add_quiz\">\n";
		print "</form>\n";
		}
		
		print "	</td></tr>\n";
		print "</table>\n";
	}


function view() {
	global $script, $level_name_1, $level_name_2, $level_name_3, $do, $quiz;

	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";

	print "function showQuestion(ques_id) {\n";
	print "	popupWin = window.open('$script?action=view_ques&ques_id=' + ques_id , 'ques', 'scrollbars,width=400,height=250');\n";
	print "	}\n";

	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr height=20><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr height=269><td colspan=2 valign=middle align=center>\n";

	print "<p align=center><font face=Arial size=3><b>View a Quiz</b></font></p>\n";

	if ($do == 'view' && $quiz != '') {
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";

		if ($quiz == 'all') {
			$result = mysql_query("SELECT ques_id, question, no_trial, no_correct FROM quirex_ques ORDER BY ques_id");
			if (mysql_num_rows($result) > 0) {
				print "<tr>";
				print "<td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question</b></font></td>";
				print "<td bgcolor=#587AB1 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><b><nobr>Correct %</nobr></b></font></td>";
				print "</tr>\n";
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($ques_id, $question, $no_trial, $no_correct) = mysql_fetch_row($result);
					if ($no_trial == 0) $percentage = 0;
					else $percentage = round($no_correct/$no_trial*100);
					print "<tr>";
					print "<td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2>". ($i+1).". <a href=\"javascript:showQuestion($ques_id)\">$question</a></font></td>";
					print "<td bgcolor=#587AB1 align=right><font face=\"Arial\" color=\"#ffffff\" size=2>$percentage%</font></td>";
					print "</tr>\n";
					}
				}
			else {
				print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2>No Questions Yet</font></td></tr>\n";
				}
			}
		else {
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";

			$result = mysql_query("SELECT ques_id, question FROM quirex_ques WHERE quiz_id = '$quiz' ORDER BY ques_id");
			if (mysql_num_rows($result) > 0) {
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($ques_id, $question) = mysql_fetch_row($result);
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2>". ($i+1).". <a href=\"javascript:showQuestion($ques_id)\">$question</a></font></td></tr>\n";
					}
				}
			else {
				print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2>No Questions Yet</font></td></tr>\n";
				}
			}
		
		print "</table>\n";
		print "</td></tr></table>\n";
		}
	else {
		print "<form action=\"$script\" method=\"post\">\n";
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";

		print "<tr><td bgcolor=#ff0000 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>All Questions</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#ff0000 align=right><input type=radio name=quiz value=\"all\"></td></tr>\n";

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '0' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b> <i>($quiz_id)</i><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '1' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_1</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b> <i>($quiz_id)</i><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '2' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_2</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b> <i>($quiz_id)</i><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}
		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '3' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_3</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b> <i>($quiz_id)</i><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		print "<input type=hidden name=action value=\"view\">\n";
		print "<input type=hidden name=do value=\"view\">\n";
		print "</form>\n";
		}
		
	print "	</td></tr>\n";
	print "</table>\n";
	}

function edit() {
	global $script, $level_name_1, $level_name_2, $level_name_3, 
	$do, $do2, $quiz, $type, $no_ques, $name, $desc, $level, $confirm;
	global $question, $question_image, $answer, $answer_image, $explanation,
	$choices_1, $choices_2, $choices_3, $choices_4, $choices_5, $choices_6, 
	$answers_1, $answers_2, $answers_3, $answers_4, $answers_5, $answers_6;

	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";
	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr height=20><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr height=269><td colspan=2 valign=middle align=center>\n";


	if ($do == 'edit_add' && $quiz != '') {

		if ($type != '' && $do2 == 'add') {
			if ($type == 'mc') {
				$empty = 1;
				$error = 0;
				for ($i=0;$i<$no_ques;$i++) {
					if ($question[$i] != '') {
						$empty=0;
						$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);
						if (ereg("^[:space:]*$", join("", $c))) {
							print "<b>ERROR:</b> [Question ". ($i+1) . "] Choices were empty<br>\n";
							$error=1;
							}
						else {
							unset($c2);
							for ($j=0;$j<count($c);$j++) {
								if (! ereg("^[:space:]*$", $c[$j])) $c2[] = $c[$j];
								}
							if (! in_array($answer[$i], $c2)) {
								print "<b>ERROR:</b> [Question ". ($i+1) . "] Answer was not found in the choices<br>\n";
								$error=1;
								}
							}
						}
					}
				if ($empty) {
					print "<b>ERROR:</b> No Questions were entered.<br>\n";
					}
				elseif (!$error) {
					for ($i=0;$i<$no_ques;$i++) {
						if ($question[$i] != '') {
							if ($question_image[$i] == 'http://') $question_image[$i] = '';
							if ($answer_image[$i] == 'http://') $answer_image[$i] = '';
							
							$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);
							unset($c2);
							for ($j=0;$j<count($c);$j++) if (! ereg("^[:space:]*$", $c[$j])) $c2[] = $c[$j];
							$choice[$i] = join("||", $c2);
							
							$result = mysql_query(
								"INSERT INTO quirex_ques SET ".
								"quiz_id = '$quiz', ques_type = 'mc', ".
								"question = '$question[$i]', ques_img = '$question_image[$i]', ".
								"answer = '$answer[$i]', ans_img = '$answer_image[$i]', ".
								"choice = '$choice[$i]', explanation = '$explanation[$i]' ");
							
							if ($result) {
								print "Question ".($i+1)." was added successfully<br>\n";
								}
							else {
								print "Question ".($i+1)." was NOT added successfully<br>\n";
								}
							}
						}
					}
				}
			elseif ($type == 'ma') {
				$empty = 1;
				$error = 0;
				for ($i=0;$i<$no_ques;$i++) {
					if ($question[$i] != '') {
						$empty=0;
						$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);
						if (ereg("^[:space:]*$", join("", $c))) {
							print "<b>ERROR:</b> [Question ". ($i+1) . "] Choices were empty<br>\n";
							$error=1;
							}
						elseif ($answers_1[$i] == '' && $answers_2[$i] == '' &&$answers_3[$i] == '' &&$answers_4[$i] == '' &&$answers_5[$i] == '' &&$answers_6[$i] == '') {
								print "<b>ERROR:</b> [Question ". ($i+1) . "] No answers were selected.<br>\n";
								$error=1;
								}					
						else {	
							if (($answers_1[$i] && $choices_1[$i] == '') || ($answers_2[$i] && $choices_2[$i] == '') || ($answers_3[$i] && $choices_3[$i] == '') || ($answers_4[$i] && $choices_4[$i] == '') || ($answers_5[$i] && $choices_5[$i] == '') || ($answers_6[$i] && $choices_6[$i] == '')) {
								print "<b>ERROR:</b> [Question ". ($i+1) . "] An empty choice was checked.<br>\n";
								$error=1;
								}
							}
						}
					}
				if ($empty) {
					print "<b>ERROR:</b> No Questions were entered.<br>\n";
					}
				elseif (!$error) {
					for ($i=0;$i<$no_ques;$i++) {
						if ($question[$i] != '') {
							if ($question_image[$i] == 'http://') $question_image[$i] = '';
							if ($answer_image[$i] == 'http://') $answer_image[$i] = '';
							
							$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);

							unset($a);
							if ($answers_1[$i]) $a[] = $choices_1[$i];
							if ($answers_2[$i]) $a[] = $choices_2[$i];
							if ($answers_3[$i]) $a[] = $choices_3[$i];
							if ($answers_4[$i]) $a[] = $choices_4[$i];
							if ($answers_5[$i]) $a[] = $choices_5[$i];
							if ($answers_6[$i]) $a[] = $choices_6[$i];
							$answer[$i] = join("||", $a);

							unset($c2);
							for ($j=0;$j<count($c);$j++) if (! ereg("^[:space:]*$", $c[$j])) $c2[] = $c[$j];
							$choice[$i] = join("||", $c2);
							
							$result = mysql_query(
								"INSERT INTO quirex_ques SET ".
								"quiz_id = '$quiz', ques_type = 'ma', ".
								"question = '$question[$i]', ques_img = '$question_image[$i]', ".
								"answer = '$answer[$i]', ans_img = '$answer_image[$i]', ".
								"choice = '$choice[$i]', explanation = '$explanation[$i]' ");
							
							if ($result) {
								print "Question ".($i+1)." was added successfully<br>\n";
								}
							else {
								print "Question ".($i+1)." was NOT added successfully<br>\n";
								}
							}
						}
					}
				}
			elseif ($type == 'sa') {
				$empty = 1;
				$error = 0;
				for ($i=0;$i<$no_ques;$i++) {
					if ($question[$i] != '') {
						$empty=0;
						$a = array($answers_1[$i], $answers_2[$i], $answers_3[$i], $answers_4[$i], $answers_5[$i], $answers_6[$i]);
						if (ereg("^[:space:]*$", join("", $a))) {
							print "<b>ERROR:</b> [Question ". ($i+1) . "] No answers entered.<br>\n";
							$error=1;
							}
						}
					}
				if ($empty) {
					print "<b>ERROR:</b> No Questions were entered.<br>\n";
					}
				elseif (!$error) {
					for ($i=0;$i<$no_ques;$i++) {
						if ($question[$i] != '') {
							if ($question_image[$i] == 'http://') $question_image[$i] = '';
							if ($answer_image[$i] == 'http://') $answer_image[$i] = '';
							
							$a = array($answers_1[$i], $answers_2[$i], $answers_3[$i], $answers_4[$i], $answers_5[$i], $answers_6[$i]);
							unset($a2);
							for ($j=0;$j<count($a);$j++) if (! ereg("^[:space:]*$", $a[$j])) $a2[] = $a[$j];
							$answer[$i] = join("||", $a2);
						
							$result = mysql_query(
								"INSERT INTO quirex_ques SET ".
								"quiz_id = '$quiz', ques_type = 'sa', ".
								"question = '$question[$i]', ques_img = '$question_image[$i]', ".
								"answer = '$answer[$i]', ans_img = '$answer_image[$i]', ".
								"explanation = '$explanation[$i]' ");
							
							if ($result) {
								print "Question ".($i+1)." was added successfully<br>\n";
								}
							else {
								print "Question ".($i+1)." was NOT added successfully<br>\n";
								}
							}
						}
					}
				}
			elseif ($type == 'nu') {
				$empty = 1;
				$error = 0;
				for ($i=0;$i<$no_ques;$i++) {
					if ($question[$i] != '') {
						$empty=0;
						if (ereg("^[:space:]*$", $answer[$i])) {
							print "<b>ERROR:</b> [Question ". ($i+1) . "] No answer entered.<br>\n";
							$error=1;
							}
						elseif (!is_numeric($answer[$i])) {
							print "<b>ERROR:</b> [Question ". ($i+1) . "] Answer is not numeric.<br>\n";
							$error=1;
							}
						}
					}
				if ($empty) {
					print "<b>ERROR:</b> No Questions were entered.<br>\n";
					}
				elseif (!$error) {
					for ($i=0;$i<$no_ques;$i++) {
						if ($question[$i] != '') {
							if ($question_image[$i] == 'http://') $question_image[$i] = '';
							if ($answer_image[$i] == 'http://') $answer_image[$i] = '';
					
							$result = mysql_query(
								"INSERT INTO quirex_ques SET ".
								"quiz_id = '$quiz', ques_type = 'nu', ".
								"question = '$question[$i]', ques_img = '$question_image[$i]', ".
								"answer = '$answer[$i]', ans_img = '$answer_image[$i]', ".
								"explanation = '$explanation[$i]' ");
							
							if ($result) {
								print "Question ".($i+1)." was added successfully<br>\n";
								}
							else {
								print "Question ".($i+1)." was NOT added successfully<br>\n";
								}
							}
						}
					}
				}		
			elseif ($type == 'tf') {
				$empty = 1;
				$error = 0;
				for ($i=0;$i<$no_ques;$i++) {
					if ($question[$i] != '') {
						$empty=0;
						if ($answer[$i] != 't' && $answer[$i] != 'f') {
							print "<b>ERROR:</b> [Question ". ($i+1) . "] No answer chosen.<br>\n";
							$error=1;
							}
						}
					}
				if ($empty) {
					print "<b>ERROR:</b> No Questions were entered.<br>\n";
					}
				elseif (!$error) {
					for ($i=0;$i<$no_ques;$i++) {
						if ($question[$i] != '') {
							if ($question_image[$i] == 'http://') $question_image[$i] = '';
							if ($answer_image[$i] == 'http://') $answer_image[$i] = '';
					
							$result = mysql_query(
								"INSERT INTO quirex_ques SET ".
								"quiz_id = '$quiz', ques_type = 'tf', ".
								"question = '$question[$i]', ques_img = '$question_image[$i]', ".
								"answer = '$answer[$i]', ans_img = '$answer_image[$i]', ".
								"explanation = '$explanation[$i]' ");
							
							if ($result) {
								print "Question ".($i+1)." was added successfully<br>\n";
								}
							else {
								print "Question ".($i+1)." was NOT added successfully<br>\n";
								}
							}
						}
					}
				}


			print "<p align=center><font face=Arial size=3><b>Add More Questions</b></font></p>\n";

			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";
			print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question type: </b></font></td><td bgcolor=#587AB1><select name=type style=\"font-family: Arial; font-size: 10pt\"><option value=mc>Multiple Choice<option value=ma>Multiple Answer<option value=sa>Short Answer<option value=nu>Numeric Answer<option value=tf>True / False</select></td></tr>\n";
			print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Number of questions to add: </b></font></td><td bgcolor=#587AB1><select name=no_ques style=\"font-family: Arial; font-size: 10pt\"><option value=1>1<option value=2>2<option value=3 selected>3<option value=4>4<option value=5>5<option value=6>6<option value=7>7<option value=8>8<option value=9>9<option value=10>10<option value=15>15<option value=20>20</select></td></tr>\n";
			print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=do value=\"edit_add\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "</form>\n";

			}
		elseif ($type != '' && $no_ques > 0) {
			print "<p align=center><font face=Arial size=3><b>Add Questions</b></font></p>\n";

			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";

			if ($type == 'mc') {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Type: Multiple Choice</b></font></td></tr>\n";
				for ($i=0;$i<$no_ques;$i++) {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question ". ($i+1) .".</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$i]\" size=40></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1 valign=top><font face=\"Arial\" color=\"#ffffff\" size=2><b>Choices:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"choices_1[$i]\" size=20> <input type=text name=\"choices_2[$i]\" size=20><br><input type=text name=\"choices_3[$i]\" size=20> <input type=text name=\"choices_4[$i]\" size=20><br><input type=text name=\"choices_5[$i]\" size=20> <input type=text name=\"choices_6[$i]\" size=20><br></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer[$i]\" size=20></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$i]\" size=40></font></td></tr>\n";
					}
				}
			elseif ($type == 'ma') {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Type: Multiple Answer</b></font></td></tr>\n";
				for ($i=0;$i<$no_ques;$i++) {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question ". ($i+1) .".</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$i]\" size=40></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1 valign=top><font face=\"Arial\" color=\"#ffffff\" size=2><b>Choices:</b><br>(check the<br>correct answers)</font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=checkbox name=answers_1[$i] value=1><input type=text name=\"choices_1[$i]\" size=15> <input type=checkbox name=answers_2[$i] value=1><input type=text name=\"choices_2[$i]\" size=15><br><input type=checkbox name=answers_3[$i] value=1><input type=text name=\"choices_3[$i]\" size=15> <input type=checkbox name=answers_4[$i] value=1><input type=text name=\"choices_4[$i]\" size=15><br><input type=checkbox name=answers_5[$i] value=1><input type=text name=\"choices_5[$i]\" size=15> <input type=checkbox name=answers_6[$i] value=1><input type=text name=\"choices_6[$i]\" size=15><br></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$i]\" size=40></font></td></tr>\n";
					}
				}
			elseif ($type == 'sa') {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Type: Short Answer</b></font></td></tr>\n";
				for ($i=0;$i<$no_ques;$i++) {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question ". ($i+1) .".</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$i]\" size=40></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1 valign=top><font face=\"Arial\" color=\"#ffffff\" size=2><b>Acceptable Answers:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answers_1[$i]\" size=20> <input type=text name=\"answers_2[$i]\" size=20><br><input type=text name=\"answers_3[$i]\" size=20> <input type=text name=\"answers_4[$i]\" size=20><br><input type=text name=\"answers_5[$i]\" size=20> <input type=text name=\"answers_6[$i]\" size=20><br></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$i]\" size=40></font></td></tr>\n";
					}		
				}
			elseif ($type == 'nu') {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Type: Numeric Answer</b></font></td></tr>\n";
				for ($i=0;$i<$no_ques;$i++) {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question ". ($i+1) .".</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$i]\" size=40></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer[$i]\" size=20></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$i]\" size=40></font></td></tr>\n";
					}		
				}		
			elseif ($type == 'tf') {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Type: True / False</b></font></td></tr>\n";
				for ($i=0;$i<$no_ques;$i++) {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question ". ($i+1) .".</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$i]\" size=40></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=radio name=\"answer[$i]\" value=t checked>True <input type=radio name=\"answer[$i]\" value=f>False</font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$i]\" size=40 value=\"http://\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$i]\" size=40></font></td></tr>\n";
					}
				}
			print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=do value=\"edit_add\">\n";
			print "<input type=hidden name=do2 value=\"add\">\n";
			print "<input type=hidden name=type value=\"$type\">\n";
			print "<input type=hidden name=no_ques value=\"$no_ques\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "</form>\n";
			}
		else {
			print "<p align=center><font face=Arial size=3><b>Add Questions</b></font></p>\n";

			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";
			print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question type: </b></font></td><td bgcolor=#587AB1><select name=type style=\"font-family: Arial; font-size: 10pt\"><option value=mc>Multiple Choice<option value=ma>Multiple Answer<option value=sa>Short Answer<option value=nu>Numeric Answer<option value=tf>True / False</select></td></tr>\n";
			print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Number of questions to add: </b></font></td><td bgcolor=#587AB1><select name=no_ques style=\"font-family: Arial; font-size: 10pt\"><option value=1>1<option value=2>2<option value=3 selected>3<option value=4>4<option value=5>5<option value=6>6<option value=7>7<option value=8>8<option value=9>9<option value=10>10<option value=15>15<option value=20>20</select></td></tr>\n";
			print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=do value=\"edit_add\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "</form>\n";

			}
		}
	elseif ($do == 'edit_ques' && $quiz != '') {
		print "<script language=\"JavaScript\">\n";
		print "<!-- \n";
		print "function showQuestion(ques_id) {\n";
		print "	popupWin = window.open('$script?action=view_ques&ques_id=' + ques_id , 'ques', 'scrollbars,width=400,height=250');\n";
		print "	}\n";
		print "// -->\n";
		print "</script>\n";

		print "<p align=center><font face=Arial size=3><b>Edit Questions</b></font></p>\n";

		if ($do2 == 'edit') {
			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";

			$q = $question;
			reset($q);
			while(list(, $val) = each($q)) {
				list($quiz_id, $ques_type, $question, $ques_img, $choice, $answer, $ans_img, $explanation, $no_trial, $no_correct) = mysql_fetch_row(mysql_query("SELECT quiz_id, ques_type, question, ques_img, choice, answer, ans_img, explanation, no_trial, no_correct FROM quirex_ques WHERE ques_id = '$val'"));

				$question = ereg_replace("\"", "&quot;", $question);
				$ques_img = ereg_replace("\"", "&quot;", $ques_img);
				$choice = ereg_replace("\"", "&quot;", $choice);
				$answer = ereg_replace("\"", "&quot;", $answer);
				$ans_img = ereg_replace("\"", "&quot;", $ans_img);
				$explanation = ereg_replace("\"", "&quot;", $explanation);

				if ($ques_type == 'mc') {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question Type: Multiple Choice</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$val]\" size=40 value=\"$question\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$val]\" size=40 value=\"$ques_img\"></font></td></tr>\n";
					unset($c);
					$c = split("\|\|", $choice);
					print "<tr><td bgcolor=#587AB1 valign=top><font face=\"Arial\" color=\"#ffffff\" size=2><b>Choices:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"choices_1[$val]\" size=20 value=\"$c[0]\"> <input type=text name=\"choices_2[$val]\" size=20 value=\"$c[1]\"><br><input type=text name=\"choices_3[$val]\" size=20 value=\"$c[2]\"> <input type=text name=\"choices_4[$val]\" size=20 value=\"$c[3]\"><br><input type=text name=\"choices_5[$val]\" size=20 value=\"$c[4]\"> <input type=text name=\"choices_6[$val]\" size=20 value=\"$c[5]\"><br></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer[$val]\" size=20 value=\"$answer\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$val]\" size=40 value=\"$ans_img\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$val]\" size=40 value=\"$explanation\"></font></td></tr>\n";
					}
				elseif ($ques_type == 'ma') {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question Type: Multiple Answer</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$val]\" size=40 value=\"$question\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$val]\" size=40 value=\"$ques_img\"></font></td></tr>\n";
					unset($c);
					$c = split("\|\|", $choice);
					unset($a);
					$a = split("\|\|", $answer);
					print "<tr><td bgcolor=#587AB1 valign=top><font face=\"Arial\" color=\"#ffffff\" size=2><b>Choices:</b><br>(check the<br>correct answers)</font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2>";				
					if (in_array($c[0], $a)) {$checked = " checked";} else {$checked = "";}
					print "<input type=checkbox name=answers_1[$val] value=1$checked><input type=text name=\"choices_1[$val]\" size=15 value=\"$c[0]\"> ";
					if (in_array($c[1], $a)) {$checked = " checked";} else {$checked = "";}
					print "<input type=checkbox name=answers_2[$val] value=1$checked><input type=text name=\"choices_2[$val]\" size=15 value=\"$c[1]\"><br>";
					if (in_array($c[2], $a)) {$checked = " checked";} else {$checked = "";}
					print "<input type=checkbox name=answers_3[$val] value=1$checked><input type=text name=\"choices_3[$val]\" size=15 value=\"$c[2]\"> ";
					if (in_array($c[3], $a)) {$checked = " checked";} else {$checked = "";}
					print "<input type=checkbox name=answers_4[$val] value=1$checked><input type=text name=\"choices_4[$val]\" size=15 value=\"$c[3]\"><br>";
					if (in_array($c[4], $a)) {$checked = " checked";} else {$checked = "";}
					print "<input type=checkbox name=answers_5[$val] value=1$checked><input type=text name=\"choices_5[$val]\" size=15 value=\"$c[4]\"> ";
					if (in_array($c[5], $a)) {$checked = " checked";} else {$checked = "";}
					print "<input type=checkbox name=answers_6[$val] value=1$checked><input type=text name=\"choices_6[$val]\" size=15 value=\"$c[5]\"><br>";		
					print "</font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$val]\" size=40 value=\"$ans_img\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$val]\" size=40 value=\"$explanation\"></font></td></tr>\n";
					}
				elseif ($ques_type == 'sa') {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question Type: Short Answer</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$val]\" size=40 value=\"$question\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$val]\" size=40 value=\"$ques_img\"></font></td></tr>\n";
					unset($a);
					$a = split("\|\|", $answer);
					print "<tr><td bgcolor=#587AB1 valign=top><font face=\"Arial\" color=\"#ffffff\" size=2><b>Acceptable Answers:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answers_1[$val]\" size=20 value=\"$a[0]\"> <input type=text name=\"answers_2[$val]\" size=20 value=\"$a[1]\"><br><input type=text name=\"answers_3[$val]\" size=20 value=\"$a[2]\"> <input type=text name=\"answers_4[$val]\" size=20 value=\"$a[3]\"><br><input type=text name=\"answers_5[$val]\" size=20 value=\"$a[4]\"> <input type=text name=\"answers_6[$val]\" size=20 value=\"$a[5]\"><br></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$val]\" size=40 value=\"$ans_img\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$val]\" size=40 value=\"$explanation\"></font></td></tr>\n";
					}
				elseif ($ques_type == 'nu') {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question Type: Numeric Answer</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$val]\" size=40 value=\"$question\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$val]\" size=40 value=\"$ques_img\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer[$val]\" size=20 value=\"$answer\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$val]\" size=40 value=\"$ans_img\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$val]\" size=40 value=\"$explanation\"></font></td></tr>\n";
					}		
				elseif ($ques_type == 'tf') {
					print "<tr><td bgcolor=#ffeeee colspan=2><font face=\"Arial\" color=\"#587AB1\" size=2><b>Question Type: True / False</b></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question[$val]\" size=40 value=\"$question\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Question Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"question_image[$val]\" size=40 value=\"$ques_img\"></font></td></tr>\n";
					if ($answer == 't') {
						print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=radio name=\"answer[$val]\" value=t checked>True <input type=radio name=\"answer[$val]\" value=f>False</font></td></tr>\n";
					}
					else {
						print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=radio name=\"answer[$val]\" value=t>True <input type=radio name=\"answer[$val]\" value=f checked>False</font></td></tr>\n";
					}
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Answer Image:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"answer_image[$val]\" size=40 value=\"$ans_img\"></font></td></tr>\n";
					print "<tr><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><b>Explanation:</b></font></td><td bgcolor=#587AB1><font face=\"Arial\" color=\"#ffffff\" size=2><input type=text name=\"explanation[$val]\" size=40 value=\"$explanation\"></font></td></tr>\n";
					}


				}

			print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "<input type=hidden name=do value=\"edit_ques\">\n";
			print "<input type=hidden name=do2 value=\"edit_do\">\n";
			print "</form>\n";

			}
		elseif ($do2 == 'edit_do') {
			$any_error = 0;
			reset($question);
			while(list($num, ) = each($question)) {
				$i = $num;				
				list($ques_type, $original) = mysql_fetch_row(mysql_query("SELECT ques_type, question FROM quirex_ques WHERE ques_id = '$i'"));
				$error = '';
				if ($question[$i] == '') {
					$error = "Question not entered";
					}
				elseif ($ques_type == 'mc') {
					$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);
					if ($answer[$i] == '') {
						$error = "Answer not entered";
						}
					elseif (!in_array($answer[$i], $c)) {
						$error = "Answer not found in the choices";
						}
					}
				elseif ($ques_type == 'ma') {
					$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);
					$a = array($answers_1[$i], $answers_2[$i], $answers_3[$i], $answers_4[$i], $answers_5[$i], $answers_6[$i]);
					for ($j=0;$j<count($a);$j++) if ($a[$j] && $c[$j] == '') $error = "Answer checked was empty";
					$flag = 0;
					for ($j=0;$j<count($a);$j++) if ($a[$j] != '') $flag = 1;
					if (!$flag) $error = "No answers entered";
					$flag = 0;
					for ($j=0;$j<count($c);$j++) if ($c[$j] != '') $flag = 1;
					if (!$flag) $error = "No choices entered";
					}
				elseif ($ques_type == 'sa') {
					$a = array($answers_1[$i], $answers_2[$i], $answers_3[$i], $answers_4[$i], $answers_5[$i], $answers_6[$i]);
					for ($j=0;$j<count($a);$j++) if ($a[$j]) $flag = 1;
					if (!$flag) $error = "No answers entered";
					}
				elseif ($ques_type == 'nu') {
					if ($answer[$i] == '') $error = "No answer entered";
					}		
				elseif ($ques_type == 'tf') {
					if ($answer[$i] == '') $error = "No answer entered";
					}
				
				if ($error != '') {
					print "<b>ERROR:</b> Question <small>[$original]</small> $error!<br>\n";
					$any_error = 1;
					}

				}
			if (!$any_error) {
				reset($question);
				while(list($ques_id, ) = each($question)) {
					$i = $ques_id;
					list($ques_type) = mysql_fetch_row(mysql_query("SELECT ques_type FROM quirex_ques WHERE ques_id = '$i'"));
					
					if ($ques_type == 'mc') {
						$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);
						unset($c2);
						for ($j=0;$j<count($c);$j++) if (! ereg("^[:space:]*$", $c[$j])) $c2[] = $c[$j];
						$choice[$i] = join("||", $c2);
						}
					elseif ($ques_type == 'ma') {
						$c = array($choices_1[$i], $choices_2[$i], $choices_3[$i], $choices_4[$i], $choices_5[$i], $choices_6[$i]);

						unset($a);
						if ($answers_1[$i]) $a[] = $choices_1[$i];
						if ($answers_2[$i]) $a[] = $choices_2[$i];
						if ($answers_3[$i]) $a[] = $choices_3[$i];
						if ($answers_4[$i]) $a[] = $choices_4[$i];
						if ($answers_5[$i]) $a[] = $choices_5[$i];
						if ($answers_6[$i]) $a[] = $choices_6[$i];
						$answer[$i] = join("||", $a);

						unset($c2);
						for ($j=0;$j<count($c);$j++) if (! ereg("^[:space:]*$", $c[$j])) $c2[] = $c[$j];
						$choice[$i] = join("||", $c2);
						}
					elseif ($ques_type == 'sa') {
						$a = array($answers_1[$i], $answers_2[$i], $answers_3[$i], $answers_4[$i], $answers_5[$i], $answers_6[$i]);
						unset($c2);
						for ($j=0;$j<count($a);$j++) if (! ereg("^[:space:]*$", $a[$j])) $a2[] = $a[$j];
						$answer[$i] = join("||", $a2);
						$choice[$i] = '';
						}
					elseif ($ques_type == 'nu') {
						$choice[$i] = '';
						}		
					elseif ($ques_type == 'tf') {
						$choice[$i] = '';
						}
					
					mysql_query(
						"UPDATE quirex_ques SET ".
						"question = '$question[$i]', ques_img = '$question_image[$i]', ".
						"answer = '$answer[$i]', ans_img = '$answer_image[$i]', ".
						"choice = '$choice[$i]', explanation = '$explanation[$i]' ".
						"WHERE ques_id = '$ques_id'");

					}
		
				print "Questions edited successfully.<br>\n";
				}
			}
		else {
			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";

			$result = mysql_query("SELECT ques_id, question FROM quirex_ques WHERE quiz_id = '$quiz' ORDER BY ques_id");
			if (mysql_num_rows($result) > 0) {
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($ques_id, $question) = mysql_fetch_row($result);
					print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>". ($i+1).". <a href=\"javascript:showQuestion($ques_id)\">$question</a></font></td><td bgcolor=#587AB1 valign=top><input type=checkbox name=\"question[$i]\" value=\"$ques_id\"></td></tr>\n";
					}
				}
			else {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2>No Questions In Quiz</font></td></tr>\n";
				}
			print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "<input type=hidden name=do value=\"edit_ques\">\n";
			print "<input type=hidden name=do2 value=\"edit\">\n";
			print "</form>\n";
			}
		}	
	elseif ($do == 'edit_remove' && $quiz != '') {
		print "<script language=\"JavaScript\">\n";
		print "<!-- \n";
		print "function showQuestion(ques_id) {\n";
		print "	popupWin = window.open('$script?action=view_ques&ques_id=' + ques_id , 'ques', 'scrollbars,width=400,height=250');\n";
		print "	}\n";
		print "// -->\n";
		print "</script>\n";

		print "<p align=center><font face=Arial size=3><b>Remove Questions</b></font></p>\n";

		if ($do2 == 'remove' && $confirm) {
			reset($question);
			while(list(, $val) = each($question)) {
				list($ques) = mysql_fetch_row(mysql_query("SELECT question FROM quirex_ques WHERE ques_id = '$val'"));
				mysql_query("DELETE FROM quirex_ques WHERE ques_id = '$val'");
				print "\"$ques\" deleted.<br>\n";
				}
			}
		else {
			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name: $quiz_name</b></font></td></tr>\n";

			$result = mysql_query("SELECT ques_id, question FROM quirex_ques WHERE quiz_id = '$quiz' ORDER BY ques_id");
			if (mysql_num_rows($result) > 0) {
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($ques_id, $question) = mysql_fetch_row($result);
					print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>". ($i+1).". <a href=\"javascript:showQuestion($ques_id)\">$question</a></font></td><td bgcolor=#587AB1 valign=top><input type=checkbox name=\"question[$i]\" value=\"$ques_id\"></td></tr>\n";
					}
				}
			else {
				print "<tr><td bgcolor=#587AB1 colspan=2><font face=\"Arial\" color=\"#ffffff\" size=2>No Questions In Quiz</font></td></tr>\n";
				}
			print "<tr><td bgcolor=#587AB1 colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2>Are you sure? <input type=checkbox name=confirm value=1></font></td></tr>\n";
			print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "<input type=hidden name=do value=\"edit_remove\">\n";
			print "<input type=hidden name=do2 value=\"remove\">\n";
			print "</form>\n";
			}
		}
	elseif ($do == 'edit_quiz_info' && $quiz != '') {
		print "<p align=center><font face=Arial size=3><b>Edit Quiz Info</b></font></p>\n";

		list($quiz_name, $quiz_desc, $quiz_level) = mysql_fetch_row(mysql_query("SELECT quiz_name, quiz_desc, quiz_level FROM quirex_list WHERE quiz_id = '$quiz'"));

		if ($do2 == 'edit') {
			$result = mysql_query("UPDATE quirex_list SET quiz_name = '$name', quiz_desc = '$desc', quiz_level = '$level' WHERE quiz_id = '$quiz'");
			if ($result) {
				print "\"<font face=\"Courier New\">$quiz_name</font>\" was updated successfully.<br>\n";
				}
			else {
				print "<b>ERROR:</b> \"<font face=\"Courier New\">$quiz_name</font>\" was NOT updated successfully.<br>\n";
				}
			}
		else {
			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Name:</b> <input type=text name=name size=20 value=\"$quiz_name\"></font></td></tr>\n";
			print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Description:</b> <input type=text name=desc size=50 value=\"$quiz_desc\"></font></td></tr>\n";
			print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>Quiz Level:</b> <select name=level>";
			print $quiz_level == 0 ? "<option value=0 selected>" : "<option value=0>";
			print $quiz_level == 1 ? "<option value=1 selected>$level_name_1" : "<option value=1>$level_name_1";
			print $quiz_level == 2 ? "<option value=2 selected>$level_name_2" : "<option value=2>$level_name_2";
			print $quiz_level == 3 ? "<option value=3 selected>$level_name_3" : "<option value=3>$level_name_3";
			print "</select></font></td></tr>\n";
			print "<tr><td bgcolor=#9FBEDE align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			print "<input type=hidden name=action value=\"edit\">\n";
			print "<input type=hidden name=quiz value=\"$quiz\">\n";
			print "<input type=hidden name=do value=\"edit_quiz_info\">\n";
			print "<input type=hidden name=do2 value=\"edit\">\n";
			print "</form>\n";
			}
		}		
	else {
		print "<p align=center><font face=Arial size=3><b>Edit a Quiz</b></font></p>\n";

		print "<form action=\"$script\" method=\"post\">\n";
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '0' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '1' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_1</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '2' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_2</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}
		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '3' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_3</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><b>Action:</b> <select name=do style=\"font-family: Arial; font-size: 10pt\"><option value=edit_add>Add Questions<option value=edit_ques>Edit Questions<option value=edit_remove>Remove Questions<option value=edit_quiz_info>Edit Quiz Information</select></font></td></tr>\n";
		print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		print "<input type=hidden name=action value=\"edit\">\n";
		print "</form>\n";
		}
		
		print "	</td></tr>\n";
		print "</table>\n";
	}

function remove() {
	global $script, $level_name_1, $level_name_2, $level_name_3, $do, $quiz, $confirm;

	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";
	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr height=20><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr height=269><td colspan=2 valign=middle align=center>\n";

	print "<p align=center><font face=Arial size=3><b>Remove a Quiz</b></font></p>\n";

	if ($do == 'remove' && $quiz != '' && confirm) {
		$error = 0;
		list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
		if (! mysql_query("DELETE FROM quirex_list WHERE quiz_id = '$quiz'")) $error=1;
		if (! mysql_query("DELETE FROM quirex_ques WHERE quiz_id = '$quiz'")) $error=1;
		if (! mysql_query("DELETE FROM quirex_record WHERE quiz_id = '$quiz'")) $error=1;
		
		if ($error) {
			print "<b>ERROR:</b> \"<font face=\"Courier New\">$quiz_name</font>\" was NOT removed successfully.<br>\n";
			}
		else {
			print "\"<font face=\"Courier New\">$quiz_name</font>\" was removed successfully.<br>\n";
			}
		}
	else {
		print "<form action=\"$script\" method=\"post\">\n";
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '0' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '1' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_1</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '2' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_2</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}
		$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '3' ORDER BY quiz_name");
		if (mysql_num_rows($result) > 0) {
			print "<tr><td bgcolor=#9FBEDE colspan=2><font face=\"Arial\" color=\"#ffffff\" size=3><b><i>$level_name_3</i></b></font></td></tr>\n";
			for ($i=0;$i<mysql_num_rows($result);$i++) {
				list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
				print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td><td bgcolor=#587AB1 align=right><input type=radio name=quiz value=\"$quiz_id\"></td></tr>\n";
				}
			}

		print "<tr><td bgcolor=#587AB1 colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2>Are you sure? <input type=checkbox name=confirm value=1></font></td></tr>\n";
		print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		print "<input type=hidden name=action value=\"remove\">\n";
		print "<input type=hidden name=do value=\"remove\">\n";
		print "</form>\n";
		}
		
	print "	</td></tr>\n";
	print "</table>\n";
	}

function config() {	
	global $script, $do, $do2;
	global $anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top;
	global $new_anticheat, $new_require_info, $new_show_record, $new_show_answer, $new_show_copyright, $new_use_table, $new_randomize_ans, $new_allow_empty_ans, $old_admin_password, $new_admin_password, $new_admin_password2, $new_admin_email, $new_email_admin, $new_email_taker, $new_header, $new_footer, $new_url_site, $new_url_tick, $new_url_cross, $new_font_face, $new_font_color, $new_table_border_color, $new_table_color_1, $new_table_color_2, $new_level_name_1, $new_level_name_2, $new_level_name_3, $new_no_options, $new_no_recent, $new_no_top;

	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";
	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr height=20><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr height=269><td colspan=2 valign=middle><font face=Arial size=2>\n";

	print "<p align=center><font face=Arial size=3><b>Configurations</b></font></p>\n";

	if ($do == 'password') {
		print "<center>\n";
		if ($do2 == 'password') {
			if ($old_admin_password != $admin_password) {
				print "Old password entered was incorrect!";
				}
			elseif ($new_admin_password != $new_admin_password2) {
				print "Two passwords entered did not match!";
				}
			else {
				print "Password changed successfully!";
				}
			}
		else {
			print "<form action=\"$script\" method=\"post\">\n";
			print "<table border=0>\n";
			print "<tr><td><font face=Arial size=2><b>Old Password:</b></font></td><td><input type=password name=old_admin_password maxlength=12 size=12></td></tr>\n";
			print "<tr><td><font face=Arial size=2><b>New Password:</b></font></td><td><input type=password name=new_admin_password maxlength=12 size=12></td></tr>\n";
			print "<tr><td><font face=Arial size=2><b>Re-type Password:</b></font></td><td><input type=password name=new_admin_password2 maxlength=12 size=12></td></tr>\n";
			print "</table>\n";
			print "<input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\">\n";
			print "<input type=hidden name=action value=config>\n";
			print "<input type=hidden name=do value=password>\n";
			print "<input type=hidden name=do2 value=password>\n";
			print "</form>\n";
			}
		print "</center>\n";
		}
	elseif ($do == 'options') {
		if ($do2 == 'options') {
			print "<center>\n";
			$result = mysql_query("UPDATE quirex_config SET anticheat = '$new_anticheat', require_info = '$new_require_info', show_record = '$new_show_record', show_answer = '$new_show_answer', show_copyright = '$new_show_copyright', use_table = '$new_use_table', randomize_ans = '$new_randomize_ans', allow_empty_ans = '$new_allow_empty_ans', admin_email = '$new_admin_email', email_admin = '$new_email_admin', email_taker = '$new_email_taker', url_site = '$new_url_site', url_tick = '$new_url_tick', url_cross = '$new_url_cross', font_face = '$new_font_face', font_color = '$new_font_color', table_border_color = '$new_table_border_color', table_color_1 = '$new_table_color_1', table_color_2 = '$new_table_color_2', level_name_1 = '$new_level_name_1', level_name_2 = '$new_level_name_2', level_name_3 = '$new_level_name_3', no_options = '$new_no_options', no_recent = '$new_no_recent', no_top = '$new_no_top'");
			if ($result) {
				print "Options were updated successfully!";
				}
			else {
				print "Options were NOT updated successfully!<br>\n";
				print mysql_error();
				}
			print "</center>\n";
			}
		else {
			print "<form action=$script method=post>\n";

			print "<p align=left>\n";
			print "<fieldset style='margin:5px'><legend>Administration information</legend>\n";
			print "Email address:<br>\n";
			print "<input type=text name=new_admin_email size=40 value='$admin_email'><br><br>\n";
			print "</fieldset>\n";
			
			print "<fieldset style='margin:5px'><legend>URLs...</legend>\n";
			print "Your site's URL:<br>\n";
			print "<input type=text name=new_url_site size=40 value='$url_site'><br><br>\n";
			print "The 'tick' image's URL:<br>\n";
			print "<input type=text name=new_url_tick size=40 value='$url_tick'><br><br>\n";
			print "The 'cross' image's URL:<br>\n";
			print "<input type=text name=new_url_cross size=40 value='$url_cross'><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Font and Color</legend>\n";
			print "Font face: \n";
			print "<input type=text name=new_font_face size=20 value='$font_face'><br><br>\n";
			print "Font color: \n";
			print "<input type=text name=new_font_color size=20 value='$font_color'><br><br>\n";
			print "Table border color: \n";
			print "<input type=text name=new_table_border_color size=20 value='$table_border_color'><br><br>\n";
			print "Table color 1: \n";
			print "<input type=text name=new_table_color_1 size=20 value='$table_color_1'><br><br>\n";
			print "Table color 2: \n";
			print "<input type=text name=new_table_color_2 size=20 value='$table_color_2'><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Level names</legend>\n";
			print "1. \n";
			print "<input type=text name=new_level_name_1 size=20 value='$level_name_1'><br><br>\n";
			print "2. \n";
			print "<input type=text name=new_level_name_2 size=20 value='$level_name_2'><br><br>\n";
			print "3. \n";
			print "<input type=text name=new_level_name_3 size=20 value='$level_name_3'><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Others</legend>\n";
			print "Options for 'Number of Questions to Take' <font size=1>(options are separated by commas)</font>.<br>\n";
			print "<input type=text name=new_no_options size=20 value='$no_options'><br><br>\n";
			print "Number of Recent Records Shown: \n";
			print "<input type=text name=new_no_recent size=3 maxlength=3 value='$no_recent'><br><br>\n";
			print "Number of Top Records Shown: \n";
			print "<input type=text name=new_no_top size=3 maxlength=3 value='$no_top'><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Preferences</legend>\n";
			print "Do you wish to turn on the anti-cheat function?<br>\n";
			print "<input type=text name=new_anticheat size=5 value='$anticheat'> (enter '1' to disallow takers from taking the same quiz within 1 hour, '24' to disallow takers from taking the same quiz within 24 hours, and so on. Or enter '0' to disable the function.)<br><br>\n";
			print "Do you require quiz takers to enter their names and emails?<br>\n";
			print "<input type=radio name=new_require_info value=1".($require_info == "1" ? " checked" : "").">Yes <input type=radio name=new_require_info value=0".($require_info == "0" ? " checked" : "").">No<br><br>\n";
			print "Do you want to make the takers' (top and recent) records to be shown to all visitors?<br>\n";
			print "<input type=radio name=new_show_record value=1".($show_record == "1" ? " checked" : "").">Yes <input type=radio name=new_show_record value=0".($show_record == "0" ? " checked" : "").">No<br><br>\n";
			print "Do you want to show answers to quiz takers after they have submitted the form?<br>\n";
			print "<input type=radio name=new_show_answer value=1".($show_answer == "1" ? " checked" : "").">Yes <input type=radio name=new_show_answer value=0".($show_answer == "0" ? " checked" : "").">No<br><br>\n";
			print "Do you want to show the Quirex' name and link?<br>\n";
			print "<input type=radio name=new_show_copyright value=1".($show_copyright == "1" ? " checked" : "").">Yes <input type=radio name=new_show_copyright value=0".($show_copyright == "0" ? " checked" : "").">No<br><br>\n";
			print "Do you want Quirex to use table for formatting the questions?<br>\n";
			print "<input type=radio name=new_use_table value=1".($use_table == "1" ? " checked" : "").">Yes <input type=radio name=new_use_table value=0".($use_table == "0" ? " checked" : "").">No<br><br>\n";
			print "Do you want to randomize the positions of answers of Multiple Choice and Multiple Answer questions also?<br>\n";
			print "<input type=radio name=new_randomize_ans value=1".($randomize_ans == "1" ? " checked" : "").">Yes <input type=radio name=new_randomize_ans value=0".($randomize_ans == "0" ? " checked" : "").">No<br><br>\n";
			print "Do you want to allow quiz takers to proceed to the answer checking section even if they have left some questions unanswered?<br>\n";
			print "<input type=radio name=new_allow_empty_ans value=1".($empty_ans == "1" ? " checked" : "").">Yes <input type=radio name=new_allow_empty_ans value=0".($empty_ans == "0" ? " checked" : "")." checked>No<br><br>\n";
			print "Do you want Quirex to email you when someone takes a quiz?<br>\n";
			print "<input type=radio name=new_email_admin value=1".($email_admin == "1" ? " checked" : "").">Yes <input type=radio name=new_email_admin value=0".($email_admin == "0" ? " checked" : "")." checked>No<br><br>\n";
			print "Do you want Quirex to email the quiz taker after he takes a quiz?<br>\n";
			print "<input type=radio name=new_email_taker value=1".($email_taker == "1" ? " checked" : "").">Yes <input type=radio name=new_email_taker value=0".($email_taker == "0" ? " checked" : "")." checked>No<br><br>\n";
			print "</fieldset>\n";
			print "</p>\n";

			print "<p align=center>\n";
			print "<input type=submit value='Do it!' style='font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1'>\n";
			print "<input type=hidden name=action value=config>\n";
			print "<input type=hidden name=do value=options>\n";
			print "<input type=hidden name=do2 value=options>\n";
			print "</p>\n";
			print "</form>\n";
			}
		}
	elseif ($do == 'template') {
		print "<center>\n";
		if ($do2 == 'template') {
			$result = mysql_query("UPDATE quirex_config SET header = '$new_header', footer = '$new_footer'");
			if ($result) {
				print "Header and Footer have been updated successfully";
				}
			else {
				print "Header and Footer have NOT been updated successfully<br>\n";
				print mysql_error();
				}
			}
		else {
			list($header, $footer) = mysql_fetch_row(mysql_query("SELECT header, footer FROM quirex_config"));
			print "<form action=\"$script\" method=\"post\">\n";
			print "<b>Header</b><br>\n";
			print "<textarea name=new_header cols=50 rows=10 wrap=off>$header</textarea><br><br>\n";
			print "<b>Footer</b><br>\n";
			print "<textarea name=new_footer cols=50 rows=10 wrap=off>$footer</textarea><br><br>\n";
			print "<input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\">\n";
			print "<input type=hidden name=action value=config>\n";
			print "<input type=hidden name=do value=template>\n";
			print "<input type=hidden name=do2 value=template>\n";
			print "</form>\n";
			}
		print "</center>\n";
		}
	else {
		print "<center>\n";
		print "<form action=\"$script\" method=\"post\">\n";
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>Change Admin Password</font></td><td bgcolor=#587AB1 align=right><input type=radio name=do value=password></td></tr>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>Change Options</font></td><td bgcolor=#587AB1 align=right><input type=radio name=do value=options></td></tr>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>Edit Header & Footer</font></td><td bgcolor=#587AB1 align=right><input type=radio name=do value=template></td></tr>\n";
		print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		print "<input type=hidden name=action value=config>\n";
		print "</form>\n";
		print "</center>\n";
		}
	
	print "	</font></td></tr>\n";
	print "</table>\n";	
	}

function backup() {
	global $script, $do, $confirm;
	$quirex_bak = 'data/quirex.sql';

	print "<script language=\"JavaScript\">\n";
	print "<!-- \n";
	print "function GoOption(action) {\n";
	print "	if (action != '') {\n";
	print "		document.option.submit();\n";
	print "		}\n";
	print "	}\n";
	print "\n";
	print "// -->\n";
	print "</script>\n";
	print "<table border=0 cellspacing=0 cellpadding=0 width=100% height=289>\n";
	print "	<tr height=20><td valign=top><font face=arial><b>Quirex Administration Panel</b></font></td><td valign=top align=right>";
	options();
	print "</td></tr>\n";
	print "	<tr height=269><td colspan=2 align=center valign=middle><font face=Arial size=2>\n";

	print "<p align=center><font face=Arial size=3><b>Backup / Restore Quirex</b></font></p>\n";

	if ($do == 'backup' && $confirm) {
		if ($file = fopen("$quirex_bak", 'w')) {
			$result = mysql_query("SELECT * FROM quirex_config");
			if (mysql_num_rows($result) > 0) {
				fputs($file, "INSERT INTO quirex_config (anticheat, require_info, show_record, show_answer, show_copyright, use_table, randomize_ans, allow_empty_ans, admin_password, admin_email, email_admin, email_taker, header, footer, url_site, url_tick, url_cross, font_face, font_color, table_border_color, table_color_1, table_color_2, level_name_1, level_name_2, level_name_3, no_options, no_recent, no_top) VALUES \n");
				unset($string);
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top) = mysql_fetch_row($result);
					$string[$i] = "('$anticheat', '$require_info', '$show_record', '$show_answer', '$show_copyright', '$use_table', '$randomize_ans', '$allow_empty_ans', '".addslashes($admin_password)."', '".addslashes($admin_email)."', '".addslashes($email_admin)."', '".addslashes($email_taker)."', '".addslashes($header)."', '".addslashes($footer)."', '".addslashes($url_site)."', '".addslashes($url_tick)."', '".addslashes($url_cross)."', '".addslashes($font_face)."', '".addslashes($font_color)."', '".addslashes($table_border_color)."', '".addslashes($table_color_1)."', '".addslashes($table_color_2)."', '".addslashes($level_name_1)."', '".addslashes($level_name_2)."', '".addslashes($level_name_3)."', '".addslashes($no_options)."', '".addslashes($no_recent)."', '".addslashes($no_top)."')";
					}
				fputs($file, join(", \n", $string).";\n// QUERY SEPARATOR\n");
				}

			unset($string);
			$result = mysql_query("SELECT * FROM quirex_list");
			if (mysql_num_rows($result) > 0) {
				fputs($file, "INSERT INTO quirex_list (quiz_id, quiz_name, quiz_desc, quiz_level) VALUES \n");
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($quiz_id, $quiz_name, $quiz_desc, $quiz_level) = mysql_fetch_row($result);
					$string[$i] = "('".addslashes($quiz_id)."', '".addslashes($quiz_name)."', '".addslashes($quiz_desc)."', '".addslashes($quiz_level)."')";
					}
				fputs($file, join(", \n", $string).";\n// QUERY SEPARATOR\n");
				}

			unset($string);
			$result = mysql_query("SELECT * FROM quirex_ques");
			if (mysql_num_rows($result) > 0) {
				fputs($file, "INSERT INTO quirex_ques (quiz_id, ques_id, ques_type, question, ques_img, choice, answer, ans_img, explanation, no_trial, no_correct) VALUES \n");
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($quiz_id, $ques_id, $ques_type, $question, $ques_img, $choice, $answer, $ans_img, $explanation, $no_trial, $no_correct) = mysql_fetch_row($result);
					$string[$i] = "('".addslashes($quiz_id)."', '".addslashes($ques_id)."', '".addslashes($ques_type)."', '".addslashes($question)."', '".addslashes($ques_img)."', '".addslashes($choice)."', '".addslashes($answer)."', '".addslashes($ans_img)."', '".addslashes($explanation)."', '".addslashes($no_trial)."', '".addslashes($no_correct)."')";
					}
				fputs($file, join(", \n", $string).";\n// QUERY SEPARATOR\n");
				}

			unset($string);
			$result = mysql_query("SELECT * FROM quirex_record");
			if (mysql_num_rows($result) > 0) {
				fputs($file, "INSERT INTO quirex_record (quiz_id, taker_name, taker_email, show_record, no_total, no_correct, time_begin, time_finish, ip) VALUES \n");
				for ($i=0;$i<mysql_num_rows($result);$i++) {
					list($quiz_id, $taker_name, $taker_email, $show_record, $no_total, $no_correct, $time_begin, $time_finish, $ip) = mysql_fetch_row($result);
					$string[$i] = "('$quiz_id', '".addslashes($taker_name)."', '".addslashes($taker_email)."', '$show_record', '$no_total', '$no_correct', '$time_begin', '$time_finish', '$ip')";
					}
				fputs($file, join(", \n", $string).";\n// QUERY SEPARATOR\n");
				}

			fclose($file);
			print "Quirex backup was created successfully.";
			}
		else {
			print "Quirex backup was NOT created successfully.";
			}
		}
	elseif ($do == 'restore' && $confirm) {

		if (! file_exists("$quirex_bak")) {
			print "Quirex backup file (quirex.sql) was not found.<br>\n";
			}
		else {
			$file = split(";\n// QUERY SEPARATOR\n", join("", file("$quirex_bak")));
			array_pop($file);

			$result = mysql_query("DELETE FROM quirex_config");
			if (!$result) {print "DELETE FROM quirex_config FAILED<br>\n";};
			$result = mysql_query("DELETE FROM quirex_list");
			if (!$result) {print "DELETE FROM quirex_list FAILED<br>\n";};
			$result = mysql_query("DELETE FROM quirex_ques");
			if (!$result) {print "DELETE FROM quirex_ques FAILED<br>\n";};
			$result = mysql_query("DELETE FROM quirex_record");
			if (!$result) {print "DELETE FROM quirex_record FAILED<br>\n";};

			$flag = 1;
			for ($i=0;$i<count($file);$i++) {
				$result = mysql_query("$file[$i]");
				if (!$result) {$flag = 0;}
				}

			if ($flag) {
				print "Quirex was restored successfully.";
				}
			else {
				print "Quirex was NOT restored successfully.";
				print mysql_error();
				}

			}
		}
	else {

		print "<form action=\"$script\" method=\"post\">\n";
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=#ffffff width=500 align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>Backup Quirex</font></td><td bgcolor=#587AB1 align=right><input type=radio name=do value=backup></td></tr>\n";
		print "<tr><td bgcolor=#587AB1 width=100%><font face=\"Arial\" color=\"#ffffff\" size=2>Restore Quirex</font></td><td bgcolor=#587AB1 align=right><input type=radio name=do value=restore></td></tr>\n";
		print "<tr><td bgcolor=#587AB1 colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2>Are you sure? <input type=checkbox name=confirm value=1></font></td></tr>\n";
		print "<tr><td bgcolor=#9FBEDE colspan=2 align=center><font face=\"Arial\" color=\"#ffffff\" size=2><input type=submit value=\"Do it!\" style=\"background-color: #9FBEDE; font-family: Arial\"></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		print "<input type=hidden name=action value=backup>\n";
		print "</form>\n";

		}
	
	print "	</font></td></tr>\n";
	print "</table>\n";
	}

function view_ques() {
	global $ques_id;
	
	list($quiz_id, $ques_type, $question, $ques_img, $choice, $answer, $ans_img, $explanation, $no_trial, $no_correct) = mysql_fetch_row(mysql_query("SELECT quiz_id, ques_type, question, ques_img, choice, answer, ans_img, explanation, no_trial, no_correct FROM quirex_ques WHERE ques_id = '$ques_id'"));

	print "<head>\n";
	print "<title>Quirex Administration Panel</title>\n";
	print "</head>\n";
	print "<style>\n";
	print "<!--\n";
	print "a {text-decoration : none}\n";
	print "a:hover {text-decoration : underline; color: ddddff}\n";
	print "// -->\n";
	print "</style>\n";
	print "<body bgcolor=\"#587AB1\" text=\"#ffffff\" link=\"#ffffff\" vlink=\"ffdddd\">\n";
	print "<font color=\"#ffffff\" face=Arial size=2>\n";

	print "<table border=0 cellspacing=0 width=100%>\n";
	
	print "<tr><td colspan=2><b><font face=Arial size=3>$question</font></b></td></tr>\n";

	print "<tr><td valign=top><b><font face=Arial size=2>In Quiz:</font></b></td><td valign=top><font face=Arial size=2>";
	list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz_id'"));
	print $quiz_name;
	print "</font></td></tr>\n";

	print "<tr><td valign=top><b><font face=Arial size=2>Question type:</font></b></td><td valign=top><font face=Arial size=2>";
	if ($ques_type=='mc') print 'Multiple Choice';
	if ($ques_type=='ma') print 'Multiple Answer';
	if ($ques_type=='sa') print 'Short Answer';
	if ($ques_type=='nu') print 'Numeric Answer';
	if ($ques_type=='tf') print 'True / False';
	print "</font></td></tr>\n";

	print "<tr><td valign=top><b><font face=Arial size=2>Question Image:</font></b></td><td valign=top><font face=Arial size=2>";
	if ($ques_image) {
		print "$ques_image";
		}
	else {
		print "None";
		}
	print "</font></td></tr>\n";
		
	if ($ques_type=='mc' || $ques_type=='ma') {
		print "<tr><td valign=top><b><font face=Arial size=2>Choices:</font></b></td><td valign=top><font face=Arial size=2>";
		print join(", ", split("\|\|", $choice));
		print "</font></td></tr>\n";
		}

	print "<tr><td valign=top><b><font face=Arial size=2>Answer:</font></b></td><td valign=top><font face=Arial size=2>";
	if ($ques_type=='tf') {
		if ($answer == 't') print 'True';
		if ($answer == 'f') print 'False';
		}
	else {
		print join(", ", split("\|\|", $answer));
		}
	print "</font></td></tr>\n";

	print "<tr><td valign=top><b><font face=Arial size=2>Answer Image:</font></b></td><td valign=top><font face=Arial size=2>";
	if ($ans_image) {
		print "$ans_image";
		}
	else {
		print "None";
		}
	print "</font></td></tr>\n";
	
	print "<tr><td valign=top><b><font face=Arial size=2>Explanation:</font></b></td><td valign=top><font face=Arial size=2>";
	if ($explanation) {
		print "$explanation";
		}
	else {
		print "None";
		}
	print "</font></td></tr>\n";

	print "<tr><td valign=top><b><font face=Arial size=2>Number of Trials:</font></b></td><td valign=top><font face=Arial size=2>$no_trial</font></td></tr>\n";
	print "<tr><td valign=top><b><font face=Arial size=2>Number of Correct Trials:</font></b></td><td valign=top><font face=Arial size=2>$no_correct</font></td></tr>\n";

	print "</table>\n";
	
	print "</font>\n";
	print "	</body>\n";
	print "	</html>\n";
	}

?>