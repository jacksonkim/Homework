<?
#######################################################################
#                       Quirex PHP Conversion Tool                    #
#            By Thomas Tsoi <admin@tecaeb.com> 2001-10-05             #
#     Copyright 2001 (c) Teca-scripts.com.  All rights reserved.      #
#######################################################################
#                                                                     #
# CGIHK.com:                                                          #
#   http://www.teca-scripts.com/                                      #
# F.A.Q.:                                                             #
#   http://www.teca-scripts.com/faq/                                  #
# ThomasTsoi.com                                                      #
#   http://www.ThomasTsoi.com/                                        #
# Winapi.com                                                          #
#   http://www.winapi.com/                                            #
# Astronomy.org.hk                                                    #
#   http://www.astronomy.org.hk/                                      #
#                                                                     #
# ################################################################### #
#                                                                     #
#        This is a commercial product and CANNOT be distributed       #
#                  without the author's authorization.                #
#                                                                     #
#######################################################################


require("config.php");

if (! mysql_connect($host, $username, $password)) {
	print "MySQL Error: " . mysql_error();
	exit;
	}
mysql_select_db($database);
$result = mysql_query(
"SELECT anticheat, require_info, show_record, show_answer, show_copyright, " . 
"use_table, randomize_ans, allow_empty_ans, " . 
"admin_password, admin_email, email_admin, email_taker, header, footer, ".
"url_site, url_tick, url_cross, font_face, font_color, table_border_color, ".
"table_color_1, table_color_2, level_name_1, level_name_2, level_name_3, ".
"no_options, no_recent, no_top FROM quirex_config");
if ($result) {
	list($anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top) = mysql_fetch_row($result);
	}
else {
	print "MySQL Error: " . mysql_error();
	exit;
	}
$script = "convert.php";

printheader();
print "<p align=center><font size=4><b>Quirex Conversion Tool</b></font></p>\n";

if ($action == 'select') {
	if ($file = @file("$dbpath/quirex.lst")) {
		print "<form action=$script method=POST>\n";
		print "<select name=\"quiz[]\" multiple size=6 style=\"font-family: Arial; font-size: 10pt\">";
		for ($i=0;$i<count($file);$i++) {
			list($quiz, $name) = split("\|\|", $file[$i]);
			print "<option value=\"$quiz\">$name ($quiz)";
			}
		print "</select>\n";
		print "Select all the quizzes which you would like to convert";
		
		print "<input type=hidden name=action value=convert><br>\n";
		print "<input type=hidden name=dbpath value=\"$dbpath\"><br>\n";
		print "<input type=submit value=Submit style=\"font-family: Arial; font-size: 10pt\"><br>\n";
		print "</form>\n";	
		}
	else {
		print "DB path incorrect. Unable to open $dbpath/quirex.lst";
		}
	}
elseif ($action == 'convert') {
	
	if (!count($quiz)) {
		print "ERROR: no quizzes selected";
		}
	else {
		for ($i=0;$i<count($quiz);$i++) {
		
			$list = file("$dbpath/quirex.lst");
			for ($j=0;$j<count($list);$j++) {
				list($dbname, $name, $desc, $level) = split("\|\|", chop($list[$j]));
				if ($dbname == $quiz[$i]) break;
				}

			$result = mysql_query("INSERT INTO quirex_list SET quiz_name = '$name', quiz_desc = '$desc', quiz_level = '$level'");
			$quiz_id = mysql_insert_id();
			
			$db = file("$dbpath/$quiz[$i].db");
			
			for ($j=0;$j<count($db);$j++) {
				list($qtype, $question, $qimage, $answer, $aimage, $explanation, $choice) = split("\|\|", chop($db[$j]));
				if ($qimage && !eregi("^http://", $qimage)) $qimage = "http://$qimage";
				if ($aimage && !eregi("^http://", $aimage)) $aimage = "http://$aimage";
				if ($qtype == 'mc') $choice = eregi_replace("``", "||", $choice);

				$query  = "INSERT INTO quirex_ques SET ";
				$query .= "quiz_id  = '$quiz_id', ques_type   = '$qtype' , question = '$question', ";
				$query .= "ques_img = '$qimage' , choice      = '$choice', answer   = '$answer', ";
				$query .= "ans_img  = '$aimage' , explanation = '$explanation'";
	
				mysql_query($query);
				}
			
			$rec = file("$dbpath/$quiz[$i].rec");
			for ($j=0;$j<count($rec);$j++) {
				list($taker_name, $email, $hide, $total, $correct, $time) = split("\|\|", chop($rec[$j]));
				if ($hide == "on") $show = "0";
				if ($hide == "off") $show = "1";
				
				
				$query  = "INSERT INTO quirex_record SET ";
				$query .= "quiz_id  = '$quiz_id', taker_name  = '$taker_name' , taker_email = '$email', ";
				$query .= "show_record = '$show' , no_total   = '$total', no_correct  = '$correct', ";
				$query .= "time_finish  = '$time' , time_begin = '0'";
	
				mysql_query($query);
				}	
			
			print "\"$name ($dbname)\" was converted successfully<br>\n";
		
			}
		}
	}
else {
	print "<p align=center>This utility converts the Quirex v2.x database to Quirex PHP's MySQL database.</p>\n";
	print "<form action=$script method=POST>\n";
	print "Path to Quirex v2.x DB directory:<br>\n";
	print "<input type=text name=dbpath size=40 style=\"font-family: Arial; font-size: 10pt\"><br>\n";
	print "<input type=hidden name=action value=select style=\"font-family: Arial; font-size: 10pt\"><br>\n";
	print "<input type=submit value=Submit><br>\n";
	print "</form>\n";
	}
printfooter();



function printheader() {
	print "<html>\n";
	print "<head>\n";
	print "<title>Quirex Conversion Tool</title>\n";
	print "</head>\n";
	print "<style>\n";
	print "<!--\n";
	print "a {text-decoration : none}\n";
	print "a:hover {text-decoration : underline; color: ddddff}\n";
	print "// -->\n";
	print "</style>\n";
	print "<body bgcolor=\"#587AB1\" text=\"#ffffff\" link=\"#ffffff\" vlink=\"ffdddd\">\n";
	print "<table width=\"550\" height=400 border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=center>\n";
	print "<tr><td colspan=\"3\" width=\"550\" height=\"60\"><img src=\"images/panel_01.gif\" width=\"550\" height=\"60\"></td></tr>\n";
	print "<tr>\n";
	print "	<td width=20 height=\"289\" background=\"images/panel_02.gif\"><img src=\"images/panel_02.gif\" width=\"20\" height=\"100%\"></td>\n";
	print "	<td width=510 height=\"289\">\n";
	print "	<table width=510 border=0 cellspacing=0 cellpadding=0><tr><td align=center>\n";
	print "<font color=\"#ffffff\" face=Arial size=2>\n";
	}

function printfooter() {
	print "</font>\n";
	print "		</td></tr></table>\n";
	print "		</td>\n";
	print "		<td width=20 height=\"289\" background=\"images/panel_04.gif\"><img src=\"images/panel_04.gif\" width=\"20\" height=\"100%\"></td>\n";
	print "	</tr>\n";
	print "	<tr><td colspan=\"3\" width=\"550\" height=\"26\"><img src=\"images/panel_05.gif\" width=\"550\" height=\"26\"></td></tr>\n";
	print "	<tr><td colspan=\"3\" width=\"550\" height=\"25\"><a href=\"http://www.cgihk.com\"><img src=\"images/panel_06.gif\" width=\"550\" height=\"25\" border=\"0\"></a></td></tr>\n";
	print "	</table>\n";
	print "	</body>\n";
	print "	</html>\n";
	}

?>