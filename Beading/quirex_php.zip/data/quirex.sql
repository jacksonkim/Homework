INSERT INTO quirex_config (anticheat, require_info, show_record, show_answer, show_copyright, use_table, randomize_ans, allow_empty_ans, admin_password, admin_email, email_admin, email_taker, header, footer, url_site, url_tick, url_cross, font_face, font_color, table_border_color, table_color_1, table_color_2, level_name_1, level_name_2, level_name_3, no_options, no_recent, no_top) VALUES 
('1', '1', '1', '1', '0', '0', '1', '0', 'demo', 'wctsoi@netvigator.com', '0', '0', '<html>
<head>
<title>Quirex</title>
</head>
<style>
<!--
a {text-decoration : none}
a:hover {text-decoration : underline; color: ddddff}
// -->
</style>
<body bgcolor=\"#587AB1\" text=\"#ffffff\" link=\"#ffffff\" vlink=\"ffdddd\">
<table width=\"550\" height=400 border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=center>
<tr><td colspan=\"3\" width=\"550\" height=\"60\"><img src=\"images/panel_01.gif\" width=\"550\" height=\"60\"></td></tr>
<tr>
	<td width=20 height=\"289\" background=\"images/panel_02.gif\"><img src=\"images/panel_02.gif\" width=\"20\" height=\"100%\"></td>
	<td width=510 height=\"289\">
	<table width=510 border=0 cellspacing=0 cellpadding=0><tr><td>
', '
	</td></tr></table>
	</td>
	<td width=20 height=\"289\" background=\"images/panel_04.gif\"><img src=\"images/panel_04.gif\" width=\"20\" height=\"100%\"></td>
</tr>
<tr><td colspan=\"3\" width=\"550\" height=\"26\"><img src=\"images/panel_05.gif\" width=\"550\" height=\"26\"></td></tr>
<tr><td colspan=\"3\" width=\"550\" height=\"25\"><a href=\"http://www.cgihk.com\"><img src=\"images/panel_06.gif\" width=\"550\" height=\"25\" border=\"0\"></a></td></tr>
</table>
</body>
</html>', 'http://www.cgihk.com', 'http://www.cgihk.com/images/quirex_tick.gif', 'http://www.cgihk.com/images/quirex_cross.gif', 'Arial', '#ffffff', '#000000', '#7F9EBE', '#9FBEDE', 'Beginner', 'Intermediate', 'Advanced', 'All,1,2,3,4,5', '20', '20');
// QUERY SEPARATOR
INSERT INTO quirex_list (quiz_id, quiz_name, quiz_desc, quiz_level) VALUES 
('1', 'Test', 'This is for testing purpose', '1'), 
('2', 'Test 2', 'Another testing', '3'), 
('3', 'Thomas Tsoi', 'Another testing', '2');
// QUERY SEPARATOR
INSERT INTO quirex_ques (quiz_id, ques_id, ques_type, question, ques_img, choice, answer, ans_img, explanation, no_trial, no_correct) VALUES 
('1', '1', 'mc', 'How many constellations are there?', '', '12||13||28||44||88', '88', '', '', '15', '15'), 
('1', '2', 'mc', 'How many planets are there?', '', '1||3||5||7||9||11', '9', '', '', '16', '3'), 
('1', '3', 'ma', 'Which of the following are girl names? ', '', 'Thomas||Connie||Florence||Betty||Isabella||Einstein', 'Connie||Florence||Betty||Isabella', '', '', '14', '14'), 
('1', '4', 'sa', 'What\'s the abbreviation of the \"Joint School Astronomical Society\"?', '', '', 'jsas||hkjsas', '', '', '3', '2'), 
('1', '5', 'mc', 'What is the name of Thomas Tsoi? ', '', 'Thomas Tsoi||Albert Einstein||Stephen Hawking||Richard Feymand', 'Thomas Tsoi', '', 'It\'s ..... !*^!@$&#%%?><:\"}{[]', '15', '15'), 
('1', '6', 'nu', 'What is 2+2?', '', '', '4', '', '', '3', '2'), 
('1', '7', 'tf', 'Jesus is male.', '', '', 't', '', '', '3', '2'), 
('2', '8', 'ma', 'Which of the following are stars?', '', 'Vega||Thomas||Sony||Altair||Polaris', 'Vega||Altair||Polaris', '', '', '1', '1'), 
('1', '9', 'mc', 'Which of the following is Red?', '', '[img=pic1.gif]||[img=pic2.gif]||[img=pic3.gif]||[img=pic4.gif]', '[img=pic3.gif]', '', '', '3', '3'), 
('1', '10', 'ma', 'Which of the following are NOT white?', '', '[img=pic1.gif]||[img=pic2.gif]||[img=pic3.gif]||[img=pic4.gif]', '[img=pic2.gif]||[img=pic3.gif]||[img=pic4.gif]', '', '', '3', '2'), 
('1', '11', 'tf', '9 is a prime number.', '', '', 'f', '', '9 is divisible by 3.', '2', '2'), 
('1', '12', 'tf', '(x<sup>2</sup>+2x-1) is divisible by (x+1).', '', '', 'f', '', '(x<sup>2</sup>-2x+1) is divisible by (x+1), (x<sup>2</sup>+2x-1) is not.', '15', '15');
// QUERY SEPARATOR
INSERT INTO quirex_record (quiz_id, taker_name, taker_email, show_record, no_total, no_correct, time_begin, time_finish, ip) VALUES 
('1', 'Thomas Tsoi', 'thomas@ThomasTsoi.com', '1', '5', '4', '1000637102', '1000638185', ''), 
('2', 'Thomas Tsoi', 'thomas@ThomasTsoi.com', '1', '1', '1', '1000638244', '1000638255', ''), 
('1', 'Thomas Tsoi', 'thomas@ThomasTsoi.com', '1', '5', '0', '1000638562', '1000638564', ''), 
('1', 'Thomas Tsoi', 'thomas@ThomasTsoi.com', '0', '5', '5', '1000642392', '1000642402', '203.198.23.29'), 
('1', 'Thomas Tsoi', 'thomas@ThomasTsoi.com', '1', '11', '11', '1000644915', '1000645023', '203.198.23.169');
// QUERY SEPARATOR
