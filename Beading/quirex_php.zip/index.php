<?
#######################################################################
#                             Quirex PHP                              #
#              By Thomas Tsoi <cgi@cgihk.com> 2001-09-17              #
#        Copyright 2001 (c) CGIHK.com.  All rights reserved.          #
#######################################################################
#                                                                     #
# CGIHK.com:                                                          #
#   http://www.cgihk.com/                                             #
# Support:                                                            #
#   http://www.cgihk.com/forum/                                       #
# ThomasTsoi.com                                                      #
#   http://www.ThomasTsoi.com/                                        #
# Winapi.com                                                          #
#   http://www.winapi.com/                                            #
# Astronomy.org.hk                                                    #
#   http://www.astronomy.org.hk/                                      #
#                                                                     #
# ################################################################### #
#                                                                     #
#        This is a commercial product and CANNOT be distributed       #
#                  without the author's authorization.                #
#                                                                     #
#######################################################################

require("config.php");

if (! mysql_connect($host, $username, $password)) {
	print "MySQL Error: " . mysql_error();
	exit;
	}
mysql_select_db($database);
$result = mysql_query(
"SELECT anticheat, require_info, show_record, show_answer, show_copyright, " . 
"use_table, randomize_ans, allow_empty_ans, " . 
"admin_password, admin_email, email_admin, email_taker, header, footer, ".
"url_site, url_tick, url_cross, font_face, font_color, table_border_color, ".
"table_color_1, table_color_2, level_name_1, level_name_2, level_name_3, ".
"no_options, no_recent, no_top FROM quirex_config");
if ($result) {
	list($anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top) = mysql_fetch_row($result);
	}
else {
	print "MySQL Error: " . mysql_error();
	exit;
	}
$script = "index.php";

if (file_exists("language.php")) {
	include("language.php");
	}
else {
	$language[quiz] = "Quiz";
	$language[total_takers] = "Total Takers";
	$language[record_holder] = "Record Holders";
	$language[na] = "N/A";
	$language[num_of_questions] = "Number of Questions";
	$language[name] = "Name";
	$language[email] = "E-mail";
	$language[both_required] = "both reqired";
	$language[hide_email] = "Check here if you want to hide your email address";
	$language[take_quiz] = "Take the quiz now!";
	$language[tf_true] = "True";
	$language[tf_false] = "False";
	$language[answer] = "Answer";
	$language[submit] = "Done!";
	$language[continue_quiz] = "Continue the Quiz...";
	$language[info_required_msg] = "Both your name and email are required to take the quiz.";
	$language[anticheat_msg] = "You are not allowed to re-take the same quiz within 1 hour.";
	$language[empty_ans_msg] = "You have unanswered questions.";
	$language[your_answer] = "Your Answer";
	$language[correct_answer] = "Correct Answer";
	$language[explanation] = "Explanation";
	$language[result] = "You've got [no_correct] correct out of [no_total] questions, which gives you a score of [percentage].";
	$language[take_again] = "Take the Quiz Again!";
	$language[back] = "Back to Home";
	$language[no_total] = "Ques Attemped";
	$language[no_correct] = "Ques Correct";
	$language[score] = "Score";
	$language[time_taken] = "Time Taken";
	$language[time_of_trial] = "Time";	
	}

srand ((float) microtime() * 1000000);

header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header ("Cache-Control: no-cache, must-revalidate");
header ("Pragma: no-cache");

print $header;
if ($action == 'quiz' && $quiz != '') {
	if (isset($first_ques)) {
		continue_quiz();
		}
	else {
		start_quiz();
		}
	}
elseif ($action == 'done' && $quiz != '') {
	check_answer();
	}
elseif ($quiz) {
	if (eregi("^recent", $show)) $show = "recent";
	if (eregi("^top", $show)) $show = "top";

	if (($show == 'recent' || $show == 'top') && $show_record) {
		show_record($show);
		}
	else {
		start_quiz(0);
		}
	}
else {
	show_quiz();
	}
print $footer;


function show_quiz($msg = '') {
	global $script, $anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top;
	global $action, $quiz, $number, $name, $email, $hide;
	global $language;

	print "<form action=\"$script\" method=\"post\">\n";
	print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=$table_border_color width=90% align=center><tr><td>\n";
	print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";

	if ($show_record) {$colspan=4;} else {$colspan=2;}

	print "<tr>";
	print "<td bgcolor=$table_color_1 align=center><font face=\"$font_face\" color=\"$table_color_1\" size=1>.</font></td>";
	print "<td bgcolor=$table_color_1 width=90%><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[quiz]</b></font></td>";
	if ($show_record) {
		print "<td bgcolor=$table_color_1 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><b><nobr>$language[total_takers]</nobr></b></font></td>";
		print "<td bgcolor=$table_color_1 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><b><nobr>$language[record_holder]</nobr></b></font></td>";
		}
	print "</tr>\n";

	$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '0' ORDER BY quiz_name");
	if (mysql_num_rows($result) > 0) {
		for ($i=0;$i<mysql_num_rows($result);$i++) {
			list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
			list($ttl_taker) = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM quirex_record WHERE quiz_id = '$quiz_id'"));
			if ($ttl_taker > 0) {list($record_holder) = mysql_fetch_row(mysql_query("SELECT taker_name FROM quirex_record WHERE quiz_id = '$quiz_id' ORDER BY (no_correct/no_total) DESC, no_total DESC, (time_finish - time_begin) ASC, time_finish DESC LIMIT 1"));} else {$record_holder = "$language[na]";}
			print "<tr>";
			print "<td bgcolor=$table_color_2 align=right><input type=radio name=quiz value=\"$quiz_id\"></td>";
			print "<td bgcolor=$table_color_2 width=90%><font face=\"$font_face\" color=\"$font_color\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td>";
			if ($show_record) {
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=recent\">$ttl_taker</a></font></td>";
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=top\">$record_holder</a></font></td>";
				}
			print "</tr>\n";
			}
		}

	$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '1' ORDER BY quiz_name");
	if (mysql_num_rows($result) > 0) {
		print "<tr><td bgcolor=$table_color_1 colspan=$colspan><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$level_name_1</i></b></font></td></tr>\n";
		for ($i=0;$i<mysql_num_rows($result);$i++) {
			list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
			list($ttl_taker) = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM quirex_record WHERE quiz_id = '$quiz_id'"));
			if ($ttl_taker > 0) {list($record_holder) = mysql_fetch_row(mysql_query("SELECT taker_name FROM quirex_record WHERE quiz_id = '$quiz_id' ORDER BY (no_correct/no_total) DESC, no_total DESC, (time_finish - time_begin) ASC, time_finish DESC LIMIT 1"));} else {$record_holder = "$language[na]";}
			print "<tr>";
			print "<td bgcolor=$table_color_2 align=center><input type=radio name=quiz value=\"$quiz_id\"></td>";
			print "<td bgcolor=$table_color_2 width=90%><font face=\"$font_face\" color=\"$font_color\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td>";
			if ($show_record) {
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=recent\">$ttl_taker</a></font></td>";
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=top\">$record_holder</a></font></td>";
				}
			print "</tr>\n";
			}
		}

	$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '2' ORDER BY quiz_name");
	if (mysql_num_rows($result) > 0) {
		print "<tr><td bgcolor=$table_color_1 colspan=$colspan><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$level_name_2</i></b></font></td></tr>\n";
		for ($i=0;$i<mysql_num_rows($result);$i++) {
			list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
			list($ttl_taker) = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM quirex_record WHERE quiz_id = '$quiz_id'"));
			if ($ttl_taker > 0) {list($record_holder) = mysql_fetch_row(mysql_query("SELECT taker_name FROM quirex_record WHERE quiz_id = '$quiz_id' ORDER BY (no_correct/no_total) DESC, no_total DESC, (time_finish - time_begin) ASC, time_finish DESC LIMIT 1"));} else {$record_holder = "$language[na]";}
			print "<tr>";
			print "<td bgcolor=$table_color_2 align=center><input type=radio name=quiz value=\"$quiz_id\"></td>";
			print "<td bgcolor=$table_color_2 width=90%><font face=\"$font_face\" color=\"$font_color\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td>";
			if ($show_record) {
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=recent\">$ttl_taker</a></font></td>";
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=top\">$record_holder</a></font></td>";
				}
			print "</tr>\n";
			}
		}
	$result = mysql_query("SELECT quiz_id, quiz_name, quiz_desc FROM quirex_list WHERE quiz_level = '3' ORDER BY quiz_name");
	if (mysql_num_rows($result) > 0) {
		print "<tr><td bgcolor=$table_color_1 colspan=$colspan><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$level_name_3</i></b></font></td></tr>\n";
		for ($i=0;$i<mysql_num_rows($result);$i++) {
			list($quiz_id, $quiz_name, $quiz_desc) = mysql_fetch_row($result);
			list($ttl_taker) = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM quirex_record WHERE quiz_id = '$quiz_id'"));
			if ($ttl_taker > 0) {list($record_holder) = mysql_fetch_row(mysql_query("SELECT taker_name FROM quirex_record WHERE quiz_id = '$quiz_id' ORDER BY (no_correct/no_total) DESC, no_total DESC, (time_finish - time_begin) ASC, time_finish DESC LIMIT 1"));} else {$record_holder = "$language[na]";}
			print "<tr>";
			print "<td bgcolor=$table_color_2 align=center><input type=radio name=quiz value=\"$quiz_id\"></td>";
			print "<td bgcolor=$table_color_2 width=90%><font face=\"$font_face\" color=\"$font_color\" size=2><b>$quiz_name</b><br><font size=1>$quiz_desc</font></font></td>";
			if ($show_record) {
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=recent\">$ttl_taker</a></font></td>";
				print "<td bgcolor=$table_color_2 align=center><font face=\"$font_face\" color=\"$font_color\" size=1><a href=\"$script?quiz=$quiz_id&show=top\">$record_holder</a></font></td>";
				}
			print "</tr>\n";
			}
		}
	print "<tr bgcolor=$table_color_1><td colspan=$colspan><font face=\"$font_face\" color=\"$font_color\" size=2>$language[num_of_questions]: <select name=\"number\">";
	$options = split(",", $no_options);
	for ($i=0;$i<count($options);$i++) 
	print "<option value=\"$options[$i]\">$options[$i]";
	print "</select></font></td></tr>\n";
	if ($msg) 
	print "<tr bgcolor=#ff0000><td colspan=$colspan><font face=\"$font_face\" color=\"#ffffff\" size=2><b>$msg</b></font></td></tr>\n";
	if ($require_info) 
	print "<tr bgcolor=$table_color_1><td colspan=$colspan><font face=\"$font_face\" color=\"$font_color\" size=2>$language[name]: <input type=text name=name size=20 maxlength=40 value=\"$name\"> $language[email]:<input type=text name=email size=20 value=\"$email\"> <i>($language[both_required])</i><br>$language[hide_email]: <input type=\"checkbox\" name=\"hide\" value=1></font></td></tr>\n";
	print "<tr><td bgcolor=$table_color_1 colspan=$colspan align=center><font face=\"$font_face\" color=\"$font_color\" size=2><input type=submit value=\"$language[take_quiz]\" style=\"background-color: $table_color_2; font-family: $font_face\"></font></td></tr>\n";
	if ($show_copyright) 
	print "<tr bgcolor=$table_color_1><td colspan=$colspan align=right><font face=\"$font_face\" color=\"$font_color\" size=1>Powered by <a href=\"http://www.cgihk.com\">Quirex PHP</a></font></td></tr>\n";
	print "</table>\n";
	print "</td></tr></table>\n";
	print "<input type=hidden name=action value=\"quiz\">\n";
	print "</form>\n";

	}







function start_quiz($check_info = 1) {
	global $script, $anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top;
	global $action, $quiz, $number, $name, $email, $hide;
	global $language;
	
	if ($check_info && $require_info && ($name == '' || ! ereg(".+@.+\..+", $email))) {
			show_quiz($language[both_required_long]);
		}
	else {
		list($all_ques) = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM quirex_ques WHERE quiz_id = '$quiz'"));
		
		if ($all_ques == 0) {
			print "No questions";
			print $footer;
			exit;
			}
		
		if(is_numeric($number)) {
			$ques_show = min($number, $all_ques);
			}
		elseif (strtolower($number) == 'all') {
			$ques_show = $all_ques;
			}
		else {
			$ques_show = min(10, $all_ques);
			}

		print "<script language=\"JavaScript\">\n";
		print "<!--\n";
		print "function checkValue(obj) {\n";
		print "	if (isNaN(obj.value)) {\n";
		print "		alert('this question requires a numeric answer!');\n";
		print "		obj.value = '';\n";
		print "		}\n";
		print "	}\n";
		print "// -->\n";
		print "</script>\n";

		print "<form action=\"$script\" method=\"post\">\n";
		list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
		if ($use_table) {
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=$table_border_color width=90% align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			print "<tr bgcolor=$table_color_1><td><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name</i></b></font></td></tr>\n";
			}
		else {
			print "<font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name</i></b></font><br><br>\n";
			print "<font face=\"$font_face\" color=\"$font_color\" size=2>\n";
			}

		$result = mysql_query("SELECT ques_id, ques_type, question, ques_img, choice FROM quirex_ques WHERE quiz_id = '$quiz' ORDER BY RAND() LIMIT $ques_show");
		for ($i=0;$i<mysql_num_rows($result);$i++) {
			list($ques_id, $ques_type, $question, $ques_img, $choice) = mysql_fetch_row($result);
			$ques_array[] = $ques_id;
			$row_color = ($i % 2) ? $table_color_1 : $table_color_2;
			if ($use_table) {
				print "<tr bgcolor=$row_color><td><font face=\"$font_face\" color=\"$font_color\" size=2>";
				print "<b>".($i+1).". $question</b><br>";
				if ($ques_img) print "<img src=\"$ques_img\"><br>";
				if ($ques_type == 'mc') {
					$choices = split("\|\|", $choice);
					if ($randomize_ans) {
						for ($j=0;$j<count($choices)*2; $j++) {
							$x = rand(0,count($choices)-1);
							do {
								$y = rand(0,count($choices)-1);
								} while ($x == $y);
							$temp = $choices[$x];
							$choices[$x] = $choices[$y];
							$choices[$y] = $temp;
							}
						}
					for ($j=0;$j<count($choices); $j++) {
						$choice_value = $choices[$j];
						if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
							$choice_shown = "<img src=\"$vars[1]\">";
							}
						else {
							$choice_shown = $choices[$j];
							}
						print "<input type=radio name=\"q$i\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
						}
					}
				elseif ($ques_type == 'ma') {
					$choices = split("\|\|", $choice);
					if ($randomize_ans) {
						for ($j=0;$j<count($choices)*2; $j++) {
							$x = rand(0,count($choices)-1);
							do {
								$y = rand(0,count($choices)-1);
								} while ($x == $y);
							$temp = $choices[$x];
							$choices[$x] = $choices[$y];
							$choices[$y] = $temp;
							}
						}
					for ($j=0;$j<count($choices); $j++) {
						$choice_value = $choices[$j];
						if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
							$choice_shown = "<img src=\"$vars[1]\">";
							}
						else {
							$choice_shown = $choices[$j];
							}
						print "<input type=checkbox name=\"q$i"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
						}
					}
				elseif ($ques_type == 'sa') {
					print "$language[answer]: <input type=text name=\"q$i\" size=30><br>";
					}
				elseif ($ques_type == 'nu') {
					print "$language[answer]: <input type=text name=\"q$i\" size=30 onChange=\"checkValue(this);\"><br>";
					}
				elseif ($ques_type == 'tf') {
					print "<input type=radio name=\"q$i\" value=t>$language[tf_true] <input type=radio name=\"q$i\" value=f>$language[tf_false]<br>";
					}

				print "</font></td></tr>\n";
				}
			else {
				print "<b>".($i+1).". $question</b><br>";
				if ($ques_img) print "<img src=\"$ques_img\"><br>";
				if ($ques_type == 'mc') {
					$choices = split("\|\|", $choice);
					if ($randomize_ans) {
						for ($j=0;$j<count($choices)*2; $j++) {
							$x = rand(0,count($choices)-1);
							do {
								$y = rand(0,count($choices)-1);
								} while ($x == $y);
							$temp = $choices[$x];
							$choices[$x] = $choices[$y];
							$choices[$y] = $temp;
							}
						}
					for ($j=0;$j<count($choices); $j++) {
						$choice_value = $choices[$j];
						if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
							$choice_shown = "<img src=\"$vars[1]\">";
							}
						else {
							$choice_shown = $choices[$j];
							}
						print "<input type=radio name=\"q$i\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
						}
					}
				elseif ($ques_type == 'ma') {
					$choices = split("\|\|", $choice);
					if ($randomize_ans) {
						for ($j=0;$j<count($choices)*2; $j++) {
							$x = rand(0,count($choices)-1);
							do {
								$y = rand(0,count($choices)-1);
								} while ($x == $y);
							$temp = $choices[$x];
							$choices[$x] = $choices[$y];
							$choices[$y] = $temp;
							}
						}
					for ($j=0;$j<count($choices); $j++) {
						$choice_value = $choices[$j];
						if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
							$choice_shown = "<img src=\"$vars[1]\">";
							}
						else {
							$choice_shown = $choices[$j];
							}
						print "<input type=checkbox name=\"q$i"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
						}
					}
				elseif ($ques_type == 'sa') {
					print "$language[answer]: <input type=text name=\"q$i\" size=30><br>";
					}
				elseif ($ques_type == 'nu') {
					print "$language[answer]: <input type=text name=\"q$i\" size=30 onChange=\"checkValue(this);\"><br>";
					}
				elseif ($ques_type == 'tf') {
					print "<input type=radio name=\"q$i\" value=t>$language[tf_true] <input type=radio name=\"q$i\" value=f>$language[tf_false]<br>";
					}
				print "<br>\n";
				}
			}

		if ($use_table) {
			if (!$check_info && $require_info)
			print "<tr><td bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2>$language[name]: <input type=text name=name size=20 maxlength=40 value=\"$name\"> $language[email]:<input type=text name=email size=20 value=\"$email\"> <i>($language[both_required])</i><br>$language[hide_email]: <input type=\"checkbox\" name=\"hide\" value=1></font></td></tr>\n";
			print "<tr><td bgcolor=$table_color_1 align=center><input type=submit value=\"$language[submit]\" style=\"background-color: $table_color_2; font-family: $font_face\"></td></tr>\n";
			if ($show_copyright) 
			print "<tr bgcolor=$table_color_1><td align=right><font face=\"$font_face\" color=\"$font_color\" size=1>Powered by <a href=\"http://www.cgihk.com\">Quirex PHP</a></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			}
		else {
			if (!$check_info && $require_info)
			print "<font face=\"$font_face\" color=\"$font_color\" size=2>$language[name]: <input type=text name=name size=20 maxlength=40 value=\"$name\"> $language[email]:<input type=text name=email size=20 value=\"$email\"> <i>($language[both_required])</i><br>$language[hide_email]: <input type=\"checkbox\" name=\"hide\" value=1></font>\n";
			print "<p align=center><input type=submit value=\"$language[submit]\" style=\"background-color: $table_color_2; font-family: $font_face\"></p>\n";
			print "</font>";
			if ($show_copyright) 
			print "<p align=right><font face=\"$font_face\" color=\"$font_color\" size=1>Powered by <a href=\"http://www.cgihk.com\">Quirex PHP</a></font></p>\n";
			}

		if ($check_info && $require_info) {
		print "<input type=\"hidden\" name=\"name\" value=\"$name\">\n";
		print "<input type=\"hidden\" name=\"email\" value=\"$email\">\n";
		print "<input type=\"hidden\" name=\"hide\" value=\"$hide\">\n";
			}
		print "<input type=\"hidden\" name=\"begin\" value=\"".time()."\">\n";
		print "<input type=\"hidden\" name=\"quiz\" value=\"$quiz\">\n";
		print "<input type=\"hidden\" name=\"number\" value=\"$ques_show\">\n";
		print "<input type=\"hidden\" name=\"action\" value=\"done\">\n";
		print "<input type=\"hidden\" name=\"array\" value=\"".join(",", $ques_array)."\">\n";
		print "</form>\n";

		}
	}







function continue_quiz() {
	global $script, $anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top;
	global $action, $quiz, $number, $name, $email, $hide, $first_ques, $q0;
	global $language;

	list($all_ques) = mysql_fetch_row(mysql_query("SELECT COUNT(*) FROM quirex_ques WHERE quiz_id = '$quiz'"));

	if(is_numeric($number)) {
		$ques_show = min($number, $all_ques);
		}
	elseif (strtolower($number) == 'all') {
		$ques_show = $all_ques;
		}
	else {
		$ques_show = min(10, $all_ques);
		}

	print "<script language=\"JavaScript\">\n";
	print "<!--\n";
	print "function checkValue(obj) {\n";
	print "	if (isNaN(obj.value)) {\n";
	print "		alert('this question requires a numeric answer!');\n";
	print "		obj.value = '';\n";
	print "		}\n";
	print "	}\n";
	print "// -->\n";
	print "</script>\n";

	print "<form action=\"$script\" method=\"post\">\n";
	list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
	if ($use_table) {
		print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=$table_border_color width=90% align=center><tr><td>\n";
		print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
		print "<tr bgcolor=$table_color_1><td><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name</i></b></font></td></tr>\n";
		}
	else {
		print "<font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name</i></b></font><br><br>\n";
		print "<font face=\"$font_face\" color=\"$font_color\" size=2>\n";
		}

	list($ques_id, $ques_type, $question, $ques_img, $choice) = mysql_fetch_row(mysql_query("SELECT ques_id, ques_type, question, ques_img, choice FROM quirex_ques WHERE quiz_id = '$quiz' AND ques_id = '$first_ques' LIMIT 1"));

	$ques_search = $ques_show - 1;
	$result = mysql_query("SELECT ques_id, ques_type, question, ques_img, choice FROM quirex_ques WHERE quiz_id = '$quiz' AND ques_id != '$first_ques' ORDER BY RAND() LIMIT $ques_search");
	for ($i=0;$i<mysql_num_rows($result)+1;$i++) {
		if ($i>0) {
			list($ques_id, $ques_type, $question, $ques_img, $choice) = mysql_fetch_row($result);
			}
		$ques_array[] = $ques_id;
		$row_color = ($i % 2) ? $table_color_1 : $table_color_2;
		if ($use_table) {
			print "<tr bgcolor=$row_color><td><font face=\"$font_face\" color=\"$font_color\" size=2>";
			print "<b>".($i+1).". $question</b><br>";
			if ($ques_img) print "<img src=\"$ques_img\"><br>";
			if ($ques_type == 'mc') {
				$choices = split("\|\|", $choice);
				if ($randomize_ans) {
					for ($j=0;$j<count($choices)*2; $j++) {
						$x = rand(0,count($choices)-1);
						do {
							$y = rand(0,count($choices)-1);
							} while ($x == $y);
						$temp = $choices[$x];
						$choices[$x] = $choices[$y];
						$choices[$y] = $temp;
						}
					}
				for ($j=0;$j<count($choices); $j++) {
					$choice_value = $choices[$j];
					if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
						$choice_shown = "<img src=\"$vars[1]\">";
						}
					else {
						$choice_shown = $choices[$j];
						}
					if ($i==0 && $choice_value == $q0)
					print "<input type=radio name=\"q$i\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\" checked> $choice_shown<br>";
					else
					print "<input type=radio name=\"q$i\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
					}
				}
			elseif ($ques_type == 'ma') {
				$choices = split("\|\|", $choice);
				if ($randomize_ans) {
					for ($j=0;$j<count($choices)*2; $j++) {
						$x = rand(0,count($choices)-1);
						do {
							$y = rand(0,count($choices)-1);
							} while ($x == $y);
						$temp = $choices[$x];
						$choices[$x] = $choices[$y];
						$choices[$y] = $temp;
						}
					}
				for ($j=0;$j<count($choices); $j++) {
					$choice_value = $choices[$j];
					if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
						$choice_shown = "<img src=\"$vars[1]\">";
						}
					else {
						$choice_shown = $choices[$j];
						}
					if ($i==0) {
						$matched = 0;
						for ($k=0;$k<count($choices); $k++) {
							if ($q0[$k] == $choice_value) $matched = 1;
							}
						if ($matched)
							print "<input type=checkbox name=\"q0"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\" checked> $choice_shown<br>";
						else 
							print "<input type=checkbox name=\"q0"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
						}
					else
						print "<input type=checkbox name=\"q$i"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
					}
				}
			elseif ($ques_type == 'sa') {
				if ($i==0)
				print "$language[answer]: <input type=text name=\"q0\" value=\"". eregi_replace("\"", "&quot;", $q0) ."\" size=30><br>";
				else
				print "$language[answer]: <input type=text name=\"q$i\" size=30><br>";
				}
			elseif ($ques_type == 'nu') {
				if ($i==0)
				print "$language[answer]: <input type=text name=\"q0\" value=\"". eregi_replace("\"", "&quot;", $q0) ."\" size=30 onChange=\"checkValue(this);\"><br>";
				else
				print "$language[answer]: <input type=text name=\"q$i\" size=30 onChange=\"checkValue(this);\"><br>";
				}
			elseif ($ques_type == 'tf') {
				if ($i==0) {
					if ($q0 == 't') $selected_t = " checked";
					if ($q0 == 'f') $selected_f = " checked";
					print "<input type=radio name=\"q0\" value=t$selected_t>$language[tf_true] <input type=radio name=\"q0\" value=f$selected_f>$language[tf_false]<br>";
					}
				else
					print "<input type=radio name=\"q$i\" value=t>$language[tf_true] <input type=radio name=\"q$i\" value=f>$language[tf_false]<br>";
				}

			print "</font></td></tr>\n";
			}
		else {
			print "<b>".($i+1).". $question</b><br>";
			if ($ques_img) print "<img src=\"$ques_img\"><br>";
			if ($ques_type == 'mc') {
				$choices = split("\|\|", $choice);
				if ($randomize_ans) {
					for ($j=0;$j<count($choices)*2; $j++) {
						$x = rand(0,count($choices)-1);
						do {
							$y = rand(0,count($choices)-1);
							} while ($x == $y);
						$temp = $choices[$x];
						$choices[$x] = $choices[$y];
						$choices[$y] = $temp;
						}
					}
				for ($j=0;$j<count($choices); $j++) {
					$choice_value = $choices[$j];
					if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
						$choice_shown = "<img src=\"$vars[1]\">";
						}
					else {
						$choice_shown = $choices[$j];
						}
					if ($i==0 && $choice_value == $q0)
					print "<input type=radio name=\"q$i\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\" checked> $choice_shown<br>";
					else
					print "<input type=radio name=\"q$i\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
					}
				}
			elseif ($ques_type == 'ma') {
				$choices = split("\|\|", $choice);
				if ($randomize_ans) {
					for ($j=0;$j<count($choices)*2; $j++) {
						$x = rand(0,count($choices)-1);
						do {
							$y = rand(0,count($choices)-1);
							} while ($x == $y);
						$temp = $choices[$x];
						$choices[$x] = $choices[$y];
						$choices[$y] = $temp;
						}
					}
				for ($j=0;$j<count($choices); $j++) {
					$choice_value = $choices[$j];
					if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
						$choice_shown = "<img src=\"$vars[1]\">";
						}
					else {
						$choice_shown = $choices[$j];
						}
					if ($i==0) {
						$matched = 0;
						for ($k=0;$k<count($choices); $k++) {
							if ($q0[$k] == $choice_value) $matched = 1;
							}
						if ($matched)
							print "<input type=checkbox name=\"q0"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\" checked> $choice_shown<br>";
						else 
							print "<input type=checkbox name=\"q0"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
						}
					else
						print "<input type=checkbox name=\"q$i"."[$j]\" value=\"". eregi_replace("\"", "&quot;", $choice_value) ."\"> $choice_shown<br>";
					}
				}
			elseif ($ques_type == 'sa') {
				if ($i==0)
				print "$language[answer]: <input type=text name=\"q0\" value=\"". eregi_replace("\"", "&quot;", $q0) ."\" size=30><br>";
				else
				print "$language[answer]: <input type=text name=\"q$i\" size=30><br>";
				}
			elseif ($ques_type == 'nu') {
				if ($i==0)
				print "$language[answer]: <input type=text name=\"q0\" value=\"". eregi_replace("\"", "&quot;", $q0) ."\" size=30 onChange=\"checkValue(this);\"><br>";
				else
				print "$language[answer]: <input type=text name=\"q$i\" size=30 onChange=\"checkValue(this);\"><br>";
				}
			elseif ($ques_type == 'tf') {
				if ($i==0) {
					if ($q0 == 't') $selected_t = " checked";
					if ($q0 == 'f') $selected_f = " checked";
					print "<input type=radio name=\"q0\" value=t$selected_t>$language[tf_true] <input type=radio name=\"q0\" value=f$selected_f>$language[tf_false]<br>";
					}
				else
					print "<input type=radio name=\"q$i\" value=t>$language[tf_true] <input type=radio name=\"q$i\" value=f>$language[tf_false]<br>";
				}
			print "<br>\n";
			}
		}

	if ($use_table) {
		if ($require_info)
		print "<tr><td bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2>$language[name]: <input type=text name=name size=20 maxlength=40 value=\"$name\"> $language[email]:<input type=text name=email size=20 value=\"$email\"> <i>($language[both_required])</i><br>$language[hide_email]: <input type=\"checkbox\" name=\"hide\" value=1></font></td></tr>\n";
		print "<tr><td bgcolor=$table_color_1 align=center><input type=submit value=\"$language[submit]\" style=\"background-color: $table_color_2; font-family: $font_face\"></td></tr>\n";
		if ($show_copyright) 
		print "<tr bgcolor=$table_color_1><td align=right><font face=\"$font_face\" color=\"$font_color\" size=1>Powered by <a href=\"http://www.cgihk.com\">Quirex PHP</a></font></td></tr>\n";
		print "</table>\n";
		print "</td></tr></table>\n";
		}
	else {
		if ($require_info)
		print "<font face=\"$font_face\" color=\"$font_color\" size=2>$language[name]: <input type=text name=name size=20 maxlength=40 value=\"$name\"> $language[email]:<input type=text name=email size=20 value=\"$email\"> <i>($language[both_required])</i><br>$language[hide_email]: <input type=\"checkbox\" name=\"hide\" value=1></font>\n";
		print "<p align=center><input type=submit value=\"$language[submit]\" style=\"background-color: $table_color_2; font-family: $font_face\"></p>\n";
		print "</font>";
		if ($show_copyright) 
		print "<p align=right><font face=\"$font_face\" color=\"$font_color\" size=1>Powered by <a href=\"http://www.cgihk.com\">Quirex PHP</a></font></p>\n";
		}


	print "<input type=\"hidden\" name=\"begin\" value=\"".time()."\">\n";
	print "<input type=\"hidden\" name=\"quiz\" value=\"$quiz\">\n";
	print "<input type=\"hidden\" name=\"number\" value=\"$ques_show\">\n";
	print "<input type=\"hidden\" name=\"action\" value=\"done\">\n";
	print "<input type=\"hidden\" name=\"array\" value=\"".join(",", $ques_array)."\">\n";
	print "</form>\n";

	}







function check_answer() {
	global $script, $anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top;
	global $action, $array, $quiz, $number, $name, $email, $hide, $begin;
	global $language;
	for ($i=0;$i<$number;$i++)
		global ${"q$i"};

	$taker_ip = getenv("REMOTE_ADDR");

	if ($anticheat != 0) {
		$seconds = $anticheat * 3600;
		$result = mysql_query("SELECT * FROM quirex_record WHERE ip = '$taker_ip' AND quiz_id = '$quiz' AND (UNIX_TIMESTAMP() -  time_finish) < $seconds");
		}
	if (!$allow_empty_ans) {
		$empty_ans = 0;
		for ($i=0;$i<$number;$i++)
			if (!isset(${"q$i"}))
				$empty_ans = 1;
		}
	if ($anticheat != 0 && mysql_num_rows($result) != 0) {
		print "<font face=\"$font_face\" color=\"$font_color\" size=3>$language[anticheat_msg]</font>";
		}
	elseif (!$allow_empty_ans && $empty_ans) {
		print "<font face=\"$font_face\" color=\"$font_color\" size=3>$language[empty_ans_msg]</font>";
		}
	elseif ($require_info && ($name == '' || ! ereg(".+@.+\..+", $email))) {
		print "<font face=\"$font_face\" color=\"$font_color\" size=3>$language[info_required_msg]</font>";
		}
	else {
		print "<font face=\"$font_face\" color=\"$font_color\" size=2>\n";
		$id = split(",", $array);
		$no_correct = 0;

		list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));
		if ($use_table) {
			print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=$table_border_color width=90% align=center><tr><td>\n";
			print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
			print "<tr bgcolor=$table_color_1><td colspan=2><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name</i></b></font></td></tr>\n";
			}
		else {
			print "<font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name</i></b></font><br><br>\n";
			}

		for ($i=0;$i<$number;$i++) {
			list($ques_id, $ques_type, $question, $choice, $answer, $ans_img, $explanation) = mysql_fetch_row(mysql_query("SELECT ques_id, ques_type, question, choice, answer, ans_img, explanation FROM quirex_ques WHERE ques_id = '$id[$i]'"));
			if ($ques_type == 'ma') {
				if (isset(${"q$i"})) {
					foreach (${"q$i"} as $index => $value) {
						${"q$i"}[$index] = stripslashes(${"q$i"}[$index]);
						}
					}
				}
			else {
				${"q$i"} = stripslashes(${"q$i"});
				}

			$is_correct = 0;
			if ($ques_type == 'mc') {
				if (${"q$i"} == $answer)
					$is_correct = 1;
				}
			elseif ($ques_type == 'ma' && isset(${"q$i"})) {
				$multi_ans = split("\|\|", $answer);
				$flag = 1;
				for ($j=0;$j<count($multi_ans);$j++) {
					if (! in_array($multi_ans[$j], ${"q$i"})) $flag = 0;
					}
				if ($flag == 1 && count(${"q$i"}) == count($multi_ans))
					$is_correct = 1;
				}
			elseif ($ques_type == 'sa') {
				$multi_ans = split("\|\|", $answer);
				for ($j=0;$j<count($multi_ans);$j++) 
					if (trim(strtolower(${"q$i"})) == trim(strtolower($multi_ans[$j])))
						$is_correct = 1;
				}
			elseif ($ques_type == 'tf') {
				if (${"q$i"} == $answer)
					$is_correct = 1;
				}
			elseif ($ques_type == 'nu') {
				if (trim(${"q$i"}) == trim($answer))
					$is_correct = 1;
				}

			mysql_query("UPDATE quirex_ques SET no_trial = no_trial + 1 WHERE ques_id = '$ques_id'");
			if ($is_correct) {
				$no_correct++;
				mysql_query("UPDATE quirex_ques SET no_correct = no_correct + 1 WHERE ques_id = '$ques_id'");
				}
			
			if ($use_table) {
				$row_color = ($i % 2) ? $table_color_1 : $table_color_2;
				print "<tr><td valign=middle bgcolor=$row_color>";
				if ($is_correct)
					print "<img src=\"$url_tick\"></td>";
				else
					print "<img src=\"$url_cross\"></td>";
					
				print "<td valign=top bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>";
				
				print "<b>".($i+1).". $question</b><br>";				
				
				if ($ques_type == 'mc' && isset(${"q$i"}))
					$your_ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", ${"q$i"});
				elseif ($ques_type == 'ma' && isset(${"q$i"}))
					$your_ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", join(", ", ${"q$i"}));
				elseif ($ques_type == 'sa' && ${"q$i"} != '')
					$your_ans = trim(${"q$i"});
				elseif ($ques_type == 'tf' && isset(${"q$i"})) {
					if (${"q$i"} == 't') $your_ans = $language[tf_true];
					if (${"q$i"} == 'f') $your_ans = $language[tf_false];
					}
				elseif ($ques_type == 'nu' && ${"q$i"} != '') {
					$your_ans = ${"q$i"};
					}
				else {
					$your_ans = $language[na];
					}

				print "<b>$language[your_answer]:</b> $your_ans<br>";
				if ($show_answer) {
					if ($ques_type == 'sa') {
						$ans = join(", ", split("\|\|", $answer));
						}
					elseif ($ques_type == 'ma') {
						$ans = join(", ", split("\|\|", $answer));
						$ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", $ans);
						}
					elseif ($ques_type == 'tf') {
						if ($answer == 't') $ans = $language[tf_true];
						if ($answer == 'f') $ans = $language[tf_false];
						}
					elseif ($ques_type == 'mc')
						$ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", $answer);
					else
						$ans = $answer;
					print "<b>$language[correct_answer]:</b> $ans<br>";
					if ($ans_img)
						print "<img src=\"$ans_img\"><br>";
					if ($explanation)
						print "<b>$language[explanation]:</b> <i>$explanation</i><br>";
					}
				print "</td</tr>\n";
				}
			else {
				if ($is_correct)
					print "<img src=\"$url_tick\"> ";
				else
					print "<img src=\"$url_cross\"> ";
				print "<b>".($i+1).". $question</b><br>";
				
				if ($ques_type == 'mc' && isset(${"q$i"}))
					$your_ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", ${"q$i"});
				elseif ($ques_type == 'ma' && isset(${"q$i"}))
					$your_ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", join(", ", ${"q$i"}));
				elseif ($ques_type == 'sa' && ${"q$i"} != '')
					$your_ans = trim(${"q$i"});
				elseif ($ques_type == 'tf' && isset(${"q$i"})) {
					if (${"q$i"} == 't') $your_ans = $language[tf_true];
					if (${"q$i"} == 'f') $your_ans = $language[tf_false];
					}
				elseif ($ques_type == 'nu' && ${"q$i"} != '') {
					$your_ans = ${"q$i"};
					}
				else {
					$your_ans = $language[na];
					}

				print "<b>$language[your_answer]:</b> $your_ans<br>";
				if ($show_answer) {
					if ($ques_type == 'sa') {
						$ans = join(", ", split("\|\|", $answer));
						}
					elseif ($ques_type == 'ma') {
						$ans = join(", ", split("\|\|", $answer));
						$ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", $ans);
						}
					elseif ($ques_type == 'tf') {
						if ($answer == 't') $ans = $language[tf_true];
						if ($answer == 'f') $ans = $language[tf_false];
						}
					elseif ($ques_type == 'mc')
						$ans = eregi_replace("\[img=([^]]+)\]", "<img src=\"\\1\">", $answer);
					else
						$ans = $answer;
					print "<b>$language[correct_answer]:</b> $ans<br>";
					if ($ans_img)
						print "<img src=\"$ans_img\"><br>";
					if ($explanation)
						print "<b>$language[explanation]:</b> <i>$explanation</i><br>";
					}
				print "<br>\n";
				}
			}
		


		$percentage = round($no_correct/$number*10000) / 100;
		$language[result] = eregi_replace("\[no_correct\]", "$no_correct", $language[result]);
		$language[result] = eregi_replace("\[no_total\]", "$number", $language[result]);
		$language[result] = eregi_replace("\[percentage\]", "$percentage", $language[result]);
		if ($use_table) print "<tr bgcolor=$table_color_1><td colspan=2>\n";
		print "<font face=\"$font_face\" color=\"$font_color\" size=4>$language[result]</font>\n";
		if ($use_table) print "</td></tr>\n";

		if (!$anticheat) {
			if ($use_table) print "<tr bgcolor=$table_color_1><td colspan=2>\n";
			print "<p align=center>\n";
			print "<form action=\"$script\" method=\"post\">\n";
			print "<input type=\"hidden\" name=\"quiz\" value=\"$quiz\">\n";
			print "<input type=\"hidden\" name=\"number\" value=\"$number\">\n";
			print "<input type=\"hidden\" name=\"hide\" value=\"$hide\">\n";
			print "<input type=\"hidden\" name=\"name\" value=\"$name\">\n";
			print "<input type=\"hidden\" name=\"email\" value=\"$email\">\n";
			print "<input type=\"hidden\" name=\"action\" value=\"quiz\">\n";
			print "<input type=submit value=\"$language[take_again]\" style=\"background-color: $table_color_2; font-family: $font_face\">\n";
			print "</form>\n";
			print "</p>\n";
			if ($use_table) print "</td></tr>\n";
			}
		
		if ($use_table) {
			if ($show_copyright) 
			print "<tr bgcolor=$table_color_1><td align=right colspan=2><font face=\"$font_face\" color=\"$font_color\" size=1>Powered by <a href=\"http://www.cgihk.com\">Quirex PHP</a></font></td></tr>\n";
			print "</table>\n";
			print "</td></tr></table>\n";
			}

		print "<p><b><a href=\"$url_site\">$language[back]</a></b></p>";
		if ($hide == '1') $show_info = 0;
		if ($hide == '') $show_info = 1;
		mysql_query("INSERT INTO quirex_record SET quiz_id = '$quiz', taker_name = '$name', taker_email = '$email', show_record = '$show_info', no_total = '$number', no_correct = '$no_correct', time_begin = '$begin', time_finish = UNIX_TIMESTAMP(), ip = '$taker_ip'");

		$seconds = $anticheat * 3600;
		mysql_query("UPDATE quirex_record SET ip = '' WHERE (UNIX_TIMESTAMP() - time_finish) > $seconds");
		print "</font>\n";
		
		if ($email_admin) {
			$mail_header = "From: \"Quirex PHP\" <$admin_email>\n";
			$mail_subject= "Someone has taken your Quiz";
			$mail_body   = "$name has taken the quiz \"$quiz_name\" \n";
			$mail_body  .= "at ".strftime("%Y-%m-%d %H:%M:%S").".\n";
			$mail_body  .= "The following is a report of his/her answers.\n";
			$mail_body  .= "\n";

			for ($i=0;$i<$number;$i++) {
				list($ques_type, $question, $answer) = mysql_fetch_row(mysql_query("SELECT ques_type, question, answer FROM quirex_ques WHERE ques_id = '$id[$i]'"));

				$mail_body  .= ($i+1).". $question\n";
				if ($ques_type == 'mc') {
					$mail_body  .= "Taker's Answer: ".${"q$i"}."\n";
					$mail_body  .= "Correct Answer: $answer\n";
					}
				elseif ($ques_type == 'ma') {
					$mail_body  .= "Taker's Answer: ".join(", ", ${"q$i"})."\n";
					$mail_body  .= "Correct Answer: ".join(", ", split("\|\|", $answer))."\n";
					}
				elseif ($ques_type == 'sa') {
					$mail_body  .= "Taker's Answer: ".${"q$i"}."\n";
					$mail_body  .= "Correct Answer: ".join(", ", split("\|\|", $answer))."\n";
					}
				elseif ($ques_type == 'nu') {
					$mail_body  .= "Taker's Answer: ".${"q$i"}."\n";
					$mail_body  .= "Correct Answer: $answer\n";
					}
				elseif ($ques_type == 'tf') {
					$tf[t] = "True";
					$tf[f] = "False";
					$mail_body  .= "Taker's Answer: ".$tf[${"q$i"}]."\n";
					$mail_body  .= "Correct Answer: ".$tf[$answer]."\n";
					}
				$mail_body  .= "\n";
				}

			mail($admin_email, $mail_subject, $mail_body, $mail_header);
			}
		
		if ($email_admin) {
			$mail_header = "From: $admin_email\n";
			$mail_subject= "Your Quiz Report";
			$mail_body   = "$name,\n";
			$mail_body   = "Thank you for taking the quiz \"$quiz_name\".\n";
			$mail_body  .= "The following is your quiz report.\n";
			$mail_body  .= "\n";

			for ($i=0;$i<$number;$i++) {
				list($ques_type, $question, $answer) = mysql_fetch_row(mysql_query("SELECT ques_type, question, answer FROM quirex_ques WHERE ques_id = '$id[$i]'"));

				$mail_body  .= ($i+1).". $question\n";
				if ($ques_type == 'mc') {
					$mail_body  .= "Your Answer: ".${"q$i"}."\n";
					if ($show_answer)
					$mail_body  .= "Correct Answer: $answer\n";
					}
				elseif ($ques_type == 'ma') {
					$mail_body  .= "Your Answer: ".join(", ", ${"q$i"})."\n";
					if ($show_answer)
					$mail_body  .= "Correct Answer: ".join(", ", split("\|\|", $answer))."\n";
					}
				elseif ($ques_type == 'sa') {
					$mail_body  .= "Your Answer: ".${"q$i"}."\n";
					if ($show_answer)
					$mail_body  .= "Correct Answer: ".join(", ", split("\|\|", $answer))."\n";
					}
				elseif ($ques_type == 'nu') {
					$mail_body  .= "Your Answer: ".${"q$i"}."\n";
					if ($show_answer)
					$mail_body  .= "Correct Answer: $answer\n";
					}
				elseif ($ques_type == 'tf') {
					$tf[t] = "True";
					$tf[f] = "False";
					$mail_body  .= "Your Answer: ".$tf[${"q$i"}]."\n";
					if ($show_answer)
					$mail_body  .= "Correct Answer: ".$tf[$answer]."\n";
					}
				$mail_body  .= "\n";
				}

			mail($email, $mail_subject, $mail_body, $mail_header);
			}		
		}
	}










function show_record($show) {
	global $script, $anticheat, $require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top;
	global $quiz, $language;

	if ($show == "recent") {
		$result = mysql_query("SELECT taker_name, taker_email, show_record, no_total, no_correct, (time_finish-time_begin) AS time_taken, FROM_UNIXTIME(time_finish) FROM quirex_record WHERE quiz_id = '$quiz' ORDER BY time_finish DESC LIMIT $no_recent");	
		$str = "Recent $no_recent";
		}
	elseif ($show == "top") {
		$result = mysql_query("SELECT taker_name, taker_email, show_record, no_total, no_correct, (time_finish-time_begin) AS time_taken, FROM_UNIXTIME(time_finish) FROM quirex_record WHERE quiz_id = '$quiz' ORDER BY (no_correct/no_total) DESC, no_total DESC, time_taken ASC, time_finish DESC LIMIT $no_top");	
		$str = "Top $no_top";
		}
		
	list($quiz_name) = mysql_fetch_row(mysql_query("SELECT quiz_name FROM quirex_list WHERE quiz_id = '$quiz'"));

	print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=$table_border_color width=90% align=center><tr><td>\n";
	print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
	print "<tr bgcolor=$table_color_1><td colspan=6><font face=\"$font_face\" color=\"$font_color\" size=3><b><i>$quiz_name: $str Quiz Takers</i></b></font></td></tr>\n";
	print "<tr>\n";
	print "	<td align=center bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[name]</b></font></td>\n";
	print "	<td align=center bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[no_total]</b></font></td>\n";
	print "	<td align=center bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[no_correct]</b></font></td>\n";
	print "	<td align=center bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[score]</b></font></td>\n";
	print "	<td align=center bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[time_taken]</b></font></td>\n";
	print "	<td align=center bgcolor=$table_color_1><font face=\"$font_face\" color=\"$font_color\" size=2><b>$language[time_of_trial]</b></font></td>\n";
	print "</tr>\n";	
	
	for($i=0;$i<mysql_num_rows($result);$i++) {
		list($taker_name, $taker_email, $show_record, $no_total, $no_correct, $time_taken, $time) = mysql_fetch_row($result);
		$percentage = round($no_correct/$no_total*10000) / 100;
		$row_color = ($i % 2) ? $table_color_1 : $table_color_2;

		print "<tr>\n";
		if ($show_record) $taker_name = "<a href=\"mailto:$taker_email\">$taker_name</a>";
		print "	<td align=center bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>$taker_name</font></td>\n";
		print "	<td align=center bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>$no_total</font></td>\n";
		print "	<td align=center bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>$no_correct</font></td>\n";
		print "	<td align=center bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>$percentage</font></td>\n";
		print "	<td align=center bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>$time_taken</font></td>\n";
		print "	<td align=center bgcolor=$row_color><font face=\"$font_face\" color=\"$font_color\" size=2>$time</font></td>\n";
		print "</tr>\n";
		}
	
	print "</table>\n";
	print "</td></tr></table>\n";

	}
?>