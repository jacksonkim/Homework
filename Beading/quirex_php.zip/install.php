<?
#######################################################################
#                             Quirex PHP                              #
#              By Thomas Tsoi <cgi@cgihk.com> 2001-09-17              #
#        Copyright 2001 (c) CGIHK.com.  All rights reserved.          #
#######################################################################
#                                                                     #
# CGIHK.com:                                                          #
#   http://www.cgihk.com/                                             #
# Support:                                                            #
#   http://www.cgihk.com/forum/                                       #
# ThomasTsoi.com                                                      #
#   http://www.ThomasTsoi.com/                                        #
# Winapi.com                                                          #
#   http://www.winapi.com/                                            #
# Astronomy.org.hk                                                    #
#   http://www.astronomy.org.hk/                                      #
#                                                                     #
# ################################################################### #
#                                                                     #
#        This is a commercial product and CANNOT be distributed       #
#                  without the author's authorization.                #
#                                                                     #
#######################################################################

require("config.php");

$page = $page ? $page : 1;
$script = "install.php";

switch ($page) {
	case 1:
		head("Quirex PHP Installation");
		print "Make sure you have edited config.php and entered your MySQL login and password correctly.\n";
		print "<p>\n";
		print "The following are what you have set:<br>\n";
		print "<font face='Courier New'>\n";
		print "Your MySQL login&nbsp;&nbsp;&nbsp;&nbsp;: $username<br>\n";
		print "Your MySQL password&nbsp;: $password<br>\n";
		print "Your MySQL database&nbsp;: $database<br>\n";
		print "Your MySQL host&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: $host\n";
		print "</font>\n";
		print "</p>\n";
		print "If you are ready, click the following button to continue.\n";
		print "<form action=$script method=post>\n";
		print "<p align=center>\n";
		print "<input type=submit value='Continue...' style='font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1'>\n";
		print "<input type=hidden name=page value=2>\n";
		print "<input type=hidden name=action value=setsql>\n";
		print "</p>\n";
		print "</form>\n";
		foot();
		break;

	case 2:
		$query[0] = "DROP TABLE IF EXISTS quirex_config";
		$query[1] = "CREATE TABLE quirex_config ( anticheat tinyint(3) unsigned DEFAULT '0' NOT NULL, require_info tinyint(1) unsigned DEFAULT '1' NOT NULL, show_record tinyint(1) unsigned DEFAULT '1' NOT NULL, show_answer tinyint(1) unsigned DEFAULT '1' NOT NULL, show_copyright tinyint(1) unsigned DEFAULT '1' NOT NULL, use_table tinyint(1) unsigned DEFAULT '1' NOT NULL, randomize_ans tinyint(1) unsigned DEFAULT '1' NOT NULL, allow_empty_ans tinyint(1) unsigned DEFAULT '0' NOT NULL, admin_password varchar(12) binary NOT NULL, admin_email varchar(255) NOT NULL, email_admin tinyint(1) unsigned DEFAULT '0' NOT NULL, email_taker tinyint(1) unsigned DEFAULT '0' NOT NULL, header text, footer text, url_site text NOT NULL, url_tick text NOT NULL, url_cross text NOT NULL, font_face varchar(255) NOT NULL, font_color varchar(255) NOT NULL, table_border_color varchar(255) NOT NULL, table_color_1 varchar(255) NOT NULL, table_color_2 varchar(255) NOT NULL, level_name_1 varchar(255) NOT NULL, level_name_2 varchar(255) NOT NULL, level_name_3 varchar(255) NOT NULL, no_options varchar(255) NOT NULL, no_recent char(3) NOT NULL, no_top char(3) NOT NULL);";
		$query[2] = "DROP TABLE IF EXISTS quirex_list";
		$query[3] = "CREATE TABLE quirex_list ( quiz_id int(10) unsigned NOT NULL auto_increment, quiz_name varchar(255) NOT NULL, quiz_desc text NOT NULL, quiz_level tinyint(3) unsigned DEFAULT '0' NOT NULL, UNIQUE quiz_no (quiz_id))";
		$query[4] = "DROP TABLE IF EXISTS quirex_ques";
		$query[5] = "CREATE TABLE quirex_ques ( quiz_id int(10) unsigned DEFAULT '0' NOT NULL, ques_id int(10) unsigned NOT NULL auto_increment, ques_type enum('mc','ma','sa','nu','tf') DEFAULT 'mc' NOT NULL, question text NOT NULL, ques_img text, choice text, answer text NOT NULL, ans_img text, explanation text, no_trial int(10) unsigned DEFAULT '0' NOT NULL, no_correct int(10) unsigned DEFAULT '0' NOT NULL, UNIQUE ques_id (ques_id))";
		$query[6] = "DROP TABLE IF EXISTS quirex_record";
		$query[7] = "CREATE TABLE quirex_record ( quiz_id int(10) unsigned DEFAULT '0' NOT NULL, taker_name varchar(255) NOT NULL, taker_email varchar(255) NOT NULL, show_record tinyint(1) unsigned DEFAULT '1' NOT NULL, no_total int(11) DEFAULT '0' NOT NULL, no_correct int(11) DEFAULT '0' NOT NULL, time_begin int(12) unsigned, time_finish int(12) unsigned, ip varchar(20))";

		$message = array(
			"DROP TABLE quirex_config",
			"CREATE TABLE quirex_config",
			"DROP TABLE quirex_list",
			"CREATE TABLE quirex_list",
			"DROP TABLE quirex_ques",
			"CREATE TABLE quirex_ques",
			"DROP TABLE quirex_record",
			"CREATE TABLE quirex_record"
			);
	
		head("Creating MySQL tables...");
		if ($action=='setsql') {
			mysql_connect($host, $username, $password);
			mysql_select_db($database);
			$failed = 0;
			for ($i=0; $i<8; $i++) {
				$result = mysql_query($query[$i]);
				if ($result) {
					print "$message[$i] successful.<br>";
					}
				else {
					print "$message[$i] not successful.<br>";
					print "mysql_error($result)<br>";
					$failed = 1;
					}
				}

			if (!$failed) {
				print "<form action=$script method=post>\n";
				print "<p align=center>\n";
				print "<input type=submit value='Continue...' style='font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1'>\n";
				print "<input type=hidden name=page value=3>\n";
				print "<input type=hidden name=action value=config>\n";
				print "</p>\n";
				print "</form>\n";
				}
			}
		foot();
		break;

	case 3:
		head("Setting Quirex parameters...");
		
		if ($action=='config') {
			print "<form action=$script method=post>\n";

			print "<fieldset style='margin:5px'><legend>Administration information</legend>\n";
			print "Choose your administration password:<br>\n";
			print "<input type=text name=admin_password maxlength=12 size=12><br><br>\n";
			print "Enter your email address:<br>\n";
			print "<input type=text name=admin_email size=40 value='".getenv("SERVER_ADMIN")."'><br><br>\n";
			print "</fieldset>\n";
			
			print "<fieldset style='margin:5px'><legend>URLs...</legend>\n";
			print "Your site's URL:<br>\n";
			print "<input type=text name=url_site size=40 value='http://".getenv("SERVER_NAME")."'><br><br>\n";
			print "The 'tick' image's URL:<br>\n";
			print "<input type=text name=url_tick size=40><br><br>\n";
			print "The 'cross' image's URL:<br>\n";
			print "<input type=text name=url_cross size=40><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Font and Color</legend>\n";
			print "Font face: \n";
			print "<input type=text name=font_face size=20 value='Arial'><br><br>\n";
			print "Font color: \n";
			print "<input type=text name=font_color size=20 value='#000000'><br><br>\n";
			print "Table border color: \n";
			print "<input type=text name=table_border_color size=20 value='#000000'><br><br>\n";
			print "Table color 1: \n";
			print "<input type=text name=table_color_1 size=20 value='#7F9EBE'><br><br>\n";
			print "Table color 2: \n";
			print "<input type=text name=table_color_2 size=20 value='#9FBEDE'><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Level names</legend>\n";
			print "1. \n";
			print "<input type=text name=level_name_1 size=20 value='Beginner'><br><br>\n";
			print "2. \n";
			print "<input type=text name=level_name_2 size=20 value='Intermediate'><br><br>\n";
			print "3. \n";
			print "<input type=text name=level_name_3 size=20 value='Advanced'><br><br>\n";
			print "</fieldset>\n";

			print "<fieldset style='margin:5px'><legend>Others</legend>\n";
			print "Options for 'Number of Questions to Take' <font size=1>(options are separated by commas)</font>.<br>\n";
			print "<input type=text name=no_options size=20 value='All,10,20,30'><br><br>\n";
			print "Number of Recent Records Shown: \n";
			print "<input type=text name=no_recent size=3 maxlength=3 value='20'><br><br>\n";
			print "Number of Top Records Shown: \n";
			print "<input type=text name=no_top size=3 maxlength=3 value='20'><br><br>\n";
			print "</fieldset>\n";

			print "<p align=center>\n";
			print "<input type=submit value='Continue...' style='font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1'>\n";
			print "<input type=hidden name=page value=4>\n";
			print "<input type=hidden name=action value=config>\n";
			print "</p>\n";
			print "</form>\n";
			}
		foot();
		break;

	case 4:
		head("Setting Quirex parameters...");
		
		if ($action=='config') {
			mysql_connect($host, $username, $password);
			mysql_select_db($database);
			
			mysql_query("DELETE FROM quirex_config");
			$query = 	"INSERT INTO quirex_config SET " .
								"admin_password = '$admin_password', " .
								"admin_email    = '$admin_email', " .
								"url_site       = '$url_site', " .
								"url_tick       = '$url_tick', " .
								"url_cross      = '$url_cross', " .
								"font_face      = '$font_face', " .
								"font_color     = '$font_color', " .
								"table_color_1  = '$table_color_1', " .
								"table_color_2  = '$table_color_2', " .
								"level_name_1   = '$level_name_1', " .
								"level_name_2   = '$level_name_2', " .
								"level_name_3   = '$level_name_3', " .
								"no_options     = '$no_options', " .
								"no_recent      = '$no_recent', " .
								"no_top         = '$no_top'";
			$result = mysql_query($query);
		
			if ($result) {
				print "<form action=$script method=post>\n";

				print "<fieldset style='margin:5px'><legend>Other options</legend>\n";
				print "Do you wish to turn on the anti-cheat function?<br>\n";
				print "<input type=text name=anticheat size=5 value='1'> (enter '1' to disallow takers from taking the same quiz within 1 hour, '24' to disallow takers from taking the same quiz within 24 hours, and so on. Or enter '0' to disable the function.)<br><br>\n";
				print "Do you require quiz takers to enter their names and emails?<br>\n";
				print "<input type=radio name=require_info value=1 checked>Yes <input type=radio name=require_info value=0>No<br><br>\n";
				print "Do you want to make the takers' (top and recent) records to be shown to all visitors?<br>\n";
				print "<input type=radio name=show_record value=1 checked>Yes <input type=radio name=show_record value=0>No<br><br>\n";
				print "Do you want to show answers to quiz takers after they have submitted the form?<br>\n";
				print "<input type=radio name=show_answer value=1 checked>Yes <input type=radio name=show_answer value=0>No<br><br>\n";
				print "Do you want to show the Quirex' name and link?<br>\n";
				print "<input type=radio name=show_copyright value=1 checked>Yes <input type=radio name=show_copyright value=0>No<br><br>\n";
				print "Do you want Quirex to use table for formatting the questions?</small><br>\n";
				print "<input type=radio name=use_table value=1>Yes <input type=radio name=use_table value=0 checked>No<br><br>\n";
				print "Do you want to randomize the positions of answers of Multiple Choice and Multiple Answer questions also?<br>\n";
				print "<input type=radio name=randomize_ans value=1 checked>Yes <input type=radio name=randomize_ans value=0>No<br><br>\n";
				print "Do you want to allow quiz takers to proceed to the answer checking section even if they have left some questions unanswered?<br>\n";
				print "<input type=radio name=allow_empty_ans value=1>Yes <input type=radio name=allow_empty_ans value=0 checked>No<br><br>\n";
				print "Do you want Quirex to email you when someone takes a quiz?<br>\n";
				print "<input type=radio name=email_admin value=1>Yes <input type=radio name=email_admin value=0 checked>No<br><br>\n";
				print "Do you want Quirex to email the quiz taker after he takes a quiz?<br>\n";
				print "<input type=radio name=email_taker value=1>Yes <input type=radio name=email_taker value=0 checked>No<br><br>\n";
				print "</fieldset>\n";

				print "<p align=center>\n";
				print "<input type=submit value='Continue...' style='font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1'>\n";
				print "<input type=hidden name=page value=5>\n";
				print "<input type=hidden name=action value=config>\n";
				print "</p>\n";
				print "</form>\n";
				}
			else {
				print "Failed";
				}
			}
		foot();
		break;

	case 5:
		head("Setting Quirex parameters...");
		
		if ($action=='config') {
			mysql_connect($host, $username, $password);
			mysql_select_db($database);
			
			$query = 	"UPDATE quirex_config SET " .
								"anticheat       = '$anticheat', " .
								"require_info    = '$require_info', " .
								"show_record     = '$show_record', " .
								"show_answer     = '$show_answer', " .
								"show_copyright  = '$show_copyright', " .
								"email_admin     = '$email_admin', " .
								"email_taker     = '$email_taker', " .
								"use_table       = '$use_table', " .
								"randomize_ans   = '$randomize_ans', " .
								"allow_empty_ans = '$allow_empty_ans'";
			$result = mysql_query($query);
		
			if ($result) {
				print "<form action=$script method=post>\n";

				print "<fieldset style='margin:5px'><legend>Header and Footer</legend>\n";
				print "Header:<br>\n";
				print "<textarea name=header cols=50 rows=10 wrap=off></textarea><br><br>\n";
				print "Footer:<br>\n";
				print "<textarea name=footer cols=50 rows=10 wrap=off></textarea><br><br>\n";
				print "</fieldset>\n";

				print "<p align=center>\n";
				print "<input type=submit value='Continue...' style='font-family: Arial; font-weight: bold; background: #ffffff; color:#587AB1'>\n";
				print "<input type=hidden name=page value=6>\n";
				print "<input type=hidden name=action value=config>\n";
				print "</p>\n";
				print "</form>\n";

				}
			else {
				print "Failed";
				}
			}
		foot();
		break;
		
	case 6:
		head("Remove The Installation Script...");
		
		if ($action=='config') {
			mysql_connect($host, $username, $password);
			mysql_select_db($database);
			
			$query = 	"UPDATE quirex_config SET " .
								"header = '$header', " .
								"footer = '$footer'";
			$result = mysql_query($query);
		
			if ($result) {

				print "The installation of Quirex has been done.\n";
				print "<p>\n";
				print "<b>IMPORTANT:</b> For security reasons, please delete this file on your server.";
				print "</p>\n";
				print "After that, you can go to <a href='admin.php'>the Administration Panel</a> to edit your Quirex.\n";

				}
			else {
				print "Failed";
				}
			}
		foot();
		break;

	}

function head ($msg) {
	print "<head>\n";
	print "<title>Quirex PHP Installation</title>\n";
	print "</head>\n";
	print "<body bgcolor=\"#587AB1\" text=\"#ffffff\" link=\"#ddddff\" vlink=\"ffdddd\">\n";
	print "<table width=\"550\" height=400 border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=center>\n";
	print "<tr><td colspan=\"3\" width=\"550\" height=\"60\"><img src=\"images/panel_01.gif\" width=\"550\" height=\"60\"></td></tr>\n";
	print "<tr>\n";
	print "	<td width=20 height=\"289\" background=\"images/panel_02.gif\"><img src=\"images/panel_02.gif\" width=\"20\" height=\"100%\"></td>\n";
	print "	<td width=510 height=\"289\">\n";
	print "	<table width=510 border=0 cellspacing=0 cellpadding=0><tr><td>\n";
	print "<font color=\"#ffffff\" face=Arial size=2>\n";
	print "<p align=center><font size=3><b>$msg</b></font></p>\n";
	}
function foot () {
	print "</font>\n";
	print "		</td></tr></table>\n";
	print "		</td>\n";
	print "		<td width=20 height=\"289\" background=\"images/panel_04.gif\"><img src=\"images/panel_04.gif\" width=\"20\" height=\"100%\"></td>\n";
	print "	</tr>\n";
	print "	<tr><td colspan=\"3\" width=\"550\" height=\"26\"><img src=\"images/panel_05.gif\" width=\"550\" height=\"26\"></td></tr>\n";
	print "	<tr><td colspan=\"3\" width=\"550\" height=\"25\"><a href=\"http://www.cgihk.com\"><img src=\"images/panel_06.gif\" width=\"550\" height=\"25\" border=\"0\"></a></td></tr>\n";
	print "	</table>\n";
	print "	</body>\n";
	print "	</html>\n";
	}

?>