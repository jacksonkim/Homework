<? // English

$language[quiz] = "Quiz";
$language[total_takers] = "Total Takers";
$language[record_holder] = "Record Holders";
$language[na] = "N/A";
$language[num_of_questions] = "Number of Questions";
$language[name] = "Name";
$language[email] = "E-mail";
$language[both_required] = "both reqired";
$language[hide_email] = "Check here if you want to hide your email address";
$language[take_quiz] = "Take the quiz now!";
$language[tf_true] = "True";
$language[tf_false] = "False";
$language[answer] = "Answer";
$language[submit] = "Done!";
$language[continue_quiz] = "Continue the Quiz...";
$language[info_required_msg] = "Both your name and email are required to take the quiz.";
$language[anticheat_msg] = "You are not allowed to re-take the same quiz within 1 hour.";
$language[empty_ans_msg] = "You have unanswered questions.";
$language[your_answer] = "Your Answer";
$language[correct_answer] = "Correct Answer";
$language[explanation] = "Explanation";
$language[result] = "You've got [no_correct] correct out of [no_total] questions, which gives you a score of [percentage].";
$language[take_again] = "Take the Quiz Again!";
$language[back] = "Back to Home";
$language[no_total] = "Ques Attemped";
$language[no_correct] = "Ques Correct";
$language[score] = "Score";
$language[time_taken] = "Time Taken";
$language[time_of_trial] = "Time";

?>