<? // Espa�ol

// Thanks to Ricardo Contreras
//   (http://www.odontologia-online.com)
//  for his translation of Quirex into Spanish

$language[quiz] = "Examen";
$language[total_takers] = "Total de participantes";
$language[record_holder] = "Usuarios con Record";
$language[na] = "N/D";
$language[num_of_questions] = "Cantidad de Preguntas";
$language[name] = "Nombre";
$language[email] = "E-mail";
$language[both_required] = "ambos requeridos";
$language[hide_email] = "Seleccione aqu� si desea ocultar su direcci�n de correo electr�nico";
$language[take_quiz] = "Tomar el examen ahora!";
$language[tf_true] = "Verdadero";
$language[tf_false] = "Falso";
$language[answer] = "Respuesta";
$language[submit] = "Hecho!";
$language[continue_quiz] = "Continuar el Examen...";
$language[info_required_msg] = "Tanto su nombre como su email son requeridos para tomar el examen.";
$language[anticheat_msg] = "A Ud. no se le permite realizar el examen nuevamente dentro de la pr�xima hora.";
$language[empty_ans_msg] = "Ud. no ha respondido preguntas.";
$language[your_answer] = "Su Respuesta";
$language[correct_answer] = "Respuesta Correcta";
$language[explanation] = "Explicaci�n";
$language[result] = "Ud. obtuvo [no_correct] respuestas correctas sobre un total de [no_total] preguntas, lo que le da una calificaci�n de [percentage].";
$language[take_again] = "Tomar el Examen nuevamente!";
$language[back] = "Regresar al Principio";
$language[no_total] = "Preguntas Respondidas";
$language[no_correct] = "Preguntas Correctas";
$language[score] = "Calificaci�n";
$language[time_taken] = "Tiempo transcurrido";
$language[time_of_trial] = "Tiempo";

?>