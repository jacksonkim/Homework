<?
#######################################################################
#                             Quirex PHP                              #
#              By Thomas Tsoi <cgi@cgihk.com> 2001-09-17              #
#        Copyright 2001 (c) CGIHK.com.  All rights reserved.          #
#######################################################################
#                                                                     #
# CGIHK.com:                                                          #
#   http://www.cgihk.com/                                             #
# Support:                                                            #
#   http://www.cgihk.com/forum/                                       #
# ThomasTsoi.com                                                      #
#   http://www.ThomasTsoi.com/                                        #
# Winapi.com                                                          #
#   http://www.winapi.com/                                            #
# Astronomy.org.hk                                                    #
#   http://www.astronomy.org.hk/                                      #
#                                                                     #
# ################################################################### #
#                                                                     #
#        This is a commercial product and CANNOT be distributed       #
#                  without the author's authorization.                #
#                                                                     #
#######################################################################

require("config.php");

if (! mysql_connect($host, $username, $password)) {
	print "MySQL Error: " . mysql_error();
	exit;
	}
mysql_select_db($database);

function show_question($quiz_id, $number, $script_url = "index.php") {
	$result = mysql_query(
	"SELECT require_info, show_record, show_answer, show_copyright, " . 
	"use_table, randomize_ans, allow_empty_ans, " . 
	"admin_password, admin_email, email_admin, email_taker, header, footer, ".
	"url_site, url_tick, url_cross, font_face, font_color, table_border_color, ".
	"table_color_1, table_color_2, level_name_1, level_name_2, level_name_3, ".
	"no_options, no_recent, no_top FROM quirex_config");
	if ($result) {
		list($require_info, $show_record, $show_answer, $show_copyright, $use_table, $randomize_ans, $allow_empty_ans, $admin_password, $admin_email, $email_admin, $email_taker, $header, $footer, $url_site, $url_tick, $url_cross, $font_face, $font_color, $table_border_color, $table_color_1, $table_color_2, $level_name_1, $level_name_2, $level_name_3, $no_options, $no_recent, $no_top) = mysql_fetch_row($result);
		}
	else {
		print "MySQL Error: " . mysql_error();
		exit;
		}
		
if (file_exists("language.php")) {
	include("language.php");
	}
else {
	$language[quiz] = "Quiz";
	$language[total_takers] = "Total Takers";
	$language[record_holder] = "Record Holders";
	$language[na] = "N/A";
	$language[num_of_questions] = "Number of Questions";
	$language[name] = "Name";
	$language[email] = "E-mail";
	$language[both_required] = "both reqired";
	$language[hide_email] = "Check here if you want to hide your email address";
	$language[take_quiz] = "Take the quiz now!";
	$language[tf_true] = "True";
	$language[tf_false] = "False";
	$language[answer] = "Answer";
	$language[submit] = "Done!";
	$language[continue_quiz] = "Continue the Quiz...";
	$language[info_required_msg] = "Both your name and email are required to take the quiz.";
	$language[anticheat_msg] = "You are not allowed to re-take the same quiz within 1 hour.";
	$language[empty_ans_msg] = "You have unanswered questions.";
	$language[your_answer] = "Your Answer";
	$language[correct_answer] = "Correct Answer";
	$language[explanation] = "Explanation";
	$language[result] = "You've got [no_correct] correct out of [no_total] questions, which gives you a score of [percentage].";
	$language[take_again] = "Take the Quiz Again!";
	$language[back] = "Back to Home";
	$language[no_total] = "Ques Attemped";
	$language[no_correct] = "Ques Correct";
	$language[score] = "Score";
	$language[time_taken] = "Time Taken";
	$language[time_of_trial] = "Time";	
	}


	print "<script language=\"JavaScript\">\n";
	print "<!--\n";
	print "function checkValue(obj) {\n";
	print "	if (isNaN(obj.value)) {\n";
	print "		alert('this question requires a numeric answer!');\n";
	print "		obj.value = '';\n";
	print "		}\n";
	print "	}\n";
	print "// -->\n";
	print "</script>\n";
	
	print "<form action=\"$script_url\" method=\"post\">\n";
	print "<table border=0 cellspacing=0 cellpadding=1 bgcolor=$table_border_color width=150><tr><td>\n";
	print "<table border=0 cellspacing=1 cellpadding=1 width=100%>\n";
	print "<tr bgcolor=$table_color_1><td><font face=\"$font_face\" color=\"$font_color\" size=2>";

	list($ques_id, $ques_type, $question, $ques_img, $choice) = mysql_fetch_row(mysql_query("SELECT ques_id, ques_type, question, ques_img, choice FROM quirex_ques WHERE quiz_id = '$quiz_id' ORDER BY RAND() LIMIT 1"));

	print "<b>$question</b><br>";
	if ($ques_img) print "<img src=\"$ques_img\"><br>";

	if ($ques_type == 'mc') {
		$choices = split("\|\|", $choice);
		if ($randomize_ans) {
			for ($j=0;$j<count($choices)*2; $j++) {
				$x = rand(0,count($choices)-1);
				do {
					$y = rand(0,count($choices)-1);
					} while ($x == $y);
				$temp = $choices[$x];
				$choices[$x] = $choices[$y];
				$choices[$y] = $temp;
				}
			}
		for ($j=0;$j<count($choices); $j++) {
			$choice_value = $choices[$j];
			if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
				$choice_shown = "<img src=\"$vars[1]\">";
				}
			else {
				$choice_shown = $choices[$j];
				}
			print "<input type=radio name=\"q0\" value=\"$choice_value\"> $choice_shown<br>";
			}
		}
	elseif ($ques_type == 'ma') {
		$choices = split("\|\|", $choice);
		if ($randomize_ans) {
			for ($j=0;$j<count($choices)*2; $j++) {
				$x = rand(0,count($choices)-1);
				do {
					$y = rand(0,count($choices)-1);
					} while ($x == $y);
				$temp = $choices[$x];
				$choices[$x] = $choices[$y];
				$choices[$y] = $temp;
				}
			}
		for ($j=0;$j<count($choices); $j++) {
			$choice_value = $choices[$j];
			if (eregi("^\[img=(.+)\]$", $choices[$j], $vars)) {
				$choice_shown = "<img src=\"$vars[1]\">";
				}
			else {
				$choice_shown = $choices[$j];
				}
			print "<input type=checkbox name=\"q0"."[$j]\" value=\"$choice_value\"> $choice_shown<br>";
			}
		}
	elseif ($ques_type == 'sa') {
		print "$language[answer]: <input type=text name=\"q0\" size=10><br>";
		}
	elseif ($ques_type == 'nu') {
		print "$language[answer]: <input type=text name=\"q0\" size=10 onChange=\"checkValue(this);\"><br>";
		}
	elseif ($ques_type == 'tf') {
		print "<input type=radio name=\"q0\" value=t>$language[tf_true] <input type=radio name=\"q0\" value=f>$language[tf_false]<br>";
		}

	print "<center><input type=submit value=\"$language[continue_quiz]\" style=\"background-color: $table_color_2; font-family: $font_face\"></center>";
	print "</font></td></tr>\n";
	print "</table>\n";
	print "</td></tr></table>\n";
	print "<input type=hidden name=quiz value=\"$quiz_id\">\n";
	print "<input type=hidden name=number value=\"$number\">\n";
	print "<input type=hidden name=first_ques value=\"$ques_id\">\n";
	print "<input type=hidden name=action value=\"quiz\">\n";
	print "</form>\n";

	}

?>