<html>
<body>

<?
require("sample_ques.php"); 
show_question(1, "All");
?>

</body>
</html>