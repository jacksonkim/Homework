9 July 1996   README.TXT - Please Read The Entire Document 
Book 'em, Dan-O v1.01 by Spider
Email me at  spider@servtech.com
http://www.servtech.com/public/spider
_______________________________________________________________________

Book 'em! ... Leverage your knowledge of your visitors!  Dan-O logs
the time of the visit, the visitor, where they came from and
the browser they were using.

_______________________________________________________________________
Packing List
_______________________________________________________________________
dan_o.pl                    2770 bytes
readme.txt  (this document) 2741 bytes

_______________________________________________________________________
Notes and Revision Status
_______________________________________________________________________
Rev. 1.01 - 10 July 1996

Book 'em Dan-O is nothing out of the ordinary, nothing extraordinary,
but the data you can log is invaluable in tracking where people are
coming from, what your heaviest usage hours are and *most importantly*
what browser their using - all the better to develop your site with!  

This script can be run as a Server Side Include, completely transparent,
or it can be used as a "Continue" button, logging and re-directing the
user at the same time.  In tracking where folks are coming from, it's
most effectively used as a SSI from your home page.  When used as a
re-direct, you'll find that the "where" is always the page the button
was on.  Hey, whacha gonna do.. that's just the way life goes.

Another option this script features is the ability to exclude yourself,
given you have a machine name or static IP.

If you're having problems getting the logging function to operate 
correctly under Unix, create an empty logfile, upload it and issue 
the command    chmod 660 <filename>   After changing the permission 
then issue the command    chown nobody:<your user name> <filename> 
This will properly set the file to be written to by the system.

Please feel free to use and post this script, all I ask is that proper 
credit be retained and noted in your script.  (ie. Please keep it as 
a .zip file with this document intact)

This script has run under Unix and NT without so much as a hiccup.
Surprised me too! :-)  Enjoy!                                                         

_______________________________________________________________________
Standard Disclaimers
_______________________________________________________________________
This script is intended for general use and no warranty is implied for
suitability to any given task.  I hold no responsibility for your setup
or any damage done while using/installing/modifing this script.

Batteries Not Included

Luv ya'll - Enjoy!
Spider :-)   spider@servtech.com
