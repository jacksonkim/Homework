/* CIST 2362 - 20786 - Kimberly Jackson - SID: 0332
	Week 3, Program 2, Parking Meter Sim - 9/9/2012

Description: Create 10 parked cars and 10 parking meters. Randomly setting 
	parking meters to a paid time ranging from 30 minutes to 5 hours 
	(30 minute increments). 
	Display the status of all cars and meters prior to simulation, and during the
	simulation display the tickets. You choose the best output layout. The simulation 
	takes place at a random time ranging from 1 hour to 5 hours (30 minute 
	increments) and the officer issues tickets for each parked car that has an 
	expired meter.

*/

#include <iostream>
#include <iomanip>
#include <string>
#include "ParkedCar.h"
#include "ParkingMeter.h"
#include "ParkingTicket.h"
#include "PoliceOfficer.h"

using namespace std;

void displayAllCars(ParkedCar);
void step30(ParkedCar car[], ParkingMeter meter[], int size, PoliceOfficer pcop);


int main()
{
	const int SIZE = 10;
	ParkedCar cars[SIZE];
	ParkingMeter meters[SIZE];
	PoliceOfficer copbro;

	for (int counter = 0; counter <=SIZE-1; counter++)
	{
		if (counter/2)
		{
			cars[counter].setMinutes(90);
			meters[counter].setMinutes(1800);
		}				
		else if (counter/3)
		{
			cars[counter].setMinutes(180);
			meters[counter].setMinutes(90);
		}		
		else if (counter/5)
		{
			cars[counter].setMinutes(300);
			meters[counter].setMinutes(300);
		}				
		else
		{
				cars[counter].setMinutes(30);
				meters[counter].setMinutes(90);
		} //end if
	} //end for



	for (int count = 0; count <=SIZE-1; count++)
	{
		displayAllCars(cars[count]);
	}

	step30(cars, meters, SIZE, copbro);

	cout << "\n";
	system("pause");
	return 0;

};

void displayAllCars(ParkedCar car)
{
	cout << "Make: " << car.getMake() << "\n";
	cout << "Model: " << car.getModel() << "\n";
	cout << "Color: " << car.getColor() << "\n";
	cout << "License Plate: " << car.getLicensePlate() << "\n";
};

void step30(ParkedCar car[], ParkingMeter meter[], int size, PoliceOfficer pcop)
{
	/*for (int timecounter = 30; timecounter <= 300; timecounter+30)
	{
		for (int count = 0; count <= size-1; count++)
		{
			pcop.testTicket(car[count], meter[count]);
		}
	}*/
};