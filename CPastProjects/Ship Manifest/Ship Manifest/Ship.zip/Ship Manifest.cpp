/* CIST 2362 - 20786 - Kimberly Jackson - SID: 0332
	Week 4, Program 2, Ship Manifest - 9/16/12

	Description: Program that displays all classes should use an array of Ship pointers.
		Array elements should be initialized with addresses of dynamically allocated Ship,
		CargoShip, and CruiseShip objects. Program should step through the array and
		use each object's print function.

*/

#include <iostream>
#include "CargoShip.h"
#include "CruiseShip.h"
#include "Ship.h"

using namespace std;

int main()
{
	const int SIZE = 20;

	cout << "\n";
	system("pause");
	return 0;

};